<?php
/**
 * Created by PhpStorm.
 * User: Corentin
 * Date: 10/01/2018
 * Time: 20:54
 */

use App\Http\Controllers\FriendsController;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;

/**
 * Renvoie la liste des departements Français
 *
 * @return array
 */
function getDepartements()
{
    $depFr = array();

    $depFr['00'] = 'Hors-France';
    $depFr["01"] = "Ain";
    $depFr["02"] = "Aisne";
    $depFr["03"] = "Allier";
    $depFr["04"] = "Alpes-de-Haute-Provence";
    $depFr["06"] = "Alpes-Maritimes";
    $depFr["07"] = "Ardèche";
    $depFr["08"] = "Ardennes";
    $depFr["09"] = "Ariège";
    $depFr["10"] = "Aube";
    $depFr["11"] = "Aude";
    $depFr["12"] = "Aveyron";
    $depFr["67"] = "Bas-Rhin";
    $depFr["13"] = "Bouches-du-Rhône";
    $depFr["14"] = "Calvados";
    $depFr["15"] = "Cantal";
    $depFr["16"] = "Charente";
    $depFr["17"] = "Charente-Maritime";
    $depFr["18"] = "Cher";
    $depFr["19"] = "Corrèze";
    $depFr["2A"] = "Corse-du-Sud";
    $depFr["21"] = "Côte-d'Or";
    $depFr["22"] = "Côtes-d'Armor";
    $depFr["23"] = "Creuse";
    $depFr["79"] = "Deux-Sèvres";
    $depFr["24"] = "Dordogne";
    $depFr["25"] = "Doubs";
    $depFr["26"] = "Drôme";
    $depFr["91"] = "Essonne";
    $depFr["27"] = "Eure";
    $depFr["28"] = "Eure-et-Loir";
    $depFr["29"] = "Finistère";
    $depFr["30"] = "Gard";
    $depFr["32"] = "Gers";
    $depFr["33"] = "Gironde";
    $depFr["971"] = "Guadeloupe";
    $depFr["973"] = "Guyane";
    $depFr["05"] = "Hautes-Alpes";
    $depFr["65"] = "Hautes-Pyrénées";
    $depFr["2B"] = "Haute-Corse";
    $depFr["31"] = "Haute-Garonne";
    $depFr["43"] = "Haute-Loire";
    $depFr["52"] = "Haute-Marne";
    $depFr["70"] = "Haute-Saône";
    $depFr["74"] = "Haute-Savoie";
    $depFr["87"] = "Haute-Vienne";
    $depFr["92"] = "Hauts-de-Seine";
    $depFr["68"] = "Haut-Rhin";
    $depFr["34"] = "Hérault";
    $depFr["35"] = "Ille-et-Vilaine";
    $depFr["36"] = "Indre";
    $depFr["37"] = "Indre-et-Loire";
    $depFr["38"] = "Isère";
    $depFr["39"] = "Jura";
    $depFr["40"] = "Landes";
    $depFr["974"] = "La Réunion";
    $depFr["42"] = "Loire";
    $depFr["45"] = "Loiret";
    $depFr["44"] = "Loire-Atlantique";
    $depFr["41"] = "Loir-et-Cher";
    $depFr["46"] = "Lot";
    $depFr["47"] = "Lot-et-Garonne";
    $depFr["48"] = "Lozère";
    $depFr["49"] = "Maine-et-Loire";
    $depFr["50"] = "Manche";
    $depFr["51"] = "Marne";
    $depFr["972"] = "Martinique";
    $depFr["53"] = "Mayenne";
    $depFr["976"] = "Mayotte";
    $depFr["54"] = "Meurthe-et-Moselle";
    $depFr["55"] = "Meuse";
    $depFr["56"] = "Morbihan";
    $depFr["57"] = "Moselle";
    $depFr["58"] = "Nièvre";
    $depFr["59"] = "Nord";
    $depFr["60"] = "Oise";
    $depFr["61"] = "Orne";
    $depFr["75"] = "Paris";
    $depFr["62"] = "Pas-de-Calais";
    $depFr["63"] = "Puy-de-Dôme";
    $depFr["64"] = "Pyrénées-Atlantiques";
    $depFr["66"] = "Pyrénées-Orientales";
    $depFr["69"] = "Rhône";
    $depFr["71"] = "Saône-et-Loire";
    $depFr["72"] = "Sarthe";
    $depFr["73"] = "Savoie";
    $depFr["93"] = "Seine-Saint-Denis";
    $depFr["76"] = "Seine-Maritime";
    $depFr["77"] = "Seine-et-Marne";
    $depFr["80"] = "Somme";
    $depFr["81"] = "Tarn";
    $depFr["82"] = "Tarn-et-Garonne";
    $depFr["90"] = "Territoire de Belfort";
    $depFr["94"] = "Val-de-Marne";
    $depFr["95"] = "Val-d'Oise";
    $depFr["83"] = "Var";
    $depFr["84"] = "Vaucluse";
    $depFr["85"] = "Vendée";
    $depFr["86"] = "Vienne";
    $depFr["88"] = "Vosges";
    $depFr["89"] = "Yonne";
    $depFr["78"] = "Yvelines";

    ksort($depFr);

    return $depFr;
}

/**
 * Renvoie la liste des orientations
 *
 * @return array
 */
function getOrientations()
{
    return [
        "Hétérosexuel",
        "Bisexuel",
        "Homosexuel",
        "Pansexuel",
        "Polysexuel",
        "Lithoromantique",
        "Demiromantique",
        "Demisexuel",
        "Graysexuel",
        "Asexuel",
        "Aromantique",
        "Autre"
    ];
}

/**
 * Renvoie la liste des statuts
 *
 * @return array
 */
function getStatuts()
{
    return ["En couple", "Célibataire", "C'est compliqué", "Autre", "Recherche amis"];
}

/**
 * Renvoie la liste des prix
 *
 * @return Collection
 */
function getPrix()
{
    return collect([
        ["nom" => "1 000 mcoins", "mcoins" => "1000", "prix" => 0.99, "url" => 1],
        ["nom" => "2 500 + 300 bonus mcoins", "mcoins" => "2800", "prix" => 2.99, "url" => 2],
        ["nom" => "6 000 + 1 500 mcoins", "mcoins" => "7500", "prix" => 5.99, "url" => 3],
        ["nom" => "10 000 + 3 500 bonus mcoins", "mcoins" => "13500", "prix" => 9.99, "url" => 4],
    ]);
}

/**
 * Renvoie les categories du forum
 *
 * @return Collection
 */
function getForumCategories()
{
    return collect([
        ["title" => "Information", "description" => "", "locked" => true],
        ["title" => "Discussion sur meetiak", "description" => ""],
        ["title" => "Discussion sur tout", "description" => ""],
        ["title" => "Gestion du site", "description" => "Problème de modération, bug, suggestion"],
    ]);
}

/**
 * Renvoie le pseudo avec la class rank-$rank
 *
 * @param $pseudo
 * @param $rank
 * @return string
 */
function pseudoRankColor($pseudo, $rank, $sexe_user)
{
    switch ($sexe_user) {
        case 0:
            $sexe = "homme";
            break;
        case 1:
            $sexe = "femme";
            break;
        case 2:
            $sexe = "";
            break;
    }

    return '<span class="rank-' . $rank . ' ' . $sexe . '">' . e($pseudo) . '</span>';
}

/**
 * Renvoie un lien vers l'utilisateur avec la bonne couleur
 *
 * @param $id
 * @return string
 */
function pseudoUserColorLink($id, $class = '')
{

    $userRepo = new \App\Repository\UserRepository();

    abort_unless(!empty($id) or $userRepo->exist("id", $id), 403);

    $user = $userRepo->find($id, ["pseudo", "rank", "sexe"]);

    switch ($user->sexe) {
        case 0:
            $sexe = "homme";
            break;
        case 1:
            $sexe = "femme";
            break;
        case 2:
            $sexe = "autre";
            break;
    }

    return '<a class="no-style rank-' . $user->rank . ' ' . $sexe . ' ' . $class . '" href="' . url("user/" . $id) . '">' . e($user->pseudo) . '</a>';
}

/**
 * Créer une pagination pour un array ou une collection
 *
 * @param $items
 * @param int $perPage
 * @param null $page
 * @param array $options
 * @return LengthAwarePaginator
 */
function paginateArrayOrCollection($items, $perPage = 15, $page = null, $options = [])
{
    $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
    $items = $items instanceof Collection ? $items : Collection::make($items);
    return new LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, $options);
}

/**
 * Renvoie le nombre de demande d'ami
 *
 * @return int
 */
function getFriendsRequestCount()
{
    if (auth()->check()) {
        /** @var FriendsController $friends */
        $friends = resolve(FriendsController::class);
        return $friends->friendRequestCount();
    } else {
        return 0;
    }
}

/**
 * Utilise un attribut -> sur la collection
 *
 * @param Collection $collection
 * @param String $attribute
 * @return Collection
 */
function collectionAttribute(Collection $collection, String $attribute)
{
    $arr = [];

    foreach ($collection as $col) {
        $arr[] = $col->$attribute;
    }

    return collect($arr);
}

/**
 * Renvoie un token unique de longueur $lenght
 *
 * @param String $table
 * @param String $column
 * @param Int $length
 * @return string
 */
function createUniqueToken(String $table, String $column, Int $length)
{

    do {
        $token = str_random($length);

    } while (DB::table($table)->where($column, $token)->exists());

    return $token;

}

/**
 * Renvoie le nom de la sahdowBox correspondant à l'utilistateur
 *
 * @param $rank
 * @param $sexe
 * @return string
 */
function shadowBoxName($rank, $sexe)
{

    if ($rank > 1) {
        return "box-shadow-rank-" . $rank;
    }

    switch ($sexe) {

        case 0:
            return "box-shadow-homme";
            break;
        case 1:
            return "box-shadow-femme";
            break;

        default:
            return "box-shadow-autre";
            break;

    }

}