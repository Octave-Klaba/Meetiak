<?php

return [

    ["nom" => "Priorité dans les recherches", "nom_id" => "priorite_recherche", "description" => "Vous êtes affiché en premier dans la page recherche.", "prix" => 100, "jours" => 7, "html" => '<i class="fas fa-search green"></i>'],
    ["nom" => "NameGlow", "nom_id" => "pseudo_background", "description" => "Votre pseudo brille de mille feux, trop la classe !", "prix" => 2000, "jours" => 0, "html" => "pseudo_background"],
    ["nom" => "ShadowBox", "nom_id" => "shadow_box", "description" => "Sur votre profile et sur la page de recherche la boite possède un une ombre brillante !", "prix" => 5000, "jours" => 0, "html" => "shadow_box"],


];