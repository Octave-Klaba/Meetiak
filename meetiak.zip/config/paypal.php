<?php

return [
    'credentials' => [
        'sandbox' => env("PAYPAL_SANDBOX", true),

        //REST
        'clientId' => env("PAYPAL_CLIENT_ID", ""),
        'secret' => env("PAYPAL_SECRET", "")
    ],
];