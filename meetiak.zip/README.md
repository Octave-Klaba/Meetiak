# TODOLIST


* Système de ban + Raison (pop up comme bouton signaler) + Modo qui as ban
* Système staff édité un profil
* Upload screenshot pour report (non obligatoire)
* Page avec liste des membres du staff
* Badge pour les amis
* Système de Pawn
* Notifications (demande d'amis accepté, badge gagné)
* Dernière connection affiché sur le profil
* Recherche triée par dernière connexion croissant