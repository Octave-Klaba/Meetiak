<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['ban_ip'])->group(function () {

    Route::get("/", "IndexController@index")->name("home");
    Route::get("/home", "IndexController@index");

    //Register
    Route::get("/auth/register", "AuthController@registerView");
    Route::post("/auth/register", "AuthController@register");

    //Email
    Route::get("auth/email/confirmation", "AuthController@confirmationEmail");

    //Login
    Route::get("auth/login", 'AuthController@loginView')->name("login");
    Route::post("auth/login", 'AuthController@login');

    Route::get("auth/logout", 'AuthController@logout')->name("logout");

    //Reset password
    Route::get("auth/forgot", "PasswordResetsController@forgotView");
    Route::post("auth/forgot", "PasswordResetsController@forgot");

    Route::get("auth/reset", "PasswordResetsController@resetView");
    Route::post("auth/reset", "PasswordResetsController@reset");

    //Profile
    Route::get('user/{id}', "UserController@profile");

    Route::get('account', "UserController@accountView");
    Route::post('account/password', "UserController@accountPassword");

    Route::post('account/avatar/crop', "UserController@accountAvatarCrop");
    Route::post('account/avatar', "UserController@accountAvatar");

    Route::post('account/info', "UserController@accountInfo");
    Route::post('account/delete', "UserController@delete");

    //Parrainage
    Route::get("parrainage", "UserController@parrainage");

    //Report
    Route::post("user/report", "UserController@report");

    //Chat
    Route::get("chat", "ChatController@chatView");
    Route::get("chat/get", "ChatController@get");
    Route::post("chat/add", "ChatController@add");
    Route::post("chat/delete", "ChatController@delete");
    Route::post("chat/clear", "ChatController@clear");

    //Conversation
    Route::get('conversations/unread/all', "ConversationsController@getAllUnread");
    Route::get('conversations/unread/all/user', "ConversationsController@getAllUnreadByUser");

    Route::get('conversations', "ConversationsController@index");
    Route::get('conversations/{user}', "ConversationsController@show")->name('conversations.show');
    Route::post('conversations/{user}/get', "ConversationsController@get");
    Route::post('conversations/{user}/add', "ConversationsController@add");

    //Recherche
    Route::get("search/", "SearchController@searchView");
    Route::post("search/ajax", "SearchController@search");

    //Friends
    Route::get("friends", "FriendsController@friends");
    Route::get("friends/request/got/count", "FriendsController@friendRequestCount");
    Route::get("friends/requests/got", "FriendsController@requestsGot");
    Route::get("friends/requests/sent", "FriendsController@requestsSent");

    Route::get("friends/delete", "FriendsController@deleteFriend");
    Route::get("friends/requests/accept", "FriendsController@acceptRequest");
    Route::get("friends/requests/ignore", "FriendsController@ignoreRequest");

    Route::get("friends/requests/remove/sent", "FriendsController@removeSentRequest");
    Route::get("friends/requests/send", "FriendsController@sendRequest");

    //Block
    Route::get("block", "FriendsController@blockUser");
    Route::get("friends/blocked", "FriendsController@blockedUser");
    Route::get("friends/unblock", "FriendsController@unblockUser");

    //Boutique
    Route::get("boutique", "BoutiqueController@get");
    Route::post("boutique/purchase", "BoutiqueController@purchase");

    //Mcoins
    Route::get("mcoins", "McoinsController@show");

    //Paypal
    Route::get("order/create/{url}", "PayController@createOrder");

    Route::get("paypal/{order}", "PayController@order")->name("paypal.order");
    Route::get("paypal/pay/{order}", "PayController@pay");
    Route::get("paypal/completed/{order}", "PayController@complete")->name("paypal.complete");
    Route::get("paypal/cancel/{order}", "PayController@cancel")->name("paypal.cancel");

    //Forum
    Route::get("forum", "ForumController@view");
    Route::get("forum/get/category", "ForumController@getCategory");
    Route::get("forum/get/post", "ForumController@getPost");
    Route::post("forum/create/post", "ForumController@createPost");
    Route::post("forum/create/message", "ForumController@createMessage");

});

//Moderateur
Route::middleware(['auth', "moderator"])->group(function () {

    Route::get("/admin", "AdminController@index");

    Route::get("/admin/report", "AdminController@getReports");
    Route::post("/admin/report", "AdminController@deleteReport");

    Route::post("/admin/ban", "AdminController@ban");

});


Route::get("/rules", "IndexController@rules");
Route::get("/cgu", "IndexController@cgu");


