<?php
/**
 * Created by PhpStorm.
 * User: Corentin
 * Date: 15/02/2018
 * Time: 15:37
 */

return [
    //Chat
    ["nom" => "On discute ?", "nom_id" => "chat_20", "description" => "Envoyer 20 messages sur le chat.", "image" => "chat_20.png"],
    ["nom" => "J'aime parler !", "nom_id" => "chat_100", "description" => "Envoyer 100 messages sur le chat.", "image" => "chat_100.png"],
    ["nom" => "Parleeeeer !", "nom_id" => "chat_200", "description" => "Envoyer 200 messages sur le chat.", "image" => "chat_200.png"],
    ["nom" => "Gros Parleur", "nom_id" => "chat_500", "description" => "Envoyer 500 messages sur le chat.", "image" => "chat_500.png"],
    ["nom" => "Parleur Actif", "nom_id" => "chat_1000", "description" => "Envoyer 1000 messages sur le chat.", "image" => "chat_1000.png"],
    ["nom" => "Chercheur de conversation", "nom_id" => "chat_2000", "description" => "Envoyer 2000 messages sur le chat.", "image" => "chat_2000.png"],
    ["nom" => "Initié du chat", "nom_id" => "chat_5000", "description" => "Envoyer 5000 messages sur le chat.", "image" => "chat_5000.png"],
    ["nom" => "Habitué du chat", "nom_id" => "chat_7000", "description" => "Envoyer 7000 messages sur le chat.", "image" => "chat_7000.png"],
    ["nom" => "It's Over 9000 !", "nom_id" => "chat_9000", "description" => "Envoyer 9000 messages sur le chat.", "image" => "chat_9000.png"],
    ["nom" => "Prince du chat !", "nom_id" => "chat_10000", "description" => "Envoyer 10000 messages sur le chat.", "image" => "chat_10000.png"],
    ["nom" => "Roi du chat !", "nom_id" => "chat_15000", "description" => "Envoyer 15000 messages sur le chat.", "image" => "chat_15000.png"],
    
    ["nom" => "Youtubeur", "nom_id" => "video", "description" => "A fait une vidéo sur MeetiaK.", "image" => "youtube.png"],
    ["nom" => "Vive les mariés !", "nom_id" => "marié", "description" => "Être marié !", "image" => "mariage.png"],
    ["nom" => "Mcoins !", "nom_id" => "mcoins", "description" => "As acheté des Mcoins !", "image" => "mcoins.png"],
    ["nom" => "Je suis VIP !", "nom_id" => "vip", "description" => "As acheté le V.I.P. !", "image" => "vip.png"],
    ["nom" => "Alphatesteur", "nom_id" => "alpha", "description" => "Être Alphatesteur !", "image" => "alphatest.png"],
    ["nom" => "Staff !", "nom_id" => "staff", "description" => "Membre du staff !", "image" => "staff.png"],
    ["nom" => "Partenaires !", "nom_id" => "partenaire", "description" => "Est partenaire avec MeetiaK !", "image" => "partenaires.png"],
    ["nom" => "Bon annif !", "nom_id" => "birthday", "description" => "S'est connecté le jour de son anniversaire !", "image" => "birthday.png"],
    


];