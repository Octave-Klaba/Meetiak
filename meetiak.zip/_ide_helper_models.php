<?php
/**
 * A helper file for your Eloquent Models
 * Copy the phpDocs from this file to the correct Model,
 * And remove them from this file, to prevent double declarations.
 *
 * @author Barry vd. Heuvel <barryvdh@gmail.com>
 */


namespace App{
/**
 * App\Annonce
 *
 * @property int $id
 * @property string $titre
 * @property string $annonce
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Annonce whereAnnonce($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Annonce whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Annonce whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Annonce whereTitre($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Annonce whereUpdatedAt($value)
 */
	class Annonce extends \Eloquent {}
}

namespace App{
/**
 * App\Badge
 *
 * @property int $id
 * @property string $nom
 * @property string $description
 * @property string $image
 * @property string $nom_id
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Badge whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Badge whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Badge whereImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Badge whereNom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Badge whereNomId($value)
 */
	class Badge extends \Eloquent {}
}

namespace App{
/**
 * App\Ban
 *
 */
	class Ban extends \Eloquent {}
}

namespace App{
/**
 * App\Boutique
 *
 * @property int $id
 * @property string $nom
 * @property string $nom_id
 * @property string $description
 * @property int $prix
 * @property string|null $html
 * @property int $jours
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Boutique whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Boutique whereHtml($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Boutique whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Boutique whereJours($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Boutique whereNom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Boutique whereNomId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Boutique wherePrix($value)
 */
	class Boutique extends \Eloquent {}
}

namespace App{
/**
 * App\BoutiqueUser
 *
 * @property int $id
 * @property int $user_id
 * @property string $boutique_id
 * @property string $expires_at
 * @property string $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property-read \App\Boutique $boutique
 * @property-read bool $expired
 * @method static \Illuminate\Database\Eloquent\Builder|\App\BoutiqueUser notExpired()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\BoutiqueUser whereBoutiqueId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\BoutiqueUser whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\BoutiqueUser whereExpiresAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\BoutiqueUser whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\BoutiqueUser whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\BoutiqueUser whereUserId($value)
 */
	class BoutiqueUser extends \Eloquent {}
}

namespace App{
/**
 * App\Chat
 *
 * @property int $id
 * @property int $user_id
 * @property string $message
 * @property string|null $last_ip
 * @property string $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string|null $deleted_at
 * @property-read string $full_date
 * @property-read \App\User $user
 * @method static bool|null forceDelete()
 * @method static \Illuminate\Database\Query\Builder|\App\Chat onlyTrashed()
 * @method static bool|null restore()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Chat whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Chat whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Chat whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Chat whereLastIp($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Chat whereMessage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Chat whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Chat whereUserId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Chat withTrashed()
 * @method static \Illuminate\Database\Query\Builder|\App\Chat withoutTrashed()
 */
	class Chat extends \Eloquent {}
}

namespace App{
/**
 * App\ForumCategory
 *
 * @property int $id
 * @property string $title
 * @property string $description
 * @property int $locked
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property-read int $posts_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\ForumPost[] $posts
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumCategory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumCategory whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumCategory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumCategory whereLocked($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumCategory whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumCategory whereUpdatedAt($value)
 */
	class ForumCategory extends \Eloquent {}
}

namespace App{
/**
 * App\ForumMessage
 *
 * @property int $id
 * @property int $user_id
 * @property int $post_id
 * @property string $message
 * @property string $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @property-read string $full_date
 * @property-read \App\ForumPost $post
 * @property-read \App\User $user
 * @method static bool|null forceDelete()
 * @method static \Illuminate\Database\Query\Builder|\App\ForumMessage onlyTrashed()
 * @method static bool|null restore()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumMessage whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumMessage whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumMessage whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumMessage whereMessage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumMessage wherePostId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumMessage whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumMessage whereUserId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\ForumMessage withTrashed()
 * @method static \Illuminate\Database\Query\Builder|\App\ForumMessage withoutTrashed()
 */
	class ForumMessage extends \Eloquent {}
}

namespace App{
/**
 * App\ForumPost
 *
 * @property int $id
 * @property int $user_id
 * @property string $title
 * @property int $locked
 * @property string $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @property int $category_id
 * @property-read \App\ForumCategory $category
 * @property-read int $messages_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\ForumMessage[] $messages
 * @property-read \App\User $user
 * @method static bool|null forceDelete()
 * @method static \Illuminate\Database\Query\Builder|\App\ForumPost onlyTrashed()
 * @method static bool|null restore()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumPost whereCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumPost whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumPost whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumPost whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumPost whereLocked($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumPost whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumPost whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ForumPost whereUserId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\ForumPost withTrashed()
 * @method static \Illuminate\Database\Query\Builder|\App\ForumPost withoutTrashed()
 */
	class ForumPost extends \Eloquent {}
}

namespace App{
/**
 * App\Mcoins
 *
 * @property int $id
 * @property int $user_id
 * @property int $montant
 * @property string $description
 * @property string $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property-read \App\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Mcoins whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Mcoins whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Mcoins whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Mcoins whereMontant($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Mcoins whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Mcoins whereUserId($value)
 */
	class Mcoins extends \Eloquent {}
}

namespace App{
/**
 * App\Message
 *
 * @property int $id
 * @property int $from_user
 * @property int $to_user
 * @property string $content
 * @property string $created_at
 * @property \Carbon\Carbon|null $read_at
 * @property-read \App\User $from
 * @property-read string $full_date
 * @property-read \App\User $to
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Message whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Message whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Message whereFromUser($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Message whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Message whereReadAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Message whereToUser($value)
 */
	class Message extends \Eloquent {}
}

namespace App{
/**
 * App\Order
 *
 * @property int $id
 * @property int $user_id
 * @property float $amount
 * @property string $transaction_id
 * @property int $accepted
 * @property string $created_at
 * @property string $updated_at
 * @property \Carbon\Carbon|null $deleted_at
 * @property string $uuid
 * @property int $mcoins
 * @property-read \App\User $user
 * @method static bool|null forceDelete()
 * @method static \Illuminate\Database\Query\Builder|\App\Order onlyTrashed()
 * @method static bool|null restore()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereAccepted($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereAmount($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereMcoins($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereTransactionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Order whereUuid($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Order withTrashed()
 * @method static \Illuminate\Database\Query\Builder|\App\Order withoutTrashed()
 */
	class Order extends \Eloquent {}
}

namespace App{
/**
 * App\Parrainage
 *
 * @property int $id
 * @property int $user_id
 * @property string $parrain_id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property-read \App\User $parrain
 * @property-read \App\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Parrainage whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Parrainage whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Parrainage whereParrainId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Parrainage whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Parrainage whereUserId($value)
 */
	class Parrainage extends \Eloquent {}
}

namespace App{
/**
 * App\PasswordResets
 *
 * @property string $email
 * @property string $token
 * @property \Carbon\Carbon|null $created_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\PasswordResets whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\PasswordResets whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\PasswordResets whereToken($value)
 */
	class PasswordResets extends \Eloquent {}
}

namespace App{
/**
 * App\Reports
 *
 * @property int $id
 * @property int $from_user
 * @property int $to_user
 * @property string $raison
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Reports whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Reports whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Reports whereFromUser($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Reports whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Reports whereRaison($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Reports whereToUser($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Reports whereUpdatedAt($value)
 */
	class Reports extends \Eloquent {}
}

namespace App{
/**
 * App\User
 *
 * @property int $id
 * @property string $pseudo
 * @property string $email
 * @property string $password
 * @property string|null $remember_token
 * @property \Carbon\Carbon $ddn
 * @property int $sexe
 * @property int $orientation
 * @property int $statut
 * @property string|null $departement
 * @property string|null $description
 * @property int $niveau
 * @property int $rank
 * @property string|null $confirmation_token
 * @property string|null $confirmed_at
 * @property int $confirmed
 * @property string|null $reset_at
 * @property string|null $last_ip
 * @property string|null $referer
 * @property string $avatar
 * @property string|null $facebook
 * @property string|null $youtube
 * @property string|null $snapchat
 * @property string|null $steam
 * @property string|null $twitter
 * @property string|null $twitch
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string $last_online
 * @property string|null $instagram
 * @property int $mcoins
 * @property string $parrain_id
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Badge[] $badges
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\BoutiqueUser[] $boutiqueUser
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Parrainage[] $filleuls
 * @property-read \Illuminate\Database\Eloquent\Collection|\Hootlex\Friendships\Models\Friendship[] $friends
 * @property-read int $age
 * @property-read string $avatar_link
 * @property-read int $departement_nom
 * @property-read string $is_online
 * @property-read string $is_online_dot
 * @property-read string $link
 * @property-read mixed $orientation_nom
 * @property-read mixed $pseudo_style
 * @property-read string $sexe_icon
 * @property-read string $shadow_box
 * @property-read mixed $statut_nom
 * @property-read string $titre
 * @property-read \Illuminate\Database\Eloquent\Collection|\Hootlex\Friendships\Models\FriendFriendshipGroups[] $groups
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Mcoins[] $mcoinsRelation
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property-read \App\Order $orders
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereAvatar($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereConfirmationToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereConfirmed($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereConfirmedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereDdn($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereDepartement($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereFacebook($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereInstagram($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereLastIp($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereLastOnline($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereMcoins($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereNiveau($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereOrientation($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereParrainId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User wherePseudo($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereRank($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereReferer($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereResetAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereSexe($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereSnapchat($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereStatut($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereSteam($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereTwitch($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereTwitter($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereYoutube($value)
 */
	class User extends \Eloquent {}
}

