<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Badge extends Model
{
    protected $table = "badges";

    protected $guarded = [];

    /**
     * Renvoie "img/badges/" + image
     *
     * @param $value
     * @return string
     */
    public function getImageAttribute($value)
    {
        return "img/badges/" . $value;
    }
}
