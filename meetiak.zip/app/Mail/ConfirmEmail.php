<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ConfirmEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $varlink;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($varlink)
    {
        $this->varlink = $varlink;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this
            ->from('noreply@meetiak.fr')
            ->view('mail.confirm_email',["varlink" => $this->varlink]);
    }
}
