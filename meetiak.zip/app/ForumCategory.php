<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ForumCategory extends Model
{
    protected $table = "forum_categories";

    protected $guarded = [];

    protected $with = ["posts"];

    protected $appends = ["posts_count"];

    /**
     * Renvoie le nombres de posts
     *
     * @return int
     */
    public function getPostsCountAttribute()
    {
        return $this->posts()->count();
    }

    /**
     * Relation catégorie <- posts
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function posts()
    {
        return $this->hasMany(ForumPost::class, "category_id", "id")->latest();
    }

}
