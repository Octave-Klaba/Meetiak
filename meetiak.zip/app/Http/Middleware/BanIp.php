<?php

namespace App\Http\Middleware;

use App\Ban;
use Closure;

class BanIp
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (Ban::isBanIP(\Request::ip())) {
            return response()->make(view('bannned'));
        }

        return $next($request);
    }
}
