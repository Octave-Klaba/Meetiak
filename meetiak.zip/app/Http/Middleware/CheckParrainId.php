<?php

namespace App\Http\Middleware;

use App\User;
use Closure;

class CheckParrainId
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if ($request->has('p') && User::whereParrainId($request->p)->exists()) {
            \Cookie::queue('parrain_id', $request->p, 240);
        }

        return $next($request);
    }
}
