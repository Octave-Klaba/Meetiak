<?php

namespace App\Http\Middleware;

use App\Ban;
use App\Repository\UserRepository;
use App\User;
use Closure;
use Illuminate\Support\Facades\Auth;

class Online
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {


        if (Auth::check()) {
            $userRep = new UserRepository();
            $userRep->update(Auth::id(), ["last_online" => \DB::raw("NOW()"), "last_ip" => \Request::ip()]);
        }

        //Pyxelle
        if (User::wherePseudo("🤖 Pyxelle")->exists()) {
            User::wherePseudo("🤖 Pyxelle")->update(["last_online" => \DB::raw("NOW()")]);

            \DB::table("chat_online")->updateOrInsert(["user" => User::wherePseudo("🤖 Pyxelle")->first()->id], ["last_online" => \DB::raw("NOW()")]);
        }

        //Deco ban
        if (\auth()->check() && Ban::isBanEmail(\auth()->user()->email)) {

            \auth()->logout();
        }

        return $next($request);
    }
}
