<?php

namespace App\Http\Controllers;

use App\Boutique;
use App\BoutiqueUser;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BoutiqueController extends Controller
{

    public function __construct()
    {
        $this->middleware(["auth"]);
    }

    /**
     * Affiche la boutique
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function get()
    {
        $items = Boutique::all();

        return view("boutique.boutique", compact("items"));
    }

    /**
     * Vérifie si l'utilisateur peut acheté un produit et l'achète
     *
     * @param Request $request
     * @return mixed|string
     */
    public function purchase(Request $request)
    {
        $boutique = Boutique::whereNomId($request->nom_id)->firstOrFail();

        //403 si n'a pas assez de mcoins ou utilisateur à déjà le produit
        abort_if(Auth::user()->mcoins < $boutique->prix, 403);
        abort_if(Auth::user()->hasBoutique($boutique->nom_id), 403);


        Auth::user()->changeMcoins($boutique->prix * -1, $boutique->nom);
        Auth::user()->save();

        $boutiqueUser = new BoutiqueUser;

        $boutiqueUser->boutique_id = $boutique->nom_id;
        $boutiqueUser->expires_at = Carbon::now()->addDays(($boutique->jours !== 0) ? $boutique->jours : 18250);

        Auth::user()->boutiqueUser()->save($boutiqueUser);

        return $boutique->nom;


    }
}


