<?php

namespace App\Http\Controllers;

use Alert;
use App\Mail\ConfirmEmail;
use App\Parrainage;
use App\Repository\UserRepository;
use App\Rules\BanEmail;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AuthController extends Controller
{
    //
    private $user;

    public function __construct(UserRepository $user)
    {
        $this->middleware("guest")->only(["registerView", "register", "login", "loginView"]);
        $this->middleware("auth")->only(["logout"]);

        $this->user = $user;
    }


    /**
     * Confirme l'email
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function confirmationEmail(Request $request)
    {
        $id = $this->user->existConfirmationToken($request->token);
        if ($id !== -1) {

            $this->user->updateConfirmed($request->token);

            auth()->loginUsingId($id);

            Alert::success('Email vérifier avec succès', 'Vous êtes connecté !');

            //Parrainage
            if (Parrainage::whereUserId($id)->exists()) {

                $parrain = Parrainage::whereUserId($id)->first()->parrain;
                $parrain->changeMcoins(PARRAIN_MCOINS, "Vous avez parrainé " . User::find($id)->pseudo);
                $parrain->save();


                $user = User::find($id);
                $user->changeMcoins(FILLEUL_MCOINS, "Vous êtes le filleul " . $parrain->pseudo);
                $user->save();

            }

        } else {
            Alert::error('Token invalide ou déjà utilisé', 'Erreur');
        }
        return redirect("/");

    }


    ///////////////////////////////////////////
    /// Register                            ///
    ///////////////////////////////////////////

    /**
     * Affiche le formulaire d'inscription
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function registerView(Request $request)
    {

        $sexes = ["Homme", "Femme", "Autre"];
        $departements = getDepartements();
        $orientations = getOrientations();

        return view("auth.register", compact("sexes", "departements", "orientations"));
    }

    /**
     * Verifie les requests et ajoute l'utilisateurs au site
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function register(Request $request)
    {

        $this->validate($request,
            [
                'pseudo' => ["required", "unique:users,pseudo", "regex:/^[\p{L}\p{N}]+$/iu"],
                'email' => ['required', 'email', 'unique:users,email', new BanEmail],
                'password' => 'required|confirmed',
                'ddn' => 'required|date|age',
                'sexe' => 'required|in:0,1,2',
                'departement' => ['required', Rule::in(array_keys(getdepartements()))],
                'orientation' => ['required', Rule::in(array_keys(getOrientations()))],
                'rules' => ['required', 'in:1'],
                'g-recaptcha-response' => config("app.use_recaptcha") ? 'required|recaptcha' : '',
            ],
            [
                "pseudo.required" => "Le pseudo est vide.",
                "pseudo.unique" => "Le pseudo est déjà pris.",
                "pseudo.regex" => "Le pseudo ne peut contenir que des lettres et des chiffres.",

                "email.required" => "L'email est vide.",
                "email.email" => "L'email est non valide.",
                "email.unique" => "L'email est déjà prise.",

                "password.required" => "Le mot de passe est vide.",
                "password.confirmed" => "Les mots de passe ne corresponde pas.",

                "ddn.required" => "La date de naissance est vide.",
                "ddn.date" => "La date de naissance est non valide.",
                "ddn.age" => "Vous devez avoir entre 13 et 99 ans pour utiliser ce site.",

                "sexe.required" => "Le sexe est vide.",
                "sexe.in" => "Le sexe est non valide.",

                "departement.required" => "Le departement est vide",
                "departement.in" => "Le departement est non valide.",

                "orientation.required" => "L'orientation est vide",
                "orientation.in" => "L'orientation est non valide.",

                "rules.required" => 'Vous devez acceptez le règlement pour vous inscrire.',
                "rules.in" => 'Vous devez acceptez le règlement pour vous inscrire.',

                "g-recaptcha-response.required" => "Erreur du recaptcha.",
                "g-recaptcha-response.recaptcha" => "Erreur du recaptcha.",
            ]
        );

        $request->ddn = Carbon::parse($request->ddn)->toDateString();

        $token = $this->user->addUser($request);

        //Email
        $varlink = url("auth/email/confirmation") . '?token=' . $token;
        \Mail::to($request->email)->send(new ConfirmEmail($varlink));

        Alert::success('Un email de vérification a été envoyé à ' . $request->email, 'Compte créer avec succès !')->persistent("Fermer");;

        return redirect("/");

    }


    ///////////////////////////////////////////
    /// Login                               ///
    ///////////////////////////////////////////

    /**
     * Affiche la page de connection
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function loginView()
    {
        return view("auth.login");
    }

    /**
     * Connecte l'utilisateur
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\RedirectResponse
     */
    public function login(Request $request)
    {
        $this->validate($request,
            [
                'email' => ['required', 'email', new BanEmail],
                'password' => 'required',

            ],
            [
                "email.required" => "Le email est vide.",
                "email.email" => "L'email est non valide.",

                "password.required" => "Le mot de passe est vide.",
            ]
        );


        //Si tout est bon
        if (auth()->attempt(["email" => $request->email, "password" => $request->password, "confirmed" => true], $request->remember)) {

            //Alert::success("Vous êtes connecté !");

            //Ip
            $this->user->update(auth()->user()->id, ["last_ip" => \Request::ip()]);

            return redirect()->intended("/");


            //Si l'email n'a pas été validé
        } elseif (auth()->attempt(["email" => $request->email, "password" => $request->password, "confirmed" => false])) {

            auth()->logout();
            $request->flashOnly(['email']);
            return redirect()->back()->withErrors(["Email non validé."]);

            //Si pseudo ou mot de passe n'est pas bon
        } else {

            $request->flashOnly(['email']);
            return redirect()->back()->withErrors(["Mauvais email ou mot de passe."]);

        }

    }

    /**
     * Déconnecte l'utilisateur
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function logout()
    {
        auth()->logout();
        Alert::info("Vous êtes déconnecté");
        return redirect("/");
    }
}
