<?php

namespace App\Http\Controllers;

use App\ForumCategory;
use App\ForumMessage;
use App\ForumPost;
use Auth;
use Illuminate\Http\Request;

class ForumController extends Controller
{


    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Affiche les catégories
     *
     * @return mixed
     */
    public function view()
    {
        $categories = ForumCategory::all();

        return view("forum", compact("categories"));
    }

    /**
     * Renvoie les postes d'une catégorie
     *
     * @param Request $request
     * @return ForumCategory|\Illuminate\Database\Eloquent\Builder
     */
    public function getCategory(Request $request)
    {
        $model = ForumCategory::findOrFail($request->id);

        $model->posts->each(function (ForumPost $model) {
            $model->user->setVisible(["link"]);
        });

        return $model->posts;
    }

    /**
     * Renvoie les messages d'un post
     *
     * @param Request $request
     * @return array
     */
    public function getPost(Request $request)
    {
        /** @var ForumPost $post */
        $post = ForumPost::findOrFail($request->id);

        $messages = $post->messages()->orderBy("created_at", "ASC")->get();

        return [$messages->toArray(), $post->title, $post->locked];

    }

    /**
     * Créer un post
     *
     * @param Request $request
     * @return int|mixed
     */
    public function createPost(Request $request)
    {

        $this->validate($request,
            [
                "title" => "required|max:150",
                "message" => "required",
                "id" => "category_is_not_locked"
            ],
            [
                "title.required" => "Le nom du post est vide.",
                "title.max" => "Le nom du post ne doit pas avoir plus de 150 caractères",

                "message.required" => "Le message est vide.",

                "id.category_is_not_locked" => "La catégorie est fermé."
            ]);

        //Post
        $post = new ForumPost(["title" => $request->title]);

        $post->user()->associate(Auth::user());
        $post->category_id = ForumCategory::findOrFail($request->id)->id;

        $post->save();

        //Message
        $message = new ForumMessage;

        $message->message = $request->message;
        $message->post()->associate($post);
        $message->user()->associate(Auth::user());

        $message->save();

        return json_encode([$post->category_id, $post->id]);


    }

    /**
     * Créer un message et l'associe au post avec l'id que request
     *
     * @param Request $request
     */
    public function createMessage(Request $request)
    {

        $post = ForumPost::findOrFail($request->id);

        $message = new ForumMessage;
        $message->message = $request->message;
        $message->post()->associate($post);
        $message->user()->associate(Auth::user());

        $message->save();

    }

}

