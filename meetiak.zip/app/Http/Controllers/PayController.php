<?php

namespace App\Http\Controllers;

use App\Order;
use App\PayPal;
use Auth;
use Illuminate\Http\Request;


class PayController extends Controller
{

    public function __construct()
    {
        $this->middleware(["auth"])->except(['complete', 'cancel']);
    }

    /**
     * Créait un order
     *
     * @param $amount
     */
    public function createOrder($url)
    {
        $prix = getPrix();

        abort_unless($prix->contains("url", $url), 404);

        $prix = $prix->where("url", $url)->first();

        $order = New Order;
        $order->amount = $prix['prix'];
        $order->uuid = createUniqueToken($order->getTable(), "uuid", 20);
        $order->transaction_id = $order->uuid;
        $order->mcoins = $prix['mcoins'];

        Auth::user()->orders()->save($order);

        return redirect()->route("paypal.order", $order->uuid);


    }

    /**
     * Affiche les infos
     *
     * @param $order_id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function order($order_id)
    {
        $order = Order::whereAccepted(false)->where("uuid", $order_id)->firstOrFail();
        return view("order", compact("order"));
    }

    /**
     * Redirige vers paypal
     *
     * @param $order_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function pay($order_id)
    {

        $order = Order::whereAccepted(false)->where("uuid", $order_id)->firstOrFail();
        $paypal = new PayPal;

        $response = $paypal->purchase([
            'amount' => $paypal->formatAmount($order->amount),
            'transactionId' => $order->uuid,
            'currency' => 'EUR',
            'cancelUrl' => $paypal->getCancelUrl($order),
            'returnUrl' => $paypal->getReturnUrl($order),

        ]);

        if ($response->isRedirect()) {
            $response->redirect();
        }

        return redirect()->back()->with([
            'message' => $response->getMessage(),
        ]);
    }

    /**
     * Confirme et ajoute les mcoins
     *
     * @param $order_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function complete(Request $request, $order_id)
    {
        $order = Order::whereAccepted(false)->where("uuid", $order_id)->firstOrFail();
        $paypal = new PayPal;

        $response = $paypal->complete([
            'payerId' => $request->PayerID,
            'transactionReference' => $request->paymentId,
        ]);

        if ($response->isSuccessful()) {

            $order->update(['transaction_id' => $response->getTransactionReference(), "accepted" => true]);

            $order->user->changeMcoins($order->mcoins, "Paiment de " . $order->amount . " €", true);

            \Alert::success("Paimement réussie !");

            return redirect()->to("mcoins#/acheter");
        }

        return redirect(url("paypal", $order->uuid))->with([
            'message' => $response->getMessage(),
        ]);

    }

    /**
     * Annule le paiment
     *
     * @param $order_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function cancel($order_id)
    {
        $order = Order::whereAccepted(false)->where("uuid", $order_id)->firstOrFail();
        $order->delete();

        \Alert::warning("Paimement annulé !");

        return redirect()->to("mcoins#/acheter");
    }
}
