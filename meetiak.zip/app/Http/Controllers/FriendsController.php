<?php

namespace App\Http\Controllers;

use App\Repository\UserRepository;
use App\User;
use Hootlex\Friendships\Models\Friendship;
use Hootlex\Friendships\Status;
use Illuminate\Http\Request;

class FriendsController extends Controller
{
    private $user;

    public function __construct(UserRepository $user)
    {
        $this->user = $user;

        $this->middleware("auth");
    }

    /**
     * Affiche la list d'amis
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function friends()
    {

        $friends = User::find(auth()->id())->getFriends();

        return view("user.friends", ["friends" => $this->friendsExtraInfoPagination($friends, "friends"), "page" => "friends"]);
    }

    /**
     * Affiche la liste des demandes d'amis reçu
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function requestsGot()
    {

        $friends = collectionAttribute(User::find(auth()->id())->getFriendRequests(), "sender");

        return view("user.friends", ["friends" => $this->friendsExtraInfoPagination($friends, "friends/requests/got"), "page" => "got"]);

    }

    /**
     * Renvoie le nombre de demande d'amis
     *
     * @return int
     */
    public function friendRequestCount()
    {
        return User::find(auth()->id())->getFriendRequests()->count();
    }

    /**
     * Affiche la liste des demandes d'amis envoyée
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function requestsSent()
    {
        $col = User::find(auth()->id())->getPendingFriendships()->filter(function ($key) {
            return $key->sender_id === auth()->id();
        });

        $friends = collectionAttribute($col, "recipient");

        return view("user.friends", ["friends" => $this->friendsExtraInfoPagination($friends, "friends/requests/sent"), "page" => "sent"]);

    }

    /**
     * Affiche la liste des utilisateurs bloqué
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function blockedUser()
    {
        $col = User::find(auth()->id())->getBlockedFriendships()->filter(function ($key) {
            return $key->sender_id === auth()->id();
        });

        $friends = collectionAttribute($col, "recipient");

        return view("user.friends", ["friends" => $this->friendsExtraInfoPagination($friends, "friends/blocked"), "page" => "blocked"]);
    }

    /**
     * Envoie une demande d'ami
     *
     * @param Request $request
     */
    public function sendRequest(Request $request)
    {
        //Pas sois-même
        abort_if(auth()->id() === $request->id, 403);

        User::find(auth()->id())->befriend(User::findOrFail($request->id));

        \Alert::success("Demande d'ami envoyé");

        return redirect()->back();
    }

    /**
     * Bloque une demande d'ami
     *
     * @param Request $request
     */
    public function blockUser(Request $request)
    {
        //Pas sois-même
        abort_if(auth()->id() === $request->id, 403);

        //Pas contre rank >= 3 et pas pour rank >= 3
        if (\App::environment() !== "local") {
            abort_if($this->user->find($request->id, ["rank"])->rank >= 3, 403);
            abort_if(auth()->user()->rank >= 3, 403);
        }

        User::find(auth()->id())->blockFriend(User::findOrFail($request->id));
        \Alert::success("Utilisateur bloqué");

        return redirect()->back();
    }

    /**
     * Débloque l'utilisateur
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function unblockUser(Request $request)
    {
        User::find(auth()->id())->unblockFriend(User::findOrFail($request->id));
        \Alert::success("Utilisateur débloqué");

        return redirect()->back();
    }

    /**
     * Accepte la demande d'ami
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function acceptRequest(Request $request)
    {
        User::find(auth()->id())->acceptFriendRequest(User::findOrFail($request->id));
        \Alert::success("Ami ajouté !");

        return redirect()->back();
    }

    /**
     * Ignore la demande d'ami
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function ignoreRequest(Request $request)
    {
        User::find(auth()->id())->denyFriendRequest(User::findOrFail($request->id));

        \Alert::success("Demande d'ami supprimé !");

        return redirect()->back();
    }

    /**
     * Supprime un ami
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteFriend(Request $request)
    {
        User::find(auth()->id())->unfriend(User::findOrFail($request->id));
        \Alert::success("Ami supprimé !");

        return redirect()->back();
    }

    /**
     * Supprime une demande d'ami non accepté
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function removeSentRequest(Request $request)
    {

        Friendship::where("sender_id", auth()->id())->where("recipient_id", $request->id)->where("status", Status::PENDING)->delete();
        \Alert::success("Demande d'ami supprimé !");

        return redirect()->back();
    }

    /**
     * Ajoute des infos à friends et créer une pagination
     *
     * @param $friends
     */
    private function friendsExtraInfoPagination($friends, $path)
    {
        /*foreach ($friends as &$friend) {
            $friend->isOnline = $this->user->isOnline($friend->id);
        }*/

        $friends = paginateArrayOrCollection($friends, 20);
        $friends->setPath(url($path));

        return $friends;
    }
}
