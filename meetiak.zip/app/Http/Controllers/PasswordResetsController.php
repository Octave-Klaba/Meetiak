<?php

namespace App\Http\Controllers;

use Alert;
use App\Mail\ResetPassword;
use App\PasswordResets;
use App\Repository\UserRepository;
use App\Rules\BanEmail;
use Illuminate\Http\Request;
use Mail;

class PasswordResetsController extends Controller
{
    private $user;

    public function __construct(UserRepository $user)
    {
        $this->middleware("guest");

        $this->user = $user;
    }

    /**
     * Affiche le formulaire de mot de passe oublié
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function forgotView()
    {
        return view("auth.forgot");
    }

    /**
     * Envoie un email de récupération
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function forgot(Request $request)
    {
        $this->validate($request,
            ['email' => ['required', 'email', new BanEmail]],
            [
                "email.required" => "L'email est vide.",
                "email.email" => "L'email est non valide."
            ]);

        //Vérifie si l'email existe

        if ($this->user->exist("email", $request->email)) {
            $token = PasswordResets::addToken($request->email);

            //Email
            $varlink = url("auth/reset") . '?token=' . $token;
            Mail::to($request->email)->send(new ResetPassword($varlink));

            Alert::success("Email envoyé");

        }

        return redirect("auth/login");
    }

    /**
     * Affiche le formulaire de reinitialization du mot de passe
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Illuminate\View\View
     */
    public function resetView(Request $request)
    {
        if (PasswordResets::existToken($request->token)) {
            return view("auth.reset", ["token" => $request->token]);
        } else {
            Alert::error("Token invalide");
            return redirect("auth/login");
        }
    }

    /**
     * Change le mot de passe de l'utilisateur
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function reset(Request $request)
    {

        $this->validate($request, ['password' => 'required|confirmed'],
            [
                "password.required" => "Le mot de passe est vide.",
                "password.confirmed" => "Les mots de passe ne corresponde pas."
            ]);

        if (PasswordResets::existToken($request->token)) {

            $this->user->updateWithField("email", PasswordResets::getEmail($request->token),
                ["password" => bcrypt($request->password), "reset_at" => \DB::raw("NOW()")]);

            PasswordResets::deleteToken($request->token);

            Alert::success("Mot de passe changé avec succès !");
            return redirect("auth/login");
        } else {
            Alert::error("Token invalide");
            return redirect("auth/login");
        }

    }
}
