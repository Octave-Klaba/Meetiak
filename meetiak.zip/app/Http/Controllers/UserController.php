<?php

namespace App\Http\Controllers;

use App\Reports;
use App\Repository\UserRepository;
use App\User;
use Illuminate\Http\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

class UserController extends Controller
{
    private $user;

    public function __construct(UserRepository $user)
    {
        $this->middleware("auth")->except(["profile"]);

        $this->user = $user;

    }

    /**
     * Affiche la page de l'utilisateur
     *
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function profile($id)
    {
        //Si l'id n'existe pas -> 404
        /** @var User $user */
        $user = User::findOrFail($id);

        if (auth()->check() && $user->hasBlocked(auth()->user())) {
            return view("user.blocked", compact("user", "id"));
        }

        return view("user.profile", compact("user", "id"));

    }

    /**
     * Affiche le formulaire de modification du profile
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function accountView()
    {
        $statuts = getStatuts();
        return view("user.account", ["user" => auth()->user(), "orientations" => getOrientations(), "status" => $statuts]);
    }

    /**
     * Change le mot de passe de l'utilisateur
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function accountPassword(Request $request)
    {
        \Session::put("account_form", "password");

        $this->validate($request,
            ['password' => 'required|confirmed'],
            [
                "password.required" => "Le mot de passe est vide.",
                "password.confirmed" => "Les mots de passe ne correspondent pas.",
            ]);

        $this->user->update(auth()->user()->id, ["password" => bcrypt($request->password), "reset_at" => \DB::raw("NOW()")]);

        \Alert::success("Mot de passe changé avec succès !");

        return redirect("account");

    }

    /**
     * Valide et redigire vers la page de rognage
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function accountAvatarCrop(Request $request)
    {
        \Session::put("account_form", "avatar");

        $this->validate($request,
            ["avatar" => "required|file|image|max:5000"],
            [
                "avatar.required" => "Vous n'avez pas envoyer de fichier.",
                "avatar.file" => "Fichier invalide.",
                "avatar.image" => "Le fichier n'est pas une image.",
                "avatar.max" => "L'image doit faire moins de 5 Mo."
            ]);

        $path = $request->file('avatar')->getRealPath();
        $type = pathinfo($path, PATHINFO_EXTENSION);
        $data = file_get_contents($path);
        $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

        return view("user.avatar", compact("base64"));

    }

    /**
     * Change l'avatar de l'utilisateur
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function accountAvatar(Request $request)
    {
        $path = Storage::putFile('public/avatars', new File(public_path() . "/../storage/app/public/avatars/default.png"));

        //Image intervetion
        Image::make($request->image)->save(Storage::disk('local')->getDriver()->getAdapter()->getPathPrefix() . $path);


        $this->user->updateAvatar(auth()->user()->id, $path);


        \Alert::success("Avatar changé avec succès !");

        return redirect("account");
    }

    /**
     * Change les infos de l'utilisateur
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function accountInfo(Request $request)
    {
        \Session::put("account_form", "info");

        $this->user->update(auth()->user()->id, [
            "facebook" => $request->facebook,
            "youtube" => $request->youtube,
            "snapchat" => $request->snapchat,
            "steam" => $request->steam,
            "twitter" => $request->twitter,
            "twitch" => $request->twitch,
            "instagram" => $request->instagram,
            "orientation" => $request->orientation,
            "statut" => $request->statut,
            "departement" => $request->departement,
            "description" => $request->description
        ]);

        \Alert::success("Infos changé avec succès !");

        return redirect("account");

    }

    /**
     * Envoie un signalement
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function report(Request $request)
    {
        $this->validate($request,
            [
                "raison" => "required",
                "toUser" => "required"
            ],
            [
                "raison.required" => "Vous devez rentrer une raison pour signaler un utilisateur.",
                "toUser.required" => "Utilisateur à signer invalide."
            ]);

        Reports::addReport(auth()->user()->id, $request->toUser, $request->raison);

        \Alert::success("Utilisateur signalé");

        return redirect()->back();
    }

    /**
     * Supprime le compte
     *
     * @param Request $request
     * @return $this|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function delete(Request $request)
    {
        \Session::put("account_form", "delete");

        //Vérifie le mot de passe
        if (Hash::check($request->password, auth()->user()->password)) {

            \Auth::user()->delete();
            auth()->logout();

            \Alert::success("Au revoir", "Compte supprimé");

            return redirect("/");

        } else {
            return redirect()->back()->withErrors(["Mauvais mot de passe."]);
        }
    }

    /**
     * Affiche la page du parrainage
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function parrainage()
    {

        return view("user.parrainage");
    }

}
