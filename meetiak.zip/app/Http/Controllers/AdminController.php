<?php

namespace App\Http\Controllers;

use App\Ban;
use App\Repository\ReportRepository;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{

    private $report;

    public function __construct(ReportRepository $report)
    {
        $this->report = $report;
    }

    /**
     * Affiche la page d'administration
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        return view("admin.index");
    }

    /**
     * Renvoie les signalements
     *
     * @return array
     */
    public function getReports()
    {
        return $this->report->getReport()->toArray();
    }

    public function deleteReport(Request $request)
    {
        $this->report->softDelete($request->id);
    }

    /**
     * Ban l'ip et l'emai lde l'utilisateur
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function ban(Request $request)
    {

        /** @var User $user */
        $user = User::findOrFail($request->id);

        if (!Ban::isBanEmail($user->email)) {
            DB::table("ban_email")->insert(["email" => $user->email, "created_at" => DB::raw("NOW()")]);
        }

        if (!Ban::isBanIp($user->last_ip)) {
            DB::table("ban_ip")->insert(["ip" => $user->last_ip, "created_at" => DB::raw("NOW()")]);
        }

        $user->rank = 0;
        $user->save();

        \Alert::success($user->pseudo . "bannie.");

        return redirect()->back();

    }
}
