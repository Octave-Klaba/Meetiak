<?php

namespace App\Http\Controllers;

use App\Badge;
use App\Chat;
use App\Events\BadgeEvent;
use App\Repository\ChatOnlineRepository;
use App\Repository\ChatRepository;
use App\User;
use Auth;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    private $chat;
    private $chatOnline;


    public function __construct(ChatRepository $chat, ChatOnlineRepository $chatOnline)
    {
        $this->chat = $chat;
        $this->chatOnline = $chatOnline;


        $this->middleware('auth');
        $this->middleware(['auth', "moderator"])->only(["delete"]);
        $this->middleware(['auth', "admin"])->only(["clear"]);

    }

    private function updateOnline()
    {
        if (auth()->check()) {
            $this->chatOnline->insertOrUpdateWithField("user", auth()->user()->id, ["last_online" => \DB::raw("NOW()")]);
        }
    }

    /**
     * Affiche le chat
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function chatView()
    {
        $this->updateOnline();
        return view("chat");
    }

    /**
     * Renvoie les messages en JSON
     *
     * @return array
     */
    public function get()
    {
        $this->updateOnline();
        $arr = $this->chat->getMessages();

        return ["messages" => $arr->toArray(), "usersOnline" => $this->getOnlineUsers()];
    }

    /**
     * Ajoute le message à la bdd
     *
     * @param Request $request
     */
    public function add(Request $request)
    {
        $this->updateOnline();

        //Commande
        //say text
        if (Auth::user()->rank >= 4 && preg_match_all('/^\/say\s+(\S.+)$/s', $request->message, $matches, PREG_SET_ORDER, 0)) {
            $text = $matches[0][1];
            $this->chat->insert(["user_id" => User::wherePseudo("🤖 Pyxelle")->first()->id, "message" => $text, "last_ip" => \Request::ip()]);
        } else {

            $this->chat->insert(["user_id" => auth()->user()->id, "message" => $request->message, "last_ip" => \Request::ip()]);

            //Badge
            $paliers = [20, 100, 200, 500, 1000, 2000, 5000, 7000, 9000, 10000, 15000];

            foreach ($paliers as $index => $palier) {

                $count = Chat::whereUserId(auth()->id())->count();

                //$max = $index + 1 === count($paliers) ? array_last($paliers) : $paliers[$index + 1];

                if ($count >= $palier) {
                    event(new BadgeEvent(Badge::whereNomId("chat_" . $palier)->firstOrFail()));
                }

            }
        }

    }

    /**
     * Supprime un message
     *
     * @param Request $request
     */
    public function delete(Request $request)
    {
        $this->chat->softDelete($request->id);
    }

    /**
     * Soft delete tout les messages
     */
    public function clear()
    {
        $this->chat->clear();
    }

    /**
     * Renvoie les utilisateurs connecté
     *
     * @return array
     */
    private function getOnlineUsers()
    {
        $arr = $this->chatOnline->getOnlineUsers();

        foreach ($arr as &$value) {

            $value->link = User::find($value->user)->link;

        }

        return $arr->values()->toArray();

    }


}
