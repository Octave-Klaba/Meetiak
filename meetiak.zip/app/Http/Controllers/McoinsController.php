<?php

namespace App\Http\Controllers;

class McoinsController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth']);
    }

    /**
     * Affiche la page mcoins
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show()
    {
        $mcoinsHistory = \Auth::user()->mcoinsRelation()->orderByDesc("created_at")->get();
        $produits = \Auth::user()->boutiqueUser()->orderByDesc("created_at")->get();

        $orders = \Auth::user()->orders()->where("accepted", true)->orderByDesc("created_at")->get();
        $ordersCancelled = \Auth::user()->orders()->withTrashed()->where("accepted", false)->orderByDesc("created_at")->get();

        $mcoinsPrix = getPrix();

        return view("boutique.mcoins", compact("mcoinsHistory", "produits", "mcoinsPrix", "orders", "ordersCancelled"));
    }

}
