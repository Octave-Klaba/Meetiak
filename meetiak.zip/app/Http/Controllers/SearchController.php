<?php

namespace App\Http\Controllers;

use App\Repository\UserRepository;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class SearchController extends Controller
{

    private $user;

    public function __construct(UserRepository $user)
    {
        $this->user = $user;
        $this->middleware("auth");
    }


    /**
     * Affiche la page de recherche
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function searchView()
    {
        return view("search");
    }

    public function search(Request $request)
    {
        $users = $this->user->search($request);

        //Sort
        $users = $users->sort(
            function (User $user1, User $user2) {
                $user1Has = $user1->hasBoutique("priorite_recherche");
                $user2Has = $user2->hasBoutique("priorite_recherche");

                return $user2Has <=> $user1Has;
            });

        Session::put("search_pseudo", $request->pseudo);

        Session::put("search_homme", $request->homme);
        Session::put("search_femme", $request->femme);
        Session::put("search_autre", $request->autre);

        Session::put("search_departement", $request->departement);

        Session::put("search_min", $request->min);
        Session::put("search_max", $request->max);

        Session::put("search_online", $request->online);


        return $users->values()->toArray();
    }
}
