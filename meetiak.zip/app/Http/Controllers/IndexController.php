<?php

namespace App\Http\Controllers;

use App\Repository\UserRepository;

class IndexController extends Controller
{
    private $user;

    public function __construct(UserRepository $user)
    {
        $this->user = $user;

    }

    /**
     * Page d'acceuil
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {

        //    Connecté -> acceuil
        //Non Connecté -> index
        if (auth()->check()) {

            //lastReg = Dernier inscrits
            $lastReg = $this->user->getLastRegistered(30);

            return view("acceuil", compact("lastReg"));
        } else {
            //nbrUsers = Nombres d'utilisateurs

            $nbrUsers = $this->user->count();
            return view("index", compact("nbrUsers"));
        }
    }

    /**
     * Affiche le règlement
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function rules()
    {
        return view("rules");
    }

    /**
     * Affiche les CGU
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function CGU()
    {
        return view("cgu");
    }

}
