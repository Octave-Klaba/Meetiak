<?php

namespace App\Http\Controllers;

use App\Repository\ConversationRepository;
use App\Repository\UserRepository;
use App\User;
use Illuminate\Http\Request;

class ConversationsController extends Controller
{
    /**
     * @var ConversationRepository;
     */
    private $conversations;
    private $user;

    public function __construct(ConversationRepository $conversationRepository, UserRepository $user)
    {
        $this->conversations = $conversationRepository;
        $this->user = $user;

        $this->middleware('auth');
    }

    /**
     * Affiche la liste d'amis avec les messages non lus
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {

        $friends = $this->getFriends();

        return view("conversations.index", compact("friends"));
    }

    /**
     * Affiche la page dialogue
     *
     * @param $user_id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show($user_id)
    {
        $this->abort($user_id);

        $friends = $this->getFriends();

        return view("conversations.show", ["user" => User::find($user_id), "friends" => $friends]);
    }

    /**
     * Renvoie les messages en json
     *
     * @param $user_id
     * @return array
     */
    public function get($user_id)
    {
        $this->abort($user_id);

        $messages = $this->conversations->getMessage(auth()->id(), $user_id, 100);

        return $messages->toArray();
    }

    /**
     * Ajoute un mp
     *
     * @param $user_id
     * @param Request $request
     */
    public function add($user_id, Request $request)
    {
        $this->abort($user_id);

        $this->validate($request, ["message" => "required"]);

        $this->conversations->insert(["from_user" => auth()->id(), "to_user" => $user_id, "content" => $request->message]);
    }

    /**
     * Renvoie le nombre de notifications
     */
    public function getAllUnread()
    {
        return $this->conversations->getAllUnread(auth()->id());
    }

    public function getAllUnreadByUser()
    {
        return $this->conversations->getAllUnreadByUser(auth()->id())->toArray();
    }

    /**
     * Logique pour empêcher de se parler à soit mêm, un non amis ou un bloqué
     *
     * @param $user_id
     */
    private function abort($user_id)
    {
        abort_if(auth()->user()->id === $user_id, 403);
        abort_if(User::find(auth()->id())->isBlockedBy(User::findOrFail($user_id)), 403);
        abort_unless(User::find(auth()->id())->isFriendWith(User::findOrFail($user_id)), 403);
    }

    /**
     * Renvoie la liste d'amis
     *
     * @return \Illuminate\Support\Collection
     */
    private function getFriends()
    {
        $friends = User::find(auth()->id())->getFriends();

        foreach ($friends as &$friend) {

            $friend->unread = $this->conversations->getUnread(auth()->id(), $friend->id);

        }

        return $friends;
    }
}

