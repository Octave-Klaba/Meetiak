<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Chat extends Model
{
    use SoftDeletes;

    protected $table = "chat";

    protected $hidden = ["last_ip", "updated_at", "deleted_at"];

    protected $with = ["user"];

    protected $appends = ["full_date"];

    /**
     * Renvoie le différence pour humain
     *
     * @param $value
     * @return string
     */
    public function getCreatedAtAttribute($value)
    {
        return ucfirst(Carbon::parse($value)->diffForHumans());
    }

    /**
     * Renvoie la date complete
     *
     * @return string
     */
    public function getFullDateAttribute()
    {
        return Carbon::parse($this->getOriginal("created_at"))->format("d/m/Y H:i:s");
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
