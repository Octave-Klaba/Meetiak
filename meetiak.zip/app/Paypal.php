<?php

namespace App;

use Omnipay\Omnipay;

/**
 * Class PayPal
 * @package App
 */
class PayPal
{
    /**
     * @return mixed
     */
    public function gateway()
    {
        $gateway = Omnipay::create('PayPal_Rest');

        /* $gateway->setUsername(config('paypal.credentials.username'));
         $gateway->setPassword(config('paypal.credentials.password'));
         $gateway->setSignature(config('paypal.credentials.signature'));
         $gateway->setTestMode(config('paypal.credentials.sandbox'));
        // $gateway->setLocaleCode("fr_FR");*/

        $gateway->initialize(array(
            'clientId' => config('paypal.credentials.clientId'),
            'secret' => config('paypal.credentials.secret'),
            'testMode' => config('paypal.credentials.sandbox'), // Or false when you are ready for live transactions
        ));

        return $gateway;
    }

    /**
     * @param array $parameters
     * @return mixed
     */
    public function purchase(array $parameters)
    {
        $response = $this->gateway()
            ->purchase($parameters)
            ->send();

        return $response;
    }

    /**
     * @param array $parameters
     */
    public function complete(array $parameters)
    {
        $response = $this->gateway()
            ->completePurchase($parameters)
            ->send();

        return $response;
    }

    /**
     * @param $amount
     */
    public function formatAmount($amount)
    {
        return number_format($amount, 2, '.', '');
    }

    /**
     * @param $order
     */
    public function getCancelUrl($order)
    {
        return route('paypal.cancel', $order->uuid);
    }

    /**
     * @param $order
     */
    public function getReturnUrl($order)
    {
        return route('paypal.complete', $order->uuid);
    }

}