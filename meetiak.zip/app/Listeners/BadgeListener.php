<?php

namespace App\Listeners;

use App\Events\BadgeEvent;
use App\User;

class BadgeListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  BadgeEvent $event
     * @return void
     */
    public function handle(BadgeEvent $event)
    {
        $hasBadge = User::find(auth()->id())->badges()->where("badge_id", $event->badgeId)->exists();
        //Vérifie les dupliqué
        if (auth()->check() && !$hasBadge) {

            //Associe le badge
            User::find(auth()->id())->badges()->attach($event->badgeId);

        }
    }
}
