<?php

namespace App\Listeners;

use App\Events\UserDeleteEvent;

class UserDeleteListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserDeleteEvent $event
     * @return void
     */
    public function handle(UserDeleteEvent $event)
    {
        $event->user->deleteFriendships();
    }
}
