<?php

namespace App;

use App\Events\UserDeleteEvent;
use App\Repository\UserRepository;
use Carbon\Carbon;
use Hootlex\Friendships\Traits\Friendable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;
    use Friendable;

    protected $table = 'users';
    protected $appends = ['link', 'pseudo_style', 'avatar_link', "is_online", "is_online_dot", "sexe_icon", "age", "departement_nom", "orientation_nom", "statut_nom", "titre", "shadow_box"];
    protected $dates = ["ddn"];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'last_online'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'email', 'password', 'remember_token', 'confirmation_token', 'confirmed', 'confirmed_at', 'referer', 'reset_at', 'updated_at', 'mcoins', 'description', 'ddn', 'rank', 'parrain_id',
        'facebook', 'instagram', 'last_ip', 'niveau', 'snapchat', 'steam', 'twitch', 'twitter', 'youtube'
    ];

    protected $dispatchesEvents = [
        'deleting' => UserDeleteEvent::class,
    ];

    /**
     * Supprime les amis et bloqués
     */
    public function deleteFriendships()
    {
        $this->findFriendships()->delete();
    }

    /**
     * Renvoie un lien vers le profil
     *
     * @return string
     */
    public function getLinkAttribute()
    {
        $class = collect();

        if ($this->hasBoutique("pseudo_background")) {
            $class->push("effet");
        }

        return pseudoUserColorLink($this->id, $class->implode(" "));
    }

    /**
     * Renvoie link mais sans a
     *
     * @return mixed
     */
    public function getPseudoStyleAttribute()
    {
        return str_replace("</a", "</span", str_replace("<a", "<span", $this->link));
    }

    /**
     * Renvoie un lien vers l'avatr de l'utilisateur
     *
     * @return string
     */
    public function getAvatarLinkAttribute()
    {
        return \Illuminate\Support\Facades\Storage::url($this->avatar);
    }

    /**
     * Renvoie si l'utilisateur est en ligne
     *
     * @return string
     */
    public function getIsOnlineAttribute()
    {
        $rep = new UserRepository();

        return $rep->isOnline($this->id);
    }

    /**
     * Renvoie le html du point
     *
     * @return string
     */
    public function getIsOnlineDotAttribute()
    {
        return '<i class="fas fa-circle mx-2 ' . ($this->is_online ? "online" : "d-none") . '" aria-hidden="true"></i>';
    }

    /**
     * Renvoie l'html de l'icon et de la couleur du sexe de l'utilisateur
     *
     * @return string
     */
    public function getSexeIconAttribute()
    {
        switch ($this->sexe) {

            case 0:
                return "<span class=\"homme d-block\"><i class=\"fas fa-mars\" aria-hidden=\"true\"></i></span>";
                break;
            case 1:
                return "<span class=\"femme d-block\"><i class=\"fas fa-venus\" aria-hidden=\"true\"></i></span>";
                break;

            default:
                return "<span class=\"invisible d-block\">Autre</span>";
                break;

        }

    }

    /**
     * Renvoie l'age de l'utilisateur
     *
     * @return int
     */
    public function getAgeAttribute()
    {
        return Carbon::parse($this->ddn)->age;
    }

    /**
     * Renvoie l'age de l'utilisateur
     *
     * @return int
     */
    public function getDepartementNomAttribute()
    {
        return getDepartements()[$this->departement];
    }

    /**
     * Renvoie le nom de l'orientation
     *
     * @return mixed
     */
    public function getOrientationNomAttribute()
    {
        return getOrientations()[$this->orientation];
    }

    /**
     * Renvoie le nom du statut
     *
     * @return mixed
     */
    public function getStatutNomAttribute()
    {
        return getStatuts()[$this->statut];
    }

    /**
     * Renvoie le titre associer au rang
     *
     * @return string
     */
    public function getTitreAttribute()
    {
        switch ($this->rank) {

            case 5:
                return "Administrateur";
                break;

            case 4:
                return "Modérateur";
                break;

            case 6:
                return "Robot";
                break;

            case 0:
                return "Bannis";
                break;

            default:
                return "Membre";
                break;

        }
    }

    /**
     * Renvoie le nom de la class box-shadow
     *
     * @return string
     */
    public function getShadowBoxAttribute()
    {
        if ($this->hasBoutique("shadow_box")) {
            return shadowBoxName($this->rank, $this->sexe);

        } else {
            return "";
        }
    }

    /**
     * Créer une entrée dans mcoin et rajoute ou enlève au total de mcoins
     *
     * @param $value
     */
    public function changeMcoins($montant, $description, $save = false)
    {
        $this->mcoinsRelation()->save(new Mcoins(compact(['montant', 'description'])));

        $this->attributes['mcoins'] = $this->attributes['mcoins'] + $montant;

        if ($save) {
            $this->save();
        }
    }

    /**
     * Relation users <-> badges
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function badges()
    {
        return $this->belongsToMany(Badge::class, "badge_user", "user_id", "badge_id", "id", "nom_id")->withTimestamps();
    }

    /**
     * Relation user <- filleuls
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function filleuls()
    {
        return $this->hasMany(Parrainage::class, "parrain_id", "parrain_id");
    }

    /**
     * Relation user <- mcoins
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function mcoinsRelation()
    {
        return $this->hasMany(Mcoins::class, "user_id", "id");
    }

    /**
     * Relation user <- BoutiqueUser
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function boutiqueUser()
    {
        return $this->hasMany(BoutiqueUser::class, "user_id", "id");
    }

    /**
     * Relation user <- BoutiqueUser + notExpired
     *
     * @return Builder
     */
    public function boutiqueUserNotExpired()
    {
        return $this->boutiqueUser()->notExpired();
    }

    /**
     * Renvoie si l'utilisateur à l'objet boutique non expiré
     *
     * @param String $nom_id
     */
    public function hasBoutique(String $nom_id)
    {
        return $this->boutiqueUserNotExpired()->where("boutique_id", "=", $nom_id)->exists();
    }

    /**
     * Realtion user <- order
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function orders()
    {
        return $this->hasOne(Order::class);
    }


}
