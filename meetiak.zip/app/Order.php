<?php

namespace App;

use App\Traits\FormatCreatedAt;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use SoftDeletes;
    use FormatCreatedAt;

    /**
     * @var string
     */
    protected $table = 'orders';

    /**
     * @var array
     */
    protected $dates = ['deleted_at'];

    protected $fillable = ['transaction_id', 'accepted'];

    protected $hidden = ['user_id', 'accepted', "created_at"];


    /**
     * Format updated_at
     *
     * @return string
     */
    public function getUpdatedAtAttribute()
    {
        return Carbon::parse($this->attributes["updated_at"])->format("d/m/Y H:i");
    }

    /**
     * Relation Orders -> utilisateur
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, "user_id", "id");
    }

}
