<?php

namespace App\Providers;

use App\ForumCategory;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\ServiceProvider;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        Schema::defaultStringLength(191);
        Carbon::setLocale("fr");
        setlocale(LC_TIME, 'fr_FR.utf8') or setlocale(LC_TIME, 'French') or die("Local pas installé");


        //age:min,max
        //Vérifie que l'age soit entre min et max
        Validator::extend('age', function($attribute, $value, $parameters)
        {
            $minAge = ( ! empty($parameters)) ? (int) $parameters[0] : 13;
            $maxAge = ( ! empty($parameters)) ? (int) $parameters[1] : 99;
            $age = Carbon::now()->diff(new Carbon($value))->y;
            return  $age >= $minAge && $age <= $maxAge;

        });

        //Vérifie que la catégorie n'est pas lock
        Validator::extend('category_is_not_locked', function($attribute, $value, $parameters)
        {
            return  !(ForumCategory::findOrFail($value)->locked);
        });


    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {

    }
}
