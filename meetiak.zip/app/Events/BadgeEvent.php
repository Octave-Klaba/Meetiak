<?php

namespace App\Events;

use App\Badge;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class BadgeEvent
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $badgeId;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Badge $badge)
    {
        $this->badgeId = $badge->nom_id;
    }


}
