<?php

namespace App;

use App\Traits\FormatCreatedAt;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ForumPost extends Model
{
    use SoftDeletes, FormatCreatedAt;

    protected $hidden = ["updated_at", "deleted_at"];

    protected $appends = ["messages_count"];

    protected $fillable = ["title"];


    /**
     * Relation post <- user
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, "user_id", "id");
    }

    /**
     * Relation post -> Messages
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function messages()
    {
        return $this->hasMany(ForumMessage::class, "post_id", "id");
    }

    /**
     * Relation post -> catégorie
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function category()
    {
        return $this->belongsTo(ForumCategory::class, "id", "category_id");
    }

    /**
     * Renvoie le nombre de message
     *
     * @return int
     */
    public function getMessagesCountAttribute()
    {
        return $this->messages()->count();
    }

}
