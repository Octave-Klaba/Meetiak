<?php

namespace App;

use App\Traits\FormatCreatedAt;
use Illuminate\Database\Eloquent\Model;

class Mcoins extends Model
{
    use FormatCreatedAt;

    protected $table = "mcoins";

    protected $fillable = ["montant", "description"];

    protected $hidden = ["id", "user_id", "updated_at"];

    /**
     * Relation Mcoins -> utilisateur
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, "user_id", "id");
    }



}
