<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Reports extends Model
{
    public static function addReport($from_user, $to_user, $raison)
    {
        DB::table("reports")->insert(compact("from_user", "to_user", "raison"));
    }
}
