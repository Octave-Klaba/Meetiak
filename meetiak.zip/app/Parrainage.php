<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Parrainage extends Model
{

    /**
     * Relation filleul -> parrain
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function parrain()
    {
        return $this->belongsTo(User::class, "parrain_id", "parrain_id");
    }

    /**
     * Relation parrainage -> utilisateur
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, "user_id", "id");
    }
}
