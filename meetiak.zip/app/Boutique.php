<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Boutique extends Model
{
    protected $table = "boutique";

    protected $hidden = ["id", "nom_id", "html", "jours"];

    public function getHtmlAttribute()
    {
        switch ($this->attributes['html']) {
            case "pseudo_background":
                return pseudoUserColorLink(auth()->id(), "effet");
                break;

            case"shadow_box":
                $shadow_box = '<div class="rounded border-success border shadow-box m-2 p-2 ' . shadowBoxName(Auth::user()->rank, Auth::user()->sexe) . '">';
                $shadow_box .= pseudoUserColorLink(auth()->id());
                $shadow_box .= '</div>';

                return $shadow_box;
                break;

            case "":
                return "0";
                break;

            default:
                return $this->attributes['html'];
                break;
        }
    }

}
