<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Ban extends Model
{

    /**
     * Vérifie si l'ip est bannie
     *
     * @param $ip
     * @return bool
     */
    public static function isBanIP($ip)
    {
        return DB::table("ban_ip")->where("ip", "=", $ip)->exists();
    }

    /**
     * Vérifie si l'email est bannie
     *
     * @param $ip
     * @return bool
     */
    public static function isBanEmail($email)
    {
        return DB::table("ban_email")->where("email", "=", $email)->exists();
    }

}
