<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    protected $fillable = [
        'content', 'from_user', 'to_user', 'read_at', 'created_at'
    ];

    public $timestamps = false;

    protected $dates = ['created_at', 'read_at'];

    protected $with = ["from"];

    protected $appends = ["full_date"];

    /**
     * Renvoie le différence pour humain
     *
     * @param $value
     * @return string
     */
    public function getCreatedAtAttribute($value)
    {
        return ucfirst(Carbon::parse($value)->diffForHumans());
    }

    /**
     * Renvoie la date complete
     *
     * @return string
     */
    public function getFullDateAttribute()
    {
        return Carbon::parse($this->getOriginal("created_at"))->format("d/m/Y H:i:s");
    }

    public function from()
    {
        return $this->belongsTo(User::class, 'from_user');
    }

    public function to()
    {
        return $this->belongsTo(User::class, 'to_user');
    }
}
