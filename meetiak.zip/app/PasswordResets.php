<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class PasswordResets extends Model
{
    /**
     * Renvoie un token unique pour token
     *
     * @return bool|string
     */
    private static function generateToken()
    {
        do {
            $token = str_random(64);
        } while (DB::table("password_resets")->where("token", "=", $token)->exists());
        return $token;
    }

    /**
     * Ajoute une entrée et retourne token
     *
     * @param $email
     * @return bool|string
     */
    public static function addToken($email)
    {
        $token = self::generateToken();

        DB::table("password_resets")->insert(["email" => $email, "token" => $token]);

        return $token;
    }

    /**
     * Vérifie si le token existe
     *
     * @param $token
     * @return bool
     */
    public static function existToken($token)
    {
        return DB::table("password_resets")->where("token", "=", $token)->exists();
    }

    /**
     * Supprime une entrée
     *
     * @param $token
     */
    public static function deleteToken($token)
    {
        DB::table("password_resets")->where("token", "=", $token)->delete();
    }

    /**
     * Renvoie l'email associer au token
     *
     * @param $token
     * @return mixed
     */
    public static function getEmail($token)
    {
        return DB::table("password_resets")->where("token", "=", $token)->get(["email"])->first()->email;
    }
}
