<?php
/**
 * Created by PhpStorm.
 * User: Corentin
 * Date: 16/01/2018
 * Time: 17:35
 */

namespace App\Repository;

use App\Chat;
use Illuminate\Support\Facades\DB;

class ChatRepository extends Repository
{
    public $table = "chat";
    public $hasSoftDelete = true;

    /**
     * Renvoie les messages
     *
     * @param int $limit
     * @return \Illuminate\Support\Collection
     */
    public function getMessages($limit = 50)
    {
        return Chat::query()
            ->orderBy("created_at", "desc")
            ->limit($limit)
            ->get();
    }

    /**
     * Soft delete tout les messages
     */
    public function clear()
    {
        $this->getQuerySelect()->update(["deleted_at" => DB::raw("NOW()")]);

    }

}