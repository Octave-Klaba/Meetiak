<?php
/**
 * Created by PhpStorm.
 * User: Corentin
 * Date: 15/01/2018
 * Time: 17:58
 */

namespace App\Repository;

use Illuminate\Support\Facades\DB;

class Repository
{
    public $table;
    public $hasSoftDelete = false;


    /**
     * Renvoie DB:table(table)
     *
     * @return \Illuminate\Database\Query\Builder
     */
    public function getQuery()
    {
        return DB::table($this->table);
    }

    /**
     * Renvoie DB::table(table)->whereNull('deleted_at');
     *
     *
     */
    public function getQuerySelect()
    {
        if ($this->hasSoftDelete) {
            return $this->getQuery()->whereNull($this->table . '.deleted_at');
        } else {
            return $this->getQuery();
        }
    }

    /**
     * Renvoie tout les lignes
     *
     * @param int $limit
     * @param string $order
     * @param array $row
     * @return \Illuminate\Support\Collection
     */
    public function getAllRow($limit = 10000, $order = 'DESC', $row = ["*"])
    {
        return $this->getQuerySelect()->limit($limit)->orderBy("created_at", $order)->get($row);
    }

    /**
     * Renvoie le nombre de lignes
     *
     * @return int
     */
    public function count(): int
    {
        return $this->getQuerySelect()->count();
    }

    /**
     * Renvoie les colonnes correspondant à l'id
     *
     * @param $id
     * @param array $columns
     */
    public function find($id, $columns = ['*'])
    {
        return $this->getQuerySelect()->where("id", "=", $id)->first($columns);
    }

    /**
     * Renvoie les colonnes correspondant à $field = $value
     *
     * @param $field
     * @param $value
     * @param array $columns
     *
     * @return \Illuminate\Database\Eloquent\Model|\Illuminate\Database\Query\Builder
     */
    public function findWithField($field, $value, $columns = ['*'])
    {
        return $this->getQuerySelect()->where($field, "=", $value)->first($columns);
    }

    /**
     * Renvoie $columns correspondant à $field = $value
     *
     * @param $field
     * @param $value
     * @param array $columns
     * @return \Illuminate\Support\Collection
     */
    public function where($field, $value, $columns = ['*'])
    {
       return $this->getQuerySelect()->where($field, "=", $value)->get($columns);

    }

    /**
     * Renvoie Si la $value exist dans la colonne $field
     *
     * @param $field
     * @param $value bool
     */
    public function exist($field, $value)
    {
        return $this->getQuerySelect()->where($field, "=", $value)->exists();
    }

    /**
     * Créait une nouvelle ligne et renvoie son id
     *
     * @param $value
     * @return int
     */
    public function insert($value)
    {
        return $this->getQuery()->insertGetId($value);
    }

    /**
     * Change le(s) valeur(s) correspondant à l'id
     *
     * @param $id
     * @param $updateArray
     */
    public function update($id, $updateArray)
    {
        $this->getQuery()->where("id", "=", $id)->update($updateArray);
    }

    /**
     * Créait ou change le(s) valeur(s) correspondant à l'id
     *
     * @param $id
     * @param $updateArray
     */
    public function insertOrUpdate($id, $updateArray)
    {
        $this->getQuery()->updateOrInsert(["id" => $id], $updateArray);
    }

    /**
     * Créait ou change le(s) valeur(s) correspondant à $field = $value
     *
     * @param $id
     * @param $updateArray
     */
    public function insertOrUpdateWithField($field, $value, $updateArray)
    {
        $this->getQuery()->updateOrInsert([$field => $value], $updateArray);
    }

    /**
     * Change le(s) valeur(s) correspondant à $field = $value
     *
     * @param $id
     * @param $updateArray
     */
    public function updateWithField($field, $value, $updateArray)
    {
        $this->getQuery()->where($field, "=", $value)->update($updateArray);
    }

    /**
     * Supprime la ligne correspondant à l'id
     *
     * @param $id
     */
    public function delete($id)
    {
        $this->getQuery()->where("id", "=", $id)->delete();
    }

    /**
     * Rempli deleted_at
     *
     * @param $id
     */
    public function softDelete($id)
    {
        $this->getQuery()->where("id", "=", $id)->update(["deleted_at" => DB::raw("NOW()")]);
    }
}