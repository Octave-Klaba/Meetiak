<?php

namespace App\Repository;

use App\Message;
use App\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;


class ConversationRepository extends Repository
{

    public $table = "messages";

    /**
     * Renvoie le nombre de messages non lus envoyée par $other_user
     *
     * @param $auth_user
     * @param $other_user
     * @return int
     */
    public function getUnread($auth_user, $other_user)
    {
        return $this->getQuerySelect()
            ->where("from_user", $other_user)
            ->where("to_user", $auth_user)
            ->whereNull("read_at")
            ->count();
    }

    /**
     * Renvoie le nombres de messages non lus
     *
     * @param $auth_user
     *
     */
    public function getAllUnread($auth_user)
    {

        $users = $this->getQuerySelect()
            ->where("to_user", $auth_user)
            ->whereNull("read_at")
            ->get(["from_user"]);

        $i = 0;

        //Boucle sont amis
        foreach ($users as $user) {

            if (User::find($auth_user)->isFriendWith(User::find($user->from_user))) {

                $i++;
            }
        }

        return $i;
    }

    /**
     * Renvoie une liste de messages non lus par utilisateur, from_user => unread
     *
     * @param $auth_user
     * @return \Illuminate\Support\Collection
     */
    public function getAllUnreadByUser($auth_user)
    {
        return $this->getQuerySelect()
            ->where("to_user", $auth_user)
            ->whereNull("read_at")
            ->selectRaw("COUNT(id) AS unread, from_user")
            ->groupBy("from_user")
            ->get()
            ->pluck("unread", "from_user");
    }

    /**
     * Renvoie les messages
     *
     * @param $auth_user
     * @param $other_user
     * @return \Illuminate\Support\Collection
     */
    public function getMessage($auth_user, $other_user, $limit = 100)
    {
        //Update read_at
        $this->getQuerySelect()->where("from_user", $other_user)->where("to_user", $auth_user)->update(["read_at" => DB::raw("NOW()")]);

        return $messages = Message::query()
            ->where(function (Builder $query) use ($auth_user, $other_user) {

                $query->where(function (Builder $query) use ($auth_user, $other_user) {
                    $query->where("from_user", $auth_user)->where("to_user", $other_user);
                })
                    ->orWhere(function (Builder $query) use ($auth_user, $other_user) {
                        $query->where("from_user", $other_user)->where("to_user", $auth_user);
                    });

            })
            ->orderBy("created_at", "desc")
            ->limit($limit)
            ->get();

    }

}