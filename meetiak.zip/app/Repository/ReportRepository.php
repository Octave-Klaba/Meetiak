<?php
/**
 * Created by PhpStorm.
 * User: Corentin
 * Date: 18/01/2018
 * Time: 18:33
 */

namespace App\Repository;

class ReportRepository extends Repository
{
    public $table = "reports";
    public $hasSoftDelete = true;

    /**
     * Renvoie les derniers signalement
     *
     * @return \Illuminate\Support\Collection
     */
    public function getReport()
    {
        return $this->getQuerySelect()->selectRaw("usersFrom.pseudo AS from_pseudo, usersTo.pseudo AS to_pseudo, reports.*")
            ->leftJoin(\DB::raw("users AS usersFrom"), "usersFrom.id", "=", "reports.from_user")
            ->leftJoin(\DB::raw("users AS usersTo"), "usersTo.id", "=", "reports.to_user")
            ->latest()
            ->get();

    }

}