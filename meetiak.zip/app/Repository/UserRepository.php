<?php
/**
 * Created by PhpStorm.
 * User: Corentin
 * Date: 15/01/2018
 * Time: 17:48
 */

namespace App\Repository;

use App\Parrainage;
use App\User;
use Facades\Spatie\Referer\Referer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class UserRepository extends Repository
{
    public $table = "users";

    /**
     * Renvoie un token unique pour confirmation_token
     *
     * @return bool|string
     */
    private static function generateToken()
    {
        do {
            $token = str_random(32);
        } while (DB::table("users")->where("confirmation_token", "=", $token)->exists());
        return $token;
    }


    /**
     * Renvoie les derniers utilisateurs inscrit
     *
     * @param int $perPage Profils par page
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function getLastRegistered($perPage = 32)
    {
        return User::query()->whereNotNull("confirmed_at")->orderBy("confirmed_at", "desc")->paginate($perPage);
    }

    /**
     * Rajoute l'utilisateurs à la bdd et renvoie son confirmation_token
     *
     * @param $request
     * @return int
     */
    public function addUser(Request $request)
    {

        $token = static::generateToken();

        $id = $this->getQuery()->insertGetId([
            "pseudo" => $request->pseudo,
            "email" => $request->email,
            "password" => bcrypt($request->password),
            "ddn" => $request->ddn,
            "sexe" => $request->sexe,
            "departement" => $request->departement,
            "orientation" => $request->orientation,
            "confirmation_token" => $token,
            "last_ip" => \Request::ip(),
            "referer" => Referer::get(),
            "parrain_id" => createUniqueToken("users", "parrain_id", 20)
        ]);

        //Parrainage
        if ($request->hasCookie("parrain_id")) {
            $parrainage = new Parrainage;

            $parrainage->user_id = $id;
            $parrainage->parrain_id = $request->cookie("parrain_id");
            $parrainage->save();
        }

        return $token;

    }

    /**
     * Si un utilisateur avec le token existe renvoie son id dans ddb sinon renvoie -1
     *
     * @param $token
     * @return int|mixed
     */
    public function existConfirmationToken($token)
    {
        if ($this->getQuerySelect()->where("confirmation_token", "=", $token)->exists()) {
            return $this->getQuerySelect()->where("confirmation_token", "=", $token)->first(["id"])->id;
        } else {
            return -1;
        }
    }

    /**
     * Confirme l'email de l'utilisateur
     *
     * @param $token
     */
    public function updateConfirmed($token)
    {
        $this->getQuery()->where("confirmation_token", "=", $token)->update([
            "confirmed" => true,
            "confirmed_at" => DB::raw("NOW()"),
            "confirmation_token" => NULL
        ]);
    }

    /**
     * Change l'avatar de l'utilisateur et supprime l'ancien
     *
     * @param $id
     * @param $avatar
     */
    public function updateAvatar($id, $avatar)
    {
        if ($this->find($id, ['avatar'])->avatar !== "public/avatars/default.png") {
            Storage::delete($this->find($id, ['avatar'])->avatar);
        }

        $this->getQuery()->where("id", "=", $id)->update(["avatar" => $avatar]);
    }

    /**
     * Renvoie si l'utilisateur est en ligne depuis 5 min
     *
     * @param $id
     * @return bool
     */
    public function isOnline($id)
    {
        return $this->getQuerySelect()
                ->where("id", "=", $id)
                ->whereRaw("last_online > NOW() - INTERVAL 5 MINUTE")->count() == 1;
    }

    public function search($request)
    {

        $query = User::query()
            //->where("pseudo", "like", "%" . $request->pseudo . "%")
            ->whereRaw("pseudo LIKE CONVERT(? USING utf8mb4) COLLATE utf8mb4_unicode_ci", ["%" . $request->pseudo . "%"])
            ->where(function (\Illuminate\Database\Eloquent\Builder $query) use ($request) {

                //Sexe
                if ($request->homme) {
                    $query->orWhere("sexe", "=", 0);
                }
                if ($request->femme) {
                    $query->orWhere("sexe", "=", 1);
                }
                if ($request->autre) {
                    $query->orWhere("sexe", "=", 2);
                }

            });

        if ($request->departement !== "all") {
            $query->where("departement", "=", $request->departement);
        }

        if ($request->online) {
            $query->whereRaw("last_online > NOW() - INTERVAL 5 MINUTE");
        }

        return $query->whereBetween(DB::raw("TIMESTAMPDIFF(YEAR, ddn, CURDATE())"), [$request->min, $request->max])
            ->orderBy("pseudo", "ASC")
            ->get();
    }


}