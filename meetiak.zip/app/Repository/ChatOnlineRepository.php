<?php
/**
 * Created by PhpStorm.
 * User: Corentin
 * Date: 21/01/2018
 * Time: 13:41
 */

namespace App\Repository;


class ChatOnlineRepository extends Repository
{
    public $table = "chat_online";
    public $hasSoftDelete = false;

    /**
     * Renvoie le pseudo et l'id des personnes connecté depuis 15 min
     *
     * @return \Illuminate\Support\Collection
     */
    public function getOnlineUsers()
    {
        $users = $this->getQuerySelect()
            ->select(["chat_online.user", "users.pseudo"])
            ->join("users", "users.id", "=", "chat_online.user")
            ->whereRaw("chat_online.last_online > NOW() - INTERVAL 1 MINUTE")->get();

        //Pyxelle
        return $users->sort(function ($user1, $user2) {

            if ($user1->pseudo === "🤖 Pyxelle") {

                return -1;

            } elseif ($user2->pseudo === "🤖 Pyxelle") {

                return 1;

            } else {

                return 0;
            }
        });

    }

}