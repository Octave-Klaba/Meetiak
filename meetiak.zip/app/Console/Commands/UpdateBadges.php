<?php

namespace App\Console\Commands;

use App\Badge;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Schema;

class UpdateBadges extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update:badges';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Met à jour les badges';


    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Schema::disableForeignKeyConstraints();
        Badge::truncate();
        Schema::enableForeignKeyConstraints();

        $badges = require (__DIR__ . '../../../../badges.php');

        Badge::getQuery()->insert($badges);
    }
}
