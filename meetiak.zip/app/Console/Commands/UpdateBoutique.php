<?php

namespace App\Console\Commands;

use App\Boutique;
use Illuminate\Console\Command;
use Schema;

class UpdateBoutique extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update:boutique';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Met à jour la boutique.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Schema::disableForeignKeyConstraints();
        Boutique::truncate();
        Schema::enableForeignKeyConstraints();

        $badges = require (__DIR__ . '../../../../boutique.php');

        Boutique::getQuery()->insert($badges);
    }
}
