<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class BoutiqueUser extends Model
{
    protected $table = "boutique_users";

    protected $dates = ["expires_at"];

    protected $with = ["boutique"];

    protected $hidden = ["id", "user_id", "boutique_id", "updated_at"];

    protected $appends = ["expired"];

   // protected $dateFormat = "d/m/Y H:i";

    /**
     * Renvoie les non expirées
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeNotExpired(Builder $query)
    {
        return $query->where('expires_at', '>=', DB::raw("NOW()"));
    }

    /**
     * Renvoie si expiré
     *
     * @return bool
     */
    public function getExpiredAttribute()
    {
        return Carbon::now() > Carbon::parse($this->getOriginal("expires_at"));
    }

    /**
     * Format created_at
     *
     * @return string
     */
    public function getCreatedAtAttribute()
    {
        return Carbon::parse($this->attributes["created_at"])->format("d/m/Y H:i");
    }

    /**
     * Format expires_at
     *
     * @return string
     */
    public function getExpiresAtAttribute()
    {
        return Carbon::parse($this->attributes["expires_at"])->format("d/m/Y H:i");
    }

    /**
     * Relation Boutique <- BoutiqueUser
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function boutique()
    {
        return $this->belongsTo(Boutique::class, "boutique_id", "nom_id");
    }

}
