<?php

namespace App\Traits;

use Carbon\Carbon;

trait FormatCreatedAt
{
    /**
     * Format created_at
     *
     * @return string
     */
    public function getCreatedAtAttribute()
    {
        return Carbon::parse($this->attributes["created_at"])->format("d/m/Y H:i");
    }
}