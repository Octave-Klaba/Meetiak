<?php $__env->startSection("title", "419"); ?>

<?php $__env->startSection("content"); ?>
    <center><h1 style=" margin-top: 40vh; transform: translateY(-50%);">La session a expiré, merci de recharger la
                                                                        page.</h1></center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>