<?php $__env->startSection("title", "Amis"); ?>

<?php $__env->startSection("content"); ?>

    <div class="container">

        <nav class="nav nav-pills text-center justify-content-center">
            <a class="nav-link fl m-2 <?php echo e($page === "friends" ? "active bg-success" : ""); ?>"
               href="<?php echo e(url("friends")); ?>"><span class="<?php echo e($page === "friends" ? "" : "active green"); ?>">

                    <i class="fa fa-users" aria-hidden="true"></i></span>
                Amis</a>
            <a class="nav-link fl m-2 <?php echo e($page === "got" ? "active bg-success" : ""); ?>"
               href="<?php echo e(url("friends/requests/got")); ?>">

                <span class="<?php echo e($page === "got" ? "" : "active green"); ?>"><i class="fa fa-user-plus"
                                                                           aria-hidden="true"></i></span>
                Demandes
                d'amis reçu
                <?php if(getFriendsRequestCount() !== 0): ?>
                    <span class="badge badge-pill <?php echo e($page === "got" ? "active badge-light" : "active badge-success"); ?>">
                        <?php echo e(getFriendsRequestCount()); ?>

                    </span>
                <?php endif; ?>
            </a>
            <a class="nav-link fl m-2 <?php echo e($page === "sent" ? "active bg-success" : ""); ?>"
               href="<?php echo e(url("friends/requests/sent")); ?>">

                <span class="<?php echo e($page === "sent" ? "" : "active green"); ?>"><i class="fa fa-paper-plane"
                                                                            aria-hidden="true"></i></span>
                Demandes
                d'amis envoyées</a>
            <a class="nav-link fl m-2 <?php echo e($page === "blocked" ? "active bg-success" : ""); ?>"
               href="<?php echo e(url("friends/blocked")); ?>">

                <span class="<?php echo e($page === "blocked" ? "" : "active green"); ?>"><i class="fa fa-user-times"
                                                                               aria-hidden="true"></i></span>
                Utilisateurs
                bloqués</a>
        </nav>

        <div class="row">

            <?php if($friends->count() === 0): ?>

                <p class="text-center mx-auto my-3">
                    <?php echo e($page === "friends" ? "Vous n'avez pas d'amis." : ""); ?>

                    <?php echo e($page === "got" ? "Vous n'avez pas reçu de demande d'amis." : ""); ?>

                    <?php echo e($page === "sent" ? "Vous n'avez pas envoyé de demandes d'amis." : ""); ?>

                    <?php echo e($page === "blocked" ? "Vous n'avez pas bloqué d'utilisateurs." : ""); ?>

                </p>
            <?php endif; ?>

            <?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-12">
                    <div class="m-2 p-2 border border-success rounded row align-items-center">

                        <div class="col-12 col-md-3 text-center">
                            <img class="m-2 rounded-circle img-responsive"
                                 src="<?php echo e(\Illuminate\Support\Facades\Storage::url($friend->avatar)); ?>"
                                 style="width: 60px; height: 60px">
                        </div>

                        <div class="col-12 col-md-3 text-center">
                        <?php echo $friend->link; ?>

                        <?php echo $friend->is_online_dot; ?>


                        <!-- Sexe -->
                            <?php echo $friend->sexe_icon; ?>

                        </div>

                        <div class="col-12 col-md-3 text-center">
                            <?php echo e($friend->age); ?>

                            ans

                        </div>

                        <div class="col-12 col-md-3 text-center">
                            <?php echo e($friend->departement_nom); ?> (<?php echo e($friend->departement); ?>)

                        </div>

                        <!-- Boutons -->
                        <div class="col-12 col-md-12 text-center text-md-right">
                            <div class="btn-group">

                                <?php if($page === "friends"): ?>
                                    <a class="btn btn-success" href="<?php echo e(url("conversations/".$friend->id)); ?>">
                                        Écrire
                                    </a>
                                    <a href="<?php echo e(url("friends/delete?id=".$friend->id)); ?>" class="btn btn-danger">
                                        Supprimer
                                    </a>
                                <?php endif; ?>

                                <?php if($page === "got"): ?>
                                    <a href="<?php echo e(url("friends/requests/accept?id=".$friend->id)); ?>"
                                       class="btn btn-success">
                                        Accepter
                                    </a>
                                    <a href="<?php echo e(url("friends/requests/ignore?id=".$friend->id)); ?>" class="btn btn-danger">
                                        Supprimer
                                    </a>
                                <?php endif; ?>

                                <?php if($page === "sent"): ?>
                                    <a href="<?php echo e(url("friends/requests/remove/sent?id=".$friend->id)); ?>"
                                       class="btn btn-danger">
                                        Supprimer
                                    </a>
                                <?php endif; ?>

                                <?php if($page === "blocked"): ?>
                                    <a href="<?php echo e(url("friends/unblock?id=".$friend->id)); ?>" class="btn btn-success">
                                        Débloquer
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="profile-ads1 text-center">
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <!-- pubsoustchat -->
                    <ins class="adsbygoogle"
                         style="display:inline-block;width:728px;height:90px"
                         data-ad-client="ca-pub-7690571679670706"
                         data-ad-slot="5236342360"></ins>
                    <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
        </div>
        <?php echo e($friends->links()); ?>


    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>