<?php $__env->startSection("title", "Profil de " .$user->pseudo); ?>

<?php $__env->startSection("content"); ?>

    <?php echo $__env->make("user.signaler", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Début de page -->
    <?php  /**@var App\User $user */ ?>
    <div class="container">

        <?php echo $__env->make("layouts.errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row profile">

            <div class="col col-xl-3">
                <div class="profile-sidebar <?php echo e($user->shadow_box); ?>">
                
                <!-- SIDEBAR USERPIC -->
                    <div class="profile-userpic">
                        <div class="center">
                            <img src="<?php echo e($user->avatar_link); ?>">
                        </div>
                    </div>
                    <!-- END SIDEBAR USERPIC -->
                    <!-- SIDEBAR USER TITLE -->
                    <div class="profile-usertitle">
                        <div class="profile-usertitle-name">
                            <!-- Pseudo -->
                        <?php echo $user->pseudo_style; ?>


                        <?php echo $user->is_online_dot; ?>


                        <!-- Sexe -->
                            <?php echo $user->sexe_icon; ?>


                        </div>
                        <div class="profile-usertitle-job">
                            <!-- Titre -->
                            <?php echo e($user->titre); ?>

                        </div>
                    </div>
                    <!-- END SIDEBAR USER TITLE -->
                    <!-- SIDEBAR BUTTONS -->
                    <div class="profile-userbuttons d-flex flex-column flex-md-row flex-wrap justify-content-center">

                        
                        <?php if(auth()->check() && App\User::find(auth()->id())->id != $id): ?>

                            
                            <?php if($user->isFriendWith(App\User::find(auth()->id()))): ?>
                                <a class="btn btn-success btn-sm m-2" href="<?php echo e(url("conversations/".$user->id)); ?>">
                                    Écrire
                                </a>

                                
                            <?php elseif($user->isBlockedBy(App\User::find(auth()->id()))): ?>
                                <p class="w-100">Vous avez bloqué cette utilisateur.</p>

                                
                            <?php elseif($user->hasFriendRequestFrom(App\User::find(auth()->id()))): ?>
                                <p class="w-100 text-center">Vous avez déjà envoyé une demande d'ami.</p>

                                
                            <?php elseif($user->hasSentFriendRequestTo(App\User::find(auth()->id()))): ?>
                                <p class="w-100 text-center"><?php echo e($user->pseudo); ?> vous a envoyé une demande d'ami</p>
                                <a href="<?php echo e(url("friends/requests/accept?id=".$user->id)); ?>" class="btn btn-success">
                                    Accepter
                                </a>

                                
                            <?php else: ?>
                                <?php if($user->rank < 6): ?>
                                    <a href="<?php echo e(url("friends/requests/send?id=".$id)); ?>"
                                       class="btn btn-success btn-sm m-2">Envoyer
                                                                          une demande d'ami
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if($user->rank <= 2 && ! $user->isBlockedBy(App\User::find(auth()->id()))): ?>
                                <a href="<?php echo e(url("block?id=".$id)); ?>" class="btn btn-danger btn-sm m-2">Bloquer
                                                                                                     l'utlisateur
                                </a>
                            <?php endif; ?>

                            <?php if($user->rank < 3): ?>
                                <button type="button"
                                        class="btn btn-danger btn-sm m-2"
                                        data-toggle="modal"
                                        data-target="#modalSignaler">
                                    Signaler
                                </button>
                            <?php endif; ?>

                        <?php endif; ?>
                        <br>
                        
                        <?php if(auth()->check() && App\User::find(auth()->id())->id == $id): ?>
                            <a href="<?php echo e(url("account")); ?>" class='btn btn-success btn-sm m-2'>Éditer
                                                                                            mon
                                                                                            profil
                            </a>
                        <?php endif; ?>
                    </div>
                    <!-- END SIDEBAR BUTTONS -->
                    <!-- SIDEBAR MENU -->
                    <div class="profile-usermenu">
                        <hr>

                        <div class="center"><?php echo e($user->departement_nom); ?> (<?php echo e($user->departement); ?>)</div>
                        <div class="center">
                            <?php echo e($user->age); ?> ans
                        </div>
                        <div class="center"><?php echo e($user->orientation_nom); ?></div>
                        <div class="center">
                            <!-- Statut -->
                            <?php echo e($user->statut_nom); ?>

                        </div>
                        <hr>
                        <div class="center">
                        
                        <?php if(auth()->check()): ?>
                            <!-- Facebook -->
                                <?php if(!empty($user->facebook)): ?>
                                    <a href="https://www.facebook.com/<?php echo e($user->facebook); ?>" target="_blank">
                                        <font size="6px" color="#29487d"><i class="fab fa-facebook-square"
                                                                            aria-hidden="true"></i></font></a>
                                <?php endif; ?>

                            <!-- Youtube -->
                                <?php if(!empty($user->youtube)): ?>
                                    <a href="https://www.youtube.com/channel/<?php echo e($user->youtube); ?>" target="_blank">
                                        <font size="6px" color="#ff0000"><i class="fab fa-youtube"
                                                                            aria-hidden="true"></i></font></a>
                                <?php endif; ?>

                            <!-- Snapchat -->
                                <?php if(!empty($user->snapchat)): ?>
                                    <a href="https://snapchat.com/add/<?php echo e($user->snapchat); ?>" target="_blank">
                                        <font size="6px" color="#FFFC00"><i class="fab fa-snapchat-square"
                                                                            aria-hidden="true"></i></font></a>
                                <?php endif; ?>

                            <!-- Steam -->
                                <?php if(!empty($user->steam)): ?>
                                    <a href="https://steamcommunity.com/id/<?php echo e($user->steam); ?>" target="_blank">
                                        <font size="6px" color="#000"><i class="fab fa-steam"
                                                                         aria-hidden="true"></i></font></a>
                                <?php endif; ?>

                            <!-- Twitter -->
                                <?php if(!empty($user->twitter)): ?>
                                    <a href="https://twitter.com/<?php echo e($user->twitter); ?>" target="_blank">
                                        <font size="6px" color="#1da1f2"><i class="fab fa-twitter-square"
                                                                            aria-hidden="true"></i></font></a>
                                <?php endif; ?>

                            <!-- Twitch -->
                                <?php if(!empty($user->twitch)): ?>
                                    <a href="https://twitch.tv/<?php echo e($user->twitch); ?>" target="_blank">
                                        <font size="6px" color="#4b367c"><i class="fab fa-twitch"
                                                                            aria-hidden="true"></i></font></a>
                                <?php endif; ?>

                            <!-- Instagram -->
                                <?php if(!empty($user->instagram)): ?>
                                    <a href="https://www.instagram.com/<?php echo e($user->instagram); ?>" target="_blank">
                                        <font size="6px" color="#E70195"><i class="fab fa-instagram"
                                                                            aria-hidden="true"></i></font></a>
                                <?php endif; ?>
                            <?php else: ?>
                                <p>Veuillez vous <a href="<?php echo e(url("auth/login")); ?>">connecter</a> pour voir les réseaux
                                   sociaux de cet utilisateur.</p>
                            <?php endif; ?>


                        </div>
                    </div>
                    <!-- END MENU -->
                </div>

                <div class="center"><!-- Ban button -->
                <?php if(auth()->check() && App\User::find(auth()->id())->rank >= 4): ?>
                    <!-- TODO Ajouté lien -->
                        <div class='ban my-2'>
                            <a role='button' class='btn btn-danger btn-sm m-2'>Bannir</a></div>
                    <?php endif; ?>
                </div>

                <div class="center ads my-2">
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <!-- profilgauche -->
                    <ins class="adsbygoogle"
                         style="display:block"
                         data-ad-client="ca-pub-7690571679670706"
                         data-ad-slot="4031959955"
                         data-ad-format="auto"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>


            </div>


            <div class="col col-xl-9">
                <div class="profile-content">
                    <h3>Description :</h3>
                    <!-- Description -->
                    <?php echo clean($user->description); ?>

                    <hr>
                    <div class="m-2">
                        <?php $__currentLoopData = $user->badges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset($badge->image)); ?>"
                                 alt="<?php echo e($badge->nom); ?>"
                                 class="m-1 img-thumbnail img-badge"
                                 title="<?php echo e($badge->nom); ?>"
                                 data-toggle="popover"
                                 data-trigger="hover"
                                 data-placement="bottom"
                                 data-content="<?php echo e($badge->description); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php if(isset($user->confirmed_at) && !empty($user->confirmed_at)): ?>
                        <div class="center">
                            <small>Inscrit le :
                                <?php echo e(\Carbon\Carbon::parse($user->confirmed_at)->format("d/m/Y")); ?></small>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="profile-ads1 text-center">
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <!-- pubsousprofil -->
                    <ins class="adsbygoogle"
                         style="display:inline-block;width:728px;height:90px"
                         data-ad-client="ca-pub-7690571679670706"
                         data-ad-slot="5975118085"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
    <script>
        $(function () {
            $("[data-toggle=\"popover\"]").popover();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>