<?php $__env->startSection("title", "Forum"); ?>

<?php $__env->startSection("content"); ?>

    <div class="container" id="app">

        <transition name="fade" mode="out-in">
            <router-view></router-view>
        </transition>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
    <script>
        var _token = <?php echo json_encode(csrf_token()); ?>;

        var tiltleEnd = " - Meetiak site de rencontre pour ados gratuit !";

        var categoriesPosts = <?php echo json_encode($categories); ?>;

        var getPostUrl = <?php echo json_encode(url("forum/get/post")); ?>;
        var getCategoryUrl = <?php echo json_encode(url("forum/get/category")); ?>;
        var CreateUrl = <?php echo json_encode(url("forum/create/post")); ?>;
        var CreateMessageUrl = <?php echo json_encode(url("forum/create/message")); ?>;
    </script>

    <script src="<?php echo e(asset("js/forum.js")); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("css"); ?>
    <style>
        .fade-enter-active {
            animation: fadeIn 0.5s;
        }

        .fade-leave-active {
            animation: fadeOut 0.5s;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>