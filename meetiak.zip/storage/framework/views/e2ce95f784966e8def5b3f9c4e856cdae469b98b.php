<?php $__env->startSection("title", "Chat"); ?>

<?php $__env->startSection("content"); ?>

    <div class="container" id="app" v-cloak>

        <div class="row">
            <div class="col-md-9">
                <div class="card">

                    <div class="card-header">
                        Chat
                    </div>

                    <div class="card-body chat-body" id="chat-body">

                        <div v-for="(message, key) in messages" :key="message['id']">
                            <div class="media"
                                 :class="{'flex-row-reverse' : message['user_id'] === <?php echo e(auth()->user()->id); ?> }">
                                <!-- Avatar -->
                                <a :href=" '<?php echo e(url("user") . "/"); ?>' + message['user_id']">
                                    <img class="align-self-center mx-1 mx-md-3 rounded-circle"
                                         :src="message.user['avatar_link']"
                                         style="width: 64px; height: 64px">
                                </a>
                                <div class="media-body">


                                    <h5 class="mt-0"
                                        :class="{'text-right' : message['user_id'] === <?php echo e(auth()->user()->id); ?> }">
                                        <span v-html="message.user['link']"></span>
                                        <i>
                                            <small v-text="message['created_at']"
                                                   data-toggle="tooltip"
                                                   data-placement="top"
                                                   :title="message['full_date']"></small>
                                        </i>
                                    </h5>
                                    <p class="word-break"
                                       :class="{'text-right' : message['user_id'] === <?php echo e(auth()->user()->id); ?> }">
                                        {{ message["message"] }} </p>
                                </div>

                                <?php if(auth()->user()->rank >= 4): ?>
                                    <button class="align-self-center btn btn-danger btn-sm"
                                            href="#"
                                            @click="deleteMessage(message['id'])">
                                        <i class="ml-auto fa fa-trash" aria-hidden="true"></i>
                                    </button>
                                <?php endif; ?>
                            </div>
                            <hr v-show="++key !== messages.length">

                        </div>

                    </div>
                    <div class="card-footer">

                        <!-- Envoyer -->
                        <form class="form-inline" @submit.prevent="sendMessage">
                            <label class="sr-only" for="message">Name</label>
                            <input type="text"
                                   class="form-control mb-2 mr-sm-2 chat-input"
                                   id="message"
                                   placeholder="Message"
                                   required
                                   autocomplete="off"
                                   v-model="messageInput">

                            <button type="submit" class="btn btn-success mb-2">Envoyer</button>
                        </form>

                    </div>

                </div>
            </div>

            <div class="col-md-3">
                <!-- UsersOnline -->
                <h4> Connectés : </h4>
                <div class="d-flex flex-column flex-md-row flex-wrap">
            <span v-for="user in usersOnline"
                  v-html="user['link']"
                  class="border border-success rounded text-center m-2 p-2"></span>
                </div>
            </div>
        </div>

        <div class="alert alert-danger text-center m-2" role="alert" v-if="hasError">
            <h4 class="alert-heading">Erreur</h4>
            <strong v-text="errorMessage"></strong>
        </div>

        <?php if(auth()->user()->rank >= 5): ?>
            <div class="row align-items-center justify-content-center">
                <button class="btn btn-danger m-2" @click="clearChat">Vider</button>
            </div>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
    <script>
        var chatGetUrl = "<?php echo e(url("chat/get")); ?>";
        var chatAddUrl = "<?php echo e(url("chat/add")); ?>";

                <?php if(auth()->user()->rank >= 4): ?>
        var chatDeleteUrl = "<?php echo e(url("chat/delete")); ?>";
                <?php endif; ?>

                <?php if(auth()->user()->rank >= 5): ?>
        var chatClearUrl = "<?php echo e(url("chat/clear")); ?>";
                <?php endif; ?>

        var _token = "<?php echo e(csrf_token()); ?>";
    </script>
    <script src="<?php echo e(url("js/chat.js")); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>