<?php $__env->startSection("title", "Parrainage"); ?>

<?php $__env->startSection("content"); ?>

    <div class="container">
        <!-- Info -->
        <article class="text-center">

            <h3>Parrainage</h3>
            <p class="small">Vous gagnerez <?php echo e(PARRAIN_MCOINS); ?> MCoins lorsqu'un filleul valide son email, le filleul
                             gagnera <?php echo e(FILLEUL_MCOINS); ?> MCoins.</p>

            <div class="form-group">
                <label for="parrain">Lien de parrainage</label>
                <input type="text"
                       class="form-control"
                       id="parrain"
                       aria-describedby="parrain-help"
                       readonly
                       value="<?php echo e(url("") . "/?p=" . Auth::user()->parrain_id); ?>">
                <small id="parrain-help" class="form-text text-muted">Donner ce lien aux personnes que vous voulez
                                                                      parrainer.
                </small>
            </div>

            <hr>

            <h3>Filleuls</h3>
            <?php if(Auth::user()->filleuls()->count() > 0): ?>

                <?php $__currentLoopData = Auth::user()->filleuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filleul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php /**@var \App\Parrainage $filleul*/?>

                    <div class="row align-items-center border border-success rounded">

                        <div class="col-6">
                            <div class="rounded m-2 p-2"><?php echo $filleul->user->link; ?></div>
                        </div>

                        <div class="col-6">
                            <div class="rounded m-2 p-2"><?php echo e($filleul->user->confirmed ? "Email vérifié." : "Email non vérifié."); ?></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>

                Vous n'avez pas de filleuls

            <?php endif; ?>

        </article>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>