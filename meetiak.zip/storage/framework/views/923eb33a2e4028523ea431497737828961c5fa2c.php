<?php $__env->startSection("title", "Connection"); ?>

<?php $__env->startSection("content"); ?>

    <br>
    <div class="container">
        <h1>Se connecter</h1>
        <form action="<?php echo e(url("auth/login")); ?>" method="post">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <?php echo $__env->make("layouts.errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" class="form-control" value="<?php echo e(old("email")); ?>" required/>
            </div>

            <div class="form-group">
                <label for="password">Mot de passe <a href="<?php echo e(url("auth/forgot")); ?>">(Mot de passe oublié ?)</a></label>
                <input type="password" id="password" name="password" class="form-control" required/>
            </div>

            <div class="form-group">
                <label>
                    <input type="checkbox" name="remember" value="1"/>Se souvenir de moi
                </label>
            </div>

            <button type="submit" class="btn btn-outline-success my-2 my-sm-0">Me connecter
            </button>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>