<?php use Illuminate\Support\Facades\Session; ?>



<?php $__env->startSection("title", "Rechercher"); ?>

<?php $__env->startSection("content"); ?>

    <div class="container" id="app" v-cloak>
        <div class="border border-success rounded p-1 justify-content-center">
            <!-- Form -->
            <form class="form-inline">

                <label class="sr-only" for="pseudo">Pseudo</label>
                <input type="text" class="form-control m-1" id="pseudo" v-model="pseudo" placeholder="Pseudo">

                <!-- Sexe -->
                <div class="form-check form-check-inline m-1">
                    <input class="form-check-input" type="checkbox" id="homme" v-model="homme" value="0">
                    <label class="form-check-label" for="homme">Homme</label>
                </div>

                <div class="form-check form-check-inline m-1">
                    <input class="form-check-input" type="checkbox" id="femme" v-model="femme" value="1">
                    <label class="form-check-label" for="femme">Femme</label>
                </div>

                <div class="form-check form-check-inline m-1">
                    <input class="form-check-input" type="checkbox" id="autre" v-model="autre" value="2">
                    <label class="form-check-label" for="autre">Autre</label>
                </div>

                <!-- Departements -->
                <label class="sr-only" for="departement">Département</label>
                <select class="form-control m-1" v-model="departement" id="departement">

                    <option value="all">Tous les départements
                    </option>
                    <?php $__currentLoopData = getDepartements(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($dep); ?>

                            (<?php echo e($key); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </select>

                <!-- Age slider -->
                <div class="m-1 custom-control">
                    <div id="slider" style="margin: 20px; min-width: 200px;"></div>
                    <span class="small text-center">De {{min}} ans à {{max}} ans</span>
                </div>

                <div class="form-check form-check-inline m-1">
                    <input class="form-check-input" type="checkbox" id="online" v-model="online" value="2">
                    <label class="form-check-label" for="online">En ligne</label>
                </div>

            </form>

            <div class="text-center text-danger" v-if="error">Erreur</div>
            <div class="text-center text-warning" v-if="isEmpty">Aucun résultat</div>
        </div>
        <!-- Spinner-->
        <div v-if="loading" class="d-flex justify-content-center align-items-center m-2" style="min-height: 50vw">
            <i class="fas fa-spinner fa-spin fa-5x green"></i>
        </div>

        <div class="row">

            <div class="col-12 col-md-6" v-for="user in users" :key="user['id']">

                <div class="border border-success rounded p-2 m-2 row bg-body" :class="user['shadow_box']">
                    <img class="align-self-center mr-3 rounded-circle img-responsive"
                         :src="user['avatar_link']"
                         style="width: 60px; height: 60px">

                    <div class="row col">
                        <div class="col-6">
                            <div v-html="user['link'] + user['is_online_dot']" class="text-center"></div>
                            <div class="text-center">{{ user['age'] }} ans</div>
                        </div>

                        <div class="col-6">
                            <div class="text-center" v-html="user['sexe_icon']"></div>
                            <div class="text-center">{{ user['departement_nom'] }}
                                                     ({{ user['departement'] }})
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

        

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/11.0.3/nouislider.min.js"></script>

    <script>
        var _token = "<?php echo e(csrf_token()); ?>";
        var searchUrl = "<?php echo e(url("search/ajax")); ?>";

        var search_pseudo = "<?php echo e(Session::get("search_pseudo", "")); ?>";

        var search_homme = "<?php echo e(Session::get("search_homme", true)); ?>";
        var search_femme = "<?php echo e(Session::get("search_femme", true)); ?>";
        var search_autre = "<?php echo e(Session::get("search_autre", true)); ?>";

        var search_departement = "<?php echo e(Session::get("search_departement", "all")); ?>";

        var search_min = "<?php echo e(Session::get("search_min", 13)); ?>";
        var search_max = "<?php echo e(Session::get("search_max", 99)); ?>";

        var search_online = "<?php echo e(Session::get("search_online", false)); ?>";

    </script>
    <script src="<?php echo e(url("js/search.js")); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("css"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/11.0.3/nouislider.min.css"/>

<?php $__env->stopPush(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>