<?php $__env->startSection("title", "MP de " .$user->pseudo); ?>

<?php $__env->startSection("content"); ?>

    <?php  /**@var App\User $user */ ?>
    <div class="container">
        <div class="row">

            <?php echo $__env->make('conversations.users', compact("friends"), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-9" id="app">
                <div class="card-header">
                    <a href="<?php echo e(url("user/".$user->id)); ?>">

                        <img class="photoconversationlittle" src="<?php echo e($user->avatar_link); ?>"/>
                        <?php echo $user->pseudo_style; ?>


                    </a>
                </div>

                <div class="card-body conversations">
                    <messages :self-id="<?php echo e(auth()->id()); ?>" v-cloak></messages>

                    <form @submit.prevent="sendMessage">
                        <div class="form-group">
                            <input type="text"
                                   name="content"
                                   placeholder="Votre message ici..."
                                   class="form-control"
                                   v-model="messageInput"
                                   autocomplete="off">

                        </div>
                        <button class="btn btn-success" type="submit">Envoyer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush("scripts"); ?>
        <script>
            var _token = "<?php echo e(csrf_token()); ?>";
            var getMessagesUrl = "<?php echo e(url("conversations/". $user->id ."/get")); ?>";
            var addMessagesUrl = "<?php echo e(url("conversations/". $user->id ."/add")); ?>";
        </script>
        <script src="<?php echo e(asset("js/conversation.js")); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>