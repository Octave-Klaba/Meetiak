<!-- Modal Signaler-->

<div class="modal fade" id="modalSignaler" tabindex="-1" role="dialog">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Signaler</h5>

                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>

                </button>
            </div>

            <!-- Form -->
            <form action="<?php echo e(url("user/report")); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="toUser" value="<?php echo e($user->id); ?>">
                <div class="modal-body">


                    <div class="form-group">
                        <p>
                            <small>Merci de donner dans votre signalement un maximum de détails (l'heure, la date,
                                   etc...)
                            </small>
                        </p>
                        <label for="raison">Raison : </label>
                        <textarea class="form-control" name="raison" id="raison" rows="3" required></textarea>
                    </div>


                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        Fermer
                    </button>

                    <button type="submit" class="btn btn-success">Envoyer
                    </button>


                </div>
            </form>
        </div>
    </div>
</div>