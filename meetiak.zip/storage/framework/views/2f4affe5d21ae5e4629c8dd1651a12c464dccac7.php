<div class="col-md-3">
    <div class="list-group my-2" id="users-list">

        <?php if($friends->count() === 0): ?>
            <p class="text-center mx-auto my-2">Ajouter des amis pour pouvoir discuter.</p>
        <?php endif; ?>

        <?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as /** @var App\User $friend */$friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a class="list-group-item d-flex justify-content-between align-items-center"
               href="<?php echo e(route('conversations.show', $friend->id)); ?>">

                <img class="photoconversationlittle" src="<?php echo e($friend->avatar_link); ?>"/>
                <?php echo $friend->pseudo_style; ?>


                <span class="badge badge-pill badge-success"
                      v-if="unread[ <?php echo e($friend->id); ?> ] > 0"
                      v-text="unread[ <?php echo e($friend->id); ?> ]">

                    </span>

            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

<?php $__env->startPush("scripts"); ?>

    <script>var unreadUrl = "<?php echo e(url("conversations/unread/all/user")); ?>";</script>
    <script src="<?php echo e(asset("js/conversations-users-unread.js")); ?>"></script>

<?php $__env->stopPush(); ?>
