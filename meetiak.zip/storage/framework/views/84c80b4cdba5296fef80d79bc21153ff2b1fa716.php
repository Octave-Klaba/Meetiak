<?php $__env->startSection("title", "Page d'accueil"); ?>

<?php $__env->startSection("content"); ?>
    <div class="center"><h1>Nos derniers inscrits !</h1></div>



    <div class="container">
        <div class="row align-items-center">
            <?php $__currentLoopData = $lastReg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as /**@var App\User $reg */$reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="profile-sidebar col col-md-2 m-2">


                    <!-- SIDEBAR USERPIC -->
                    <div class="profile-userpic">
                        <div class="center"><img src="<?php echo e($reg->avatar_link); ?>"></div>
                    </div>
                    <div class="profile-usertitle">
                        <div class="profile-usertitle-name">

                            <!-- Pseudo -->
                        <?php echo $reg->link; ?>

                        <?php echo $reg->is_online_dot; ?>


                        <!-- Sexe -->
                            <?php echo $reg->sexe_icon; ?>


                            <div class="center"><?php echo e($reg->age); ?>

                                ans
                            </div>
                            <div class="center"><?php echo e($reg->departement_nom); ?> (<?php echo e($reg->departement); ?>)</div>
                        </div>
                    </div>
                    <!-- END SIDEBAR USER TITLE -->
                    <!-- SIDEBAR BUTTONS -->
                    <div class="profile-userbuttons">
                        <a href="<?php echo e(url("user/".$reg->id)); ?>">
                            <button type="button" class="btn btn-success btn-sm">Voir le profil
                            </button>
                        </a>
                        <br>
                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="profile-ads1 text-center">
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <!-- pubsoustchat -->
                    <ins class="adsbygoogle"
                         style="display:inline-block;width:728px;height:90px"
                         data-ad-client="ca-pub-7690571679670706"
                         data-ad-slot="5236342360"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
        </div>
        <?php echo e($lastReg->links()); ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>