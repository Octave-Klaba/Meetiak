<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Omnes">
    <link rel="icon" href="favicon.ico">

    <title><?php echo $__env->yieldContent("title", ""); ?> - Meetiak site de rencontre pour ados gratuit !</title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(url("/favicon/apple-icon-57x57.png")); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(url("/favicon/apple-icon-60x60.png")); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(url("/favicon/apple-icon-72x72.png")); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(url("/favicon/apple-icon-76x76.png")); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(url("/favicon/apple-icon-114x114.png")); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(url("/favicon/apple-icon-120x120.png")); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(url("/favicon/apple-icon-144x144.png")); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(url("/favicon/apple-icon-152x152.png")); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url("/favicon/apple-icon-180x180.png")); ?>">
    <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(url("/favicon/android-icon-192x192.png")); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url("/favicon/favicon-32x32.png")); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(url("/favicon/favicon-96x96.png")); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url("/favicon/favicon-16x16.png")); ?>">
    <link rel="manifest" href="<?php echo e(url("/favicon/manifest.json")); ?>">
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(url("/favicon/ms-icon-144x144.png")); ?>">
    <meta name="theme-color" content="#ffffff">
    <!-- COMMON TAGS -->
    <meta charset="utf-8">
    <!-- Search Engine -->
    <meta name="description"
          content="MeetiaK est un site de rencontre gratuit ouvert à tous, à partir de 13 ans, un système semi-rp, des niveaux, une monnaie virtuelle, des badges, et pleins d'autres choses à faire !">
    <meta name="image" content="https://image.noelshack.com/fichiers/2018/04/5/1517000404-logo.png">
    <!-- Schema.org for Google -->
    <meta itemprop="name" content="MeetiaK">

    <meta name="keywords"
          content="entre ados, rencontre ado, rencontre ados, site de rencontre, rencontre, ado, forum, tchat, discussion, jeune, ados, gratuit, fille, garçon, amour, meetiak">
    <meta itemprop="description"
          content="MeetiaK est un site de rencontre gratuit ouvert à tous, à partir de 13 ans, un système semi-rp, des niveaux, une monnaie virtuelle, des badges, et pleins d'autres choses à faire !">

    <meta itemprop="image" content="https://image.noelshack.com/fichiers/2018/04/5/1517000404-logo.png">
    <!-- Open Graph general (Facebook, Pinterest & Google+) -->
    <meta name="og:title" content="MeetiaK">
    <meta name="og:description"
          content="MeetiaK est un site de rencontre gratuit ouvert à tous, à partir de 13 ans, un système semi-rp, des niveaux, une monnaie virtuelle, des badges, et pleins d'autres choses à faire !">

    <meta name="og:image" content="https://www.noelshack.com/2018-04-5-1517000596-mediafb.png">
    <meta name="og:url" content="https://meetiak.com">
    <meta name="og:site_name" content="MeetiaK">
    <meta name="og:locale" content="fr-FR">
    <meta name="fb:admins" content="100014246352183">
    <meta name="og:type" content="website">

    <meta name="theme-color" content="#028a74"/>

    <noscript id="deferred-styles">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css"/>
        <!-- Cookies -->
        <link rel="stylesheet"
              type="text/css"
              href="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.0.3/cookieconsent.min.css"/>

        <link rel="stylesheet" href="<?php echo e(asset("css/animate.min.css")); ?>">

        <?php echo $__env->yieldPushContent("css"); ?>
    </noscript>

    <link href="<?php echo e(asset("/css/style.css")); ?>" rel="stylesheet">

    <!-- Deferred styles -->
    <script>
        var loadDeferredStyles = function () {
            var addStylesNode = document.getElementById("deferred-styles");
            var replacement = document.createElement("div");
            replacement.innerHTML = addStylesNode.textContent;
            document.body.appendChild(replacement);
            addStylesNode.parentElement.removeChild(addStylesNode);
        };
        var raf = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
            window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
        if (raf) raf(function () {
            window.setTimeout(loadDeferredStyles, 0);
        });
        else window.addEventListener("load", loadDeferredStyles);
    </script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-114414235-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag("js", new Date());

        gtag("config", "UA-114414235-1");
    </script>

</head>

<body>


<div class="content">

    <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a class="navbar-brand" href="<?php echo e(url("/")); ?>">
            <span class="green">M</span>eetia<span class="green">K</span></a>
        <button class="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarsExampleDefault"
                aria-controls="navbarsExampleDefault"
                aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar -->
        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <?php if(auth()->check()): ?>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle"
                           href="#"
                           id="navbarDropdown"
                           role="button"
                           data-toggle="dropdown"
                           aria-haspopup="true"
                           aria-expanded="false">
                            <img src="<?php echo e(auth()->user()->avatar_link); ?>"
                                 alt="Mon avatar"
                                 style="height: 20px; width: 20px">
                            <?php echo e(auth()->user()->pseudo); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

                            <a class="dropdown-item" href="<?php echo e(url("user/". auth()->user()->id)); ?>">
                                <i class="fas fa-user green" aria-hidden="true"></i> Mon profil</a>

                            <a class="dropdown-item" href="<?php echo e(url("account")); ?>">
                                <i class="fas fa-cog green"></i> Mon compte</a>

                            <a class="dropdown-item" href="<?php echo e(url("parrainage")); ?>"><i class="fas fa-users green"></i>
                                Parrainage</a>
                        </div>
                    </li>

                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("chat")); ?>">
                            <i class="fas fa-comment green" aria-hidden="true"></i>
                            Chat</a>
                    </li>

                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("forum")); ?>">
                            <i class="fas fa-align-justify green"></i></i>
                            Forum</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("boutique")); ?>">
                            <i class="fas fa-shopping-cart green" aria-hidden="true"></i>
                            Boutique</a>
                    </li>
                    <?php if(auth()->user()->rank >= 4): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url("admin")); ?>">
                                <span class="red"><i class="fa fa-lock" aria-hidden="true"></i></span>
                                Admin</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("auth/logout")); ?>">
                            <span class="green"><i class="fas fa-sign-out-alt" aria-hidden="true"></i></span>
                            Déconnexion</a>
                    </li>
                <?php else: ?>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("auth/register")); ?>">
                            <span class="green"><i class="fas fa-pencil-alt"></i></span>
                            Inscription</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("auth/login")); ?>">
                            <span class="green"><i class="fas fa-sign-in-alt"></i></span>
                            Connexion</a>
                    </li>
                <?php endif; ?>

            </ul>
            <?php if(auth()->check()): ?>

                <ul class="navbar-nav ml-auto" id="nav-check">

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("mcoins")); ?>">
                            <span><?php echo e(auth()->user()->mcoins); ?></span> <i class="fas fa-gem green" aria-hidden="true"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("/conversations")); ?>">
                            <i class="fa fa-envelope green" style="font-size: 1.20em;" aria-hidden="true"></i>

                            <span class="badge badge-pill badge-success" v-if="unread > 0" v-text="unread"></span>

                        </a>
                    </li>

                    

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url("friends")); ?>">
                            <i class="green fa fa-user-plus" style="font-size: 1.20em;" aria-hidden="true"></i> Amis
                            <span class="badge badge-pill badge-success"
                                  v-if="friendsRequests > 0"
                                  v-text="friendsRequests"></span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(url("search/")); ?>" class="nav-link">
                            <i class="fa fa-search green" aria-hidden="true"></i> Rechercher
                        </a>
                    </li>
                </ul>
            <?php endif; ?>
        </div>
    </nav>

    
    <?php
        $annonce = \App\Annonce::latest()->first();
    ?>
    <div class="container">
        <div class="alert alert-primary" role="alert">
            <h4 class="alert-heading"><?php echo e($annonce->titre); ?></h4>
            <?php echo e($annonce->annonce); ?>

        </div>
    </div>

    <?php echo $__env->yieldContent("content"); ?>
</div>

<div class="footer">
    <div class="footlink">
        <a class="fl m-2" href="<?php echo e(url("rules/")); ?>" title="Règlement">
            <i class="green fa fa-graduation-cap" aria-hidden="true"></i> Règlement
        </a>

        <a class="fl m-2" href="<?php echo e(url("cgu/")); ?>" title="CGU">
            <i class="green fa fa-gavel" aria-hidden="true"></i> CGU
        </a>
        <a class="fl m-2" href="<?php echo e(url("contact/")); ?>" title="Contact">
            <i class="green fa fa-envelope" aria-hidden="true"></i> Contact
        </a>
    </div>

    2018-<?php echo e(date("Y")); ?> © MeetiaK

</div>


<script src="<?php echo e(asset("js/master.js")); ?>"></script>

<!-- Cookie consent -->
<?php if(config("app.use_recaptcha")): ?>
    <script>
        window.addEventListener("load", function () {
            window.cookieconsent.initialise({
                "palette": {
                    "popup": {
                        "background": "#26292d"
                    },
                    "button": {
                        "background": "#028a74",
                        "text": "#ffffff"
                    }
                },
                "position": "bottom-right",
                "content": {
                    "message": "Notre site utilise des cookies afin d'améliorer l’expérience des utilisateurs.",
                    "dismiss": "Ok !",
                    "link": "En savoir plus"
                }
            });
        });
    </script>
<?php endif; ?>
<?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php if(App::environment('production')): ?>
    <script src="https://cdn.jsdelivr.net/npm/vue"></script>
<?php else: ?>
    <script src="<?php echo e(url("js/vue.js")); ?>"></script>
<?php endif; ?>

<?php if(auth()->check()): ?>
    <script>
        var notificationsUrl = "<?php echo e(url("conversations/unread/all")); ?>";
        var friendsRequestUrl = "<?php echo e(url("friends/request/got/count")); ?>";

        var unreadDefault = <?php echo json_encode(resolve(\App\Http\Controllers\ConversationsController::class)->getAllUnread()); ?>;
        var friendsRequestDefault = <?php echo json_encode(resolve(\App\Http\Controllers\FriendsController::class)->friendRequestCount()); ?>;
    </script>
    <script src="<?php echo e(asset("js/mp-notif-master.js")); ?>"></script>
<?php endif; ?>


<?php echo $__env->yieldPushContent("scripts"); ?>
</body>
</html>

