<?php $__env->startSection("title", "Mcoins"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container mcoins" id="app" v-cloak>
        <div class="row mcoins">

            <div class="col-md-3 col-12 mb-5">
                <div class="list-group">
                    <router-link to="/" class="list-group-item list-group-item-action">
                        Historique mcoins
                    </router-link>

                    <router-link to="/produits" class="list-group-item list-group-item-action">
                        Produits
                    </router-link>

                    <router-link to="acheter" class="list-group-item list-group-item-action">
                        Acheter des mcoins
                    </router-link>

                    <router-link to="achats" class="list-group-item list-group-item-action">
                        Historique des achats
                    </router-link>
                </div>
            </div>

            <div class="col-md-9 col-12">

                <transition :name="transitionName" mode="out-in">
                    <router-view></router-view>
                </transition>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
    <script>
        var mcoinsHistory = <?php echo /** @var  \Illuminate\Support\Collection $mcoinsHistory */$mcoinsHistory->toJson(); ?>;
        var produits = <?php echo /** @var  \Illuminate\Support\Collection $produits */$produits->toJson(); ?>;
        var mcoinsPrix = <?php echo /** @var  \Illuminate\Support\Collection $mcoinsPrix */$mcoinsPrix->toJson(); ?>;
        var ordersHistory = <?php echo /** @var  \Illuminate\Support\Collection $orders */$orders->toJson(); ?>;
        var ordersCancelled = <?php echo /** @var  \Illuminate\Support\Collection $ordersCancelled */$ordersCancelled->toJson(); ?>;

        var orderUrl = <?php echo json_encode(url("order/create/")); ?>;
    </script>
    <script src="<?php echo e(asset("js/mcoins.js")); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>