<?php $__env->startSection("title", "Boutique"); ?>

<?php $__env->startSection("content"); ?>
    <div id="app">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as /** @var App\Boutique $item */ $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-12">
                        <div class="rounded border border-success m-2 p-2 d-flex flex-column align-items-center text-center boutique-item">

                            <div class="m-2 p-2 rounded border <?php echo e(empty($item->html) ? "invisible" : ""); ?>"><?php echo $item->html; ?></div>

                            <h4 class="m-1"><?php echo e($item->nom); ?></h4>
                            <div class="m-1"><?php echo e($item->description); ?></div>

                            <div class="m-1 <?php echo e($item->jours === 0 ? "invisible" : ""); ?> ">Durée :
                                <span class="font-weight-bold"><?php echo e($item->jours); ?></span> jours.
                            </div>
                            <div class="m-1"><span class="font-weight-bold"><?php echo e($item->prix); ?></span> mcoins.</div>

                            <button class="btn btn-success m-2"
                                    <?php echo e((Auth::user()->mcoins < $item->prix or Auth::user()->hasBoutique($item->nom_id)) ? "disabled" : ""); ?> @click="purchase('<?php echo e($item->nom_id); ?>')">
                                Acheter
                            </button>

                            
                            <?php if(Auth::user()->hasBoutique($item->nom_id)): ?>
                                <div class="text-danger small">Vous avez déjà ce produit.</div>

                                
                            <?php elseif(Auth::user()->mcoins < $item->prix): ?>
                                <div class="text-danger small">Vous n'avez pas assez de mcoins.</div>
                            <?php endif; ?>


                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>

    <script>
        var _token = <?php echo json_encode(csrf_token()); ?>;
        var purchaseUrl = <?php echo json_encode(url("boutique/purchase")); ?>;
    </script>
    <script src="<?php echo e(asset("js/boutique.js")); ?>"></script>

<?php $__env->stopPush(); ?>

<?php $__env->startPush("css"); ?>

    <style>
        .slide-right-enter-active {
            animation: fadeInRight .5s;
        }

        .slide-right-leave-active {
            animation: fadeOutLeft .5s;
        }

        .slide-left-enter-active {
            animation: fadeInLeft .5s;
        }

        .slide-left-leave-active {
            animation: fadeOutRight .5s;
        }


    </style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>