<?php $__env->startSection("title", "500"); ?>

<?php $__env->startSection("content"); ?>
    <center><h1 style=" margin-top: 40vh; transform: translateY(-50%);">Si tu vois cette page c'est qu'Omnes a tout
                                                                        cassé, appel Bibo pour tout réparer !</h1>
    </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>