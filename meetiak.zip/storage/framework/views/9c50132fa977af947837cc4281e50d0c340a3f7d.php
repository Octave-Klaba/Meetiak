<?php $__env->startSection("title", "Page d'accueil"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="center"><img src="<?php echo e(url("img/cover.png")); ?>" style="width:76.5%"/></div>
        <!-- <center><p>Rejoins les %INSCRITS% inscrits : <button class="btn btn-outline-success my-2 my-sm-0" type="submit">S'inscrire</button></p><center></center>-->
    </div>
    <div id="intro" class="intro section-padding">
        <div class="container">
            <div>
                <div class="center">
                    <h2>POURQUOI CHOISIR
                        <span class="green">M</span>eetia<span class="green">K</span> ? </h2>
                    <small>Rejoins <b>
                            <span class="green"><?php echo e($nbrUsers); ?></span>
                        </b> membres déjà inscrits !
                        <br><br>
                        <a class="btn btn-outline-success my-2 my-sm-0" href="<?php echo e(url("auth/register")); ?>">M'inscrire
                        </a>
                        <br>
                        <br>
                    </small>
                </div>
                <br>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="intro-block text-center mb-sm-4 fadeInUp animated">
                        <div class="icon">
                            <i class="fas fa-euro-sign"></i>
                        </div>
                        <h4>GRATUIT</h4>
                        <p>
                            Nous sommes un site de rencontre gratuit, nous
                            proposons cependant des options payantes mais
                            qui ne sont pas indispensables, ces options servent à financer le site et son développement,
                            vous pourrez parfaitement communiquer sans avoir ces options. </p>
                    </div><!-- /.intro-block -->
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="intro-block text-center mb-sm-4 fadeInUp animated"
                         data-wow-duration="1.5s"
                         data-wow-delay="0.5s">
                        <div class="icon">
                            <i class="fas fa-transgender-alt"></i>
                        </div>
                        <h4>OUVERTURE</h4>
                        <p>
                            Peu importe votre genre, que vous soyez un homme, une femme, un transexuel, un non-binaire,
                            peu importe vos orientations sexuelles, de l'hétérosexualité, l'homosexualité, la
                            bisexualité, à la pansexualité en passant par la poly-sexualités, la lithoromantie, la
                            demiromancie, la demisexualité, la graysexualité, l'asexualité, ou encore l'aromantisme,
                            ..., ici tout le monde à sa place ! </p>
                    </div><!-- /.intro-block -->
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="intro-block text-center fadeInUp animated">
                        <div class="icon">
                            <i class="fas fa-address-card"></i>
                        </div>
                        <h4>MODÉRATION</h4>
                        <p>
                            Notre modération disponible rapidement, active et bénévole veille au respect du règlement et
                            à l'identité de nos membres, tout membre dont l'identité est douteuse se devra de la prouver
                            sous peine d'un bannissement du site, chaque enfrein du règlement est également rapidement
                            sanctionné, ce qui permet une bonne ambiance au sein du site. </p>
                    </div><!-- /.intro-block -->
                </div>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>