<?php $__env->startSection("title", "Mot de passe oublié"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container">

        <div class="alert alert-info" role="alert">
            <strong>Un email avec un lien de récupération sera envoyer.</strong>
        </div>

        <form action="<?php echo e(url("auth/forgot")); ?>" method="post">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <?php echo $__env->make("layouts.errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <div class="form-group">
                <label for="email">Adresse Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old("email")); ?>" required>
            </div>
            <button type="submit" class="btn btn-outline-success">Envoyer
            </button>
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>