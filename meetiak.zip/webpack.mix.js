/* eslint-disable no-undef */
let mix = require("laravel-mix");
let LiveReloadPlugin = require("webpack-livereload-plugin");
/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */


mix.webpackConfig({
    plugins: [
        new LiveReloadPlugin()
    ]
});

mix.options({
    postCss: [
        require("cssnano")(),
        require("css-mqpacker")()
    ]
});

mix.sass("resources/assets/sass/master.scss", "public/css/style.css");

//JS
mix.js("resources/assets/js/adminIndex.js", "public/js");
mix.js("resources/assets/js/chat.js", "public/js");
mix.js("resources/assets/js/search.js", "public/js");
mix.js("resources/assets/js/tabs.js", "public/js");
mix.js("resources/assets/js/conversation.js", "public/js");
mix.js("resources/assets/js/mp-notif-master.js", "public/js");
mix.js("resources/assets/js/conversations-users-unread.js", "public/js");
mix.js("resources/assets/js/avatar.js", "public/js");
mix.js("resources/assets/js/boutique.js", "public/js");
mix.js("resources/assets/js/mcoins.js", "public/js");
mix.js("resources/assets/js/forum.js", "public/js");

mix.combine(["public/js/library/axios.min.js",
    "public/js/library/jquery.min.js",
    "public/js/library/popper.min.js",
    "public/js/library/bootstrap.min.js",
    "public/js/library/cookieconsent.min.js",
    "public/js/library/sweetalert.min.js"
],
"public/js/master.js");


mix.disableNotifications();

if (!mix.inProduction()) {
    mix.sourceMaps();
}

//mix.browserSync('meetiak.test:8080');