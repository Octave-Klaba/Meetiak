<?php
/**
 * Created by PhpStorm.
 * User: Corentin
 * Date: 09/03/2018
 * Time: 14:32
 */

define("PARRAIN_MCOINS", 100);
define("FILLEUL_MCOINS", 50);
