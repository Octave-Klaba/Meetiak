var vm = new Vue({
    el: "#app",

    data: {
        reportsArray: []
    },

    methods: {
        getReports() {
            let self = this;
            axios.get(reports_url)
                .then(function (response) {
                    self.reportsArray = response.data;
                })
                .catch(function (error) {
                    console.log(error);
                });
        },
        userLink(id) {
            return userUrl + "/" + id;
        },
        deleteReport(id) {
            if (confirm("Êtes-vous sûr?")) {
                axios.post(reports_url, {
                    _token: _token,
                    id: id
                })
                    .then(function (response) {
                        vm.getReports();
                    })
                    .catch(function (error) {
                        console.log(error);
                    });

            }
        }
    }
});