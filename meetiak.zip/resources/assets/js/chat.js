import VueAdsense from "./vue-adsense/main.js";
import _ from "lodash";

/* eslint-disable no-undef */
let vm = new Vue({
    el: "#app",

    data: {
        messages: [],
        usersOnline: [],
        messageInput: "",

        scrolled: false,

        hasError: false,
        error: {}
    },

    methods: {
        getMessages() {

            axios.get(chatGetUrl)
                .then(function (response) {
                    vm.messages = response.data["messages"].reverse();
                    vm.usersOnline = response.data["usersOnline"];

                    $("[data-toggle=\"tooltip\"]").tooltip();

                    vm.hasError = false;

                    setTimeout(vm.getMessages, 1000);


                })
                .catch(function (error) {
                    vm.error = error.response;

                    vm.hasError = true;

                    setTimeout(vm.getMessages, 1000);
                });

            this.updateScroll();
        },

        sendMessage() {

            //Ajax
            axios.post(chatAddUrl, {
                _token: _token,
                message: this.messageInput
            })
                .then(() => {
                    //vide input
                    this.messageInput = "";


                    //Scroll
                    let chatBody = document.getElementById("chat-body");
                    chatBody.scrollTop = chatBody.scrollHeight;
                })
                .catch(function (error) {
                    console.log(error);
                });


        },
        deleteMessage(id) {

            axios.post(chatDeleteUrl, {
                _token: _token,
                id: id
            })
                .catch(function (error) {
                    console.log(error);
                });

        },

        clearChat() {
            axios.post(chatClearUrl, {
                _token: _token,
            })
                .catch(function (error) {
                    console.log(error);
                });

        },

        updateScroll() {
            let chatBody = document.getElementById("chat-body");
            if (!this.scrolled) {
                chatBody.scrollTop = chatBody.scrollHeight;
            }

            this.scrolled = !($("#chat-body").scrollTop() + $("#chat-body").innerHeight() >= $("#chat-body")[0].scrollHeight);
        }
    },

    computed: {

        errorMessage() {
            if (!_.isEmpty(this.error)) {
                switch (this.error.status) {
                    case 401:
                        return "Vous n'êtes pas connecté.";
                    case 503:
                        return "Le site est en maintenance.";
                    default:
                        return "Impossible de récupérer les messages du chat.";
                }

            }
        }

    },

    mounted() {

        //Première fois
        this.getMessages();

        setInterval(this.updateScroll, 250);

        $("#chat-body").on("scroll", function () {
            vm.scrolled = true;
        });


    }
});