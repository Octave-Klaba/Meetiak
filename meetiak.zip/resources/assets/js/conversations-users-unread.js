new Vue({
    el: "#users-list",

    data: {
        unread: {}
    },

    mounted() {
        let self = this;

        function getUnread() {

            axios.get(unreadUrl).then(response => {

                self.unread = response.data;
                setTimeout(getUnread, 5000);
            })
                .catch(function (error) {
                    console.log(error);
                    setTimeout(getUnread, 5000);
                });

        }

        getUnread();

    }
});