import VueAdsense from './VueAdsense.vue';
export default VueAdsense;