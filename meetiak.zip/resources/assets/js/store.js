import axios from "axios";

class Store {
    constructor() {
        this.store = {};
        this.timeout = {};
    }

    addItem(name, type, args, time) {

        self = this;

        //Première fois
        axios[type].apply(this, args)
            .then(function (response) {
                self.store[name] = response.data;
            });

        let func = () => {
            self.timeout[name] = setTimeout(() => {
                axios[type].apply(this, args)
                    .then(function (response) {
                        self.store[name] = response;
                        func();
                    })
                    .catch(function (error) {
                        console.log(error);
                        func();
                    });
            }, time);
        };

        func();


    }

    getItem(name) {
        return this.store[name];
    }

    removeItem(name) {
        clearTimeout(this.timeout[name]);
        delete this.store[name];
    }
}

let store = new Store();
export default store;