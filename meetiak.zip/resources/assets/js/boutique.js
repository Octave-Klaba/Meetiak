import swal from "sweetalert";

new Vue({
    el: "#app",

    methods: {
        purchase(nom_id) {
            self = this;
            swal({
                title: "Acheter?",
                dangerMode: true,
                buttons: {
                    cancel: {
                        text: "Annuler",
                        value: false,
                        visible: true,

                    },
                    confirm: {
                        text: "Oui",
                        value: true,
                        visible: true,
                    }
                },
            }).then((response) => {
                if (response) {
                    self.purchaseAjax(nom_id);
                }
            });
        },

        purchaseAjax(nom_id) {
            axios.post(purchaseUrl, {
                _token: _token,
                nom_id: nom_id
            }).then((response) => {
                swal({
                    title: "\"" + response.data + "\" acheté avec succès !",
                    icon: "success",
                    timer: 2000
                }).then(() => {
                    location.reload();
                });
            }).catch(() => {
                swal({
                    title: "Erreur",
                    text: "Impossible d'acheter le produit, êtes vous connecté et avez vous assez de mcoins?",
                    icon: "error",
                });
            });


        }
    },


});