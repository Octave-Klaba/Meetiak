Vue.component("tabs", {
    template: `<div>
    <ul class="nav nav-tabs">
        <li class="nav-item" v-for="tab in tabs">
            <a class="nav-link" :class="{active: tab.isActive}" href="#" @click.prevent="changeTab(tab)">{{tab.name}}</a>
        </li>
    </ul>
    <div>
        <slot></slot>
    </div>
</div>`,

    data() {
        return {
            tabs: this.$children
        };
    },

    methods: {
        changeTab(newTab) {
            this.tabs.forEach(tab => {
                if (tab === newTab) {
                    tab.isActive = true;
                    tab.$emit("selected");
                } else {
                    tab.isActive = false;
                    tab.$emit("unselected");
                }
            });

        }
    },
});


Vue.component("tab", {
    template: `<div v-show="isActive"><slot></slot></div>`,

    props: {
        name: {
            required: true
        },
        selected: {
            default: false
        }
    },

    data() {
        return {
            isActive: false
        };
    },

    created() {
        this.isActive = this.selected;
        if (this.selected) {
            this.$emit("selected");
        }
    }
});