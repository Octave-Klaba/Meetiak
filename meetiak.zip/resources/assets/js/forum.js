import VueRouter from "vue-router";
import Posts from "./components/forum/posts"
import Category from "./components/forum/Categories"
import PostMessages from "./components/forum/PostMessages"
import PostForm from "./components/forum/PostForm"

Vue.use(VueRouter);

const routes = [
    {path: "/", component: Category},
    {path: "/category/:id", component: Posts},
    {path: "/post/:category/:id", component: PostMessages},
    {path: "/new/post/:id", component: PostForm},

];

const router = new VueRouter({
    routes,
    linkExactActiveClass: "active"
});

new Vue({
    el: "#app",
    router,

    mounted() {
        setInterval(() => {
            $("[data-toggle=\"tooltip\"]").tooltip();
        }, 1000);
    }

});