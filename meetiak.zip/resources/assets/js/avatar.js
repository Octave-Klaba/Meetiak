new Vue({
    el: "#app",

    data: {
        c: {}
    },

    mounted() {
        let self = this;

        $(function () {
            self.c = new Croppie(self.$refs.image, {
                enableExif: true,

                viewport: {
                    width: 120,
                    height: 120,
                    type: "circle"
                }
            });

            self.c.bind({
                url: base64
            });

        });
    },

    methods: {

        sendImage() {

            this.c.result({type: "base64", format: "png"}).then((base => {
                this.$refs.input.setAttribute("value", base);
                this.$refs.form.submit();
            }));


        }

    }

});