// eslint-disable-next-line no-undef
new Vue({
    el: "#nav-check",
    data: {
        unread: unreadDefault,
        friendsRequests: friendsRequestDefault
    },

    mounted() {
        let self = this;

        function getUnread() {

            //Unread
            axios.get(notificationsUrl).then(response => {

                self.unread = response.data;
                setTimeout(getUnread, 10000);
            })
                .catch(function (error) {
                    console.log(error);
                    setTimeout(getUnread, 10000);
                });


        }

        function getFriends() {
            //Friends
            axios.get(friendsRequestUrl).then(response => {

                self.friendsRequests = response.data;
                setTimeout(getFriends, 10000);
            })
                .catch(function (error) {
                    console.log(error);
                    setTimeout(getFriends, 10000);
                });
        }

        getUnread();
        getFriends();

    }
});