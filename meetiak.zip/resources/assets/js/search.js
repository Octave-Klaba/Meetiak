/* eslint-disable no-undef */

import lodash from "lodash";

Window._ = lodash;

// eslint-disable-next-line no-unused-vars
let vm = new Vue({
    el: "#app",
    date: {},

    data: {
        pseudo: search_pseudo,
        homme: search_homme,
        femme: search_femme,
        autre: search_autre,
        departement: search_departement,
        min: search_min,
        max: search_max,
        online: search_online,

        users: [],

        loading: false,
        error: false,

        once: false,
    },

    watch: {
        pseudo() {
            this.debounceRequest();
        },
        homme() {
            this.debounceRequest();
        },
        femme() {
            this.debounceRequest();
        },
        autre() {
            this.debounceRequest();
        },
        departement() {
            this.debounceRequest();
        },
        min() {
            this.debounceRequest();
        },
        max() {
            this.debounceRequest();
        },
        online() {
            this.debounceRequest();
        }
    },

    computed: {
        isEmpty() {

            if (this.once) {
                return _.isEmpty(this.users);
            }

            return false;
        }
    },

    methods: {

        searchRequest() {
            let self = this;

            this.loading = true;
            this.error = false;

            let oldUser = _.clone(this.users);

            //Vide
            this.users.length = 0;

            axios.post(searchUrl, {
                _token: _token,
                pseudo: this.pseudo,
                homme: this.homme,
                femme: this.femme,
                autre: this.autre,
                departement: this.departement,
                min: this.min,
                max: this.max,
                online: this.online

            }).then(function (response) {
                self.users = response.data;

                self.loading = false;
                self.once = true;
            })
                .catch(function (error) {
                    console.log(error);

                    self.users = _.clone(oldUser);

                    self.loading = false;
                    self.once = true;
                    self.error = true;
                });
        },

        debounceRequest() {
        },

        beforeLeave(el) {
            const {marginLeft, marginTop, width, height} = window.getComputedStyle(el);
            el.style.left = `${el.offsetLeft - parseFloat(marginLeft, 10)}px`;
            el.style.top = `${el.offsetTop - parseFloat(marginTop, 10)}px`;
            el.style.width = width;
            el.style.height = height;
        }


    },

    mounted() {

        let self = this;
        var slider = document.getElementById("slider");

        noUiSlider.create(slider, {
            start: [search_min, search_max],
            range: {
                "min": [13],
                "max": [99]
            },
            connect: true,
            step: 1
        });

        this.debounceRequest = _.debounce(this.searchRequest, 1000);


        slider.noUiSlider.on("slide", function () {
            self.min = parseInt(slider.noUiSlider.get()[0]);
            self.max = parseInt(slider.noUiSlider.get()[1]);
        });

        this.debounceRequest();

    }
});