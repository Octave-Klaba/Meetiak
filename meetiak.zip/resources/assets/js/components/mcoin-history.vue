<template>
    <div class="text-center">
        <h1>Historique mcoins</h1>

        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th scope="col">Montant</th>
                    <th scope="col">Description</th>
                    <th scope="col">Date et heure</th>
                </tr>
                </thead>
                <tbody>

                <tr v-for="mcoin in mcoins">
                    <td v-text="mcoin.montant"></td>
                    <td v-text="mcoin.description"></td>
                    <td v-text="mcoin.created_at"></td>
                </tr>

                </tbody>
            </table>
        </div>

    </div>
</template>

<script>
    export default {
        name: "mcoin-history",

        data() {
            return {
                mcoins: mcoinsHistory
            };
        },
    };
</script>

<style scoped>

</style>