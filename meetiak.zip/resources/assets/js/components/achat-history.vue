<template>
    <div class="text-center">
        <h1 v-if="!cancelled">Historique Achats</h1>
        <h1 v-else>Historique Achats Annulées</h1>

        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th scope="col">Montant</th>
                    <th scope="col" v-if="!cancelled">ID paypal</th>
                    <th scope="col">ID Meetiak</th>
                    <th scope="col">Mcoins</th>
                    <th scope="col">Date et heure</th>
                </tr>
                </thead>
                <tbody>

                <tr v-for="order in orders">
                    <td v-text="order.amount + ' €'"></td>
                    <td v-text="order.transaction_id" v-if="!cancelled"></td>
                    <td v-text="order.uuid"></td>
                    <td v-text="order.mcoins"></td>
                    <td v-text="order.updated_at"></td>
                </tr>

                </tbody>
            </table>
        </div>

        <div class="form-check">
            <input type="checkbox" id="trashed" class="form-check-input" v-model="cancelled">
            <label for="trashed" class="form-check-label">Afficher les achats annulé</label>
        </div>

    </div>
</template>

<script>
    export default {
        name: "achat-history",

        data() {
            return {
                cancelled: false,
            };
        },

        computed: {
            orders() {
                return this.cancelled ? ordersCancelled : ordersHistory;
            }
        },
    };
</script>

<style scoped>

</style>