<template>
    <div class="text-center">
        <h1>Acheter des mcoins</h1>

        <div class="row">
            <div class="col-12 col-md-6 item" v-for="item in items">
                <div class="border border-success m-2 p-2 rounded">
                    <h4>{{item.nom}}</h4>
                    <div>{{item.prix}} €</div>

                    <a class="btn btn-success" :href="url(item.url)">Payer avec Paypal <i class="fab fa-paypal"></i></a>

                </div>
            </div>
        </div>

    </div>
</template>

<script>
    export default {
        name: "mcoin-achat",

        data() {
            return {
                items: mcoinsPrix
            };
        },

        methods: {
            url(url) {
                return _.toString(orderUrl + '/' + url);
            }
        },
    };
</script>

<style lang="scss" scoped>

    .item {
        min-height: 100px;
    }

</style>