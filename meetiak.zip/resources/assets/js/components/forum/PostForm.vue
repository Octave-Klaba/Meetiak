<template>
    <form @submit.prevent="sendPost">
        <h2 v-text="categoryName()"></h2>
        <div class="form-group">
            <label for="title">Nom du post :</label>
            <input type="text" class="form-control" id="title" v-model="title" required autocomplete="off">
            <small class="form-text" :class="{'text-danger' : title.length > 150}">{{title.length}} / 150</small>
            <small class="form-text text-danger" v-if="error.title" v-text="error.title[0]"></small>
        </div>
        <div class="form-group">
            <label for="message">Message :</label>
            <textarea class="form-control"
                      id="message"
                      rows="3"
                      v-model="message"
                      required
                      autocomplete="off"></textarea>
            <small class="form-text text-danger" v-if="error.message" v-text="error.message[0]"></small>
        </div>

        <button type="submit" class="btn btn-success" :disabled="loading">Créer le post</button>
        <small class="form-text text-danger" v-if="ajaxError">Erreur</small>
        <small class="form-text text-danger" v-if="error.id" v-text="error.id[0]"></small>
    </form>
</template>

<script>

    export default {
        name: "post-form",
        data() {
            return {
                title: "",
                message: "",

                error: [],
                ajaxError: false,

                loading: false
            };
        },

        methods: {
            categoryName() {
                return _.find(categoriesPosts, {"id": _.toInteger(this.$route.params.id)}).title;
            },

            sendPost() {
                let self = this;

                if (!self.loading) {

                    self.loading = true;

                    self.ajaxError = false;
                    self.error = [];

                    axios.post(CreateUrl, {
                        _token: _token,
                        id: this.$route.params.id,
                        title: this.title,
                        message: this.message
                    }).then((response) => {
                        self.loading = false;

                        self.$router.push({path: "/post/" + response.data[0] + "/" + response.data[1]});
                    }).catch((error) => {
                        self.loading = false;

                        if (!_.isUndefined(error.response) && error.response.status === 422) {
                            self.error = error.response.data.errors;
                        }
                        else {
                            self.ajaxError = true;
                        }
                    });

                }
            }
        },

        mounted() {
            document.title = "Ajouter un post dans " + this.categoryName() + tiltleEnd;
        }
    };
</script>

<style scoped>

</style>