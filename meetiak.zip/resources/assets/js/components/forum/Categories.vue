<template>
    <div>
        <div class="border border-success rounded m-2 p-2 row text-center align-items-center forum-post"
             v-for="category in categories">

            <router-link class="col-12 col-md-8" :to="'category/' + category.id">{{category.title}}</router-link>
            <div class="col-12 col-md-2 small font-italic">{{category.posts_count}} posts.</div>
            <div class="col-12 col-md-2 fas fa-lock green" v-if="category.locked"></div>

        </div>
    </div>
</template>

<script>

    export default {
        name: "categories",

        data() {
            return {
                categories: categoriesPosts
            };
        },

        mounted() {
            document.title = "Forum" + tiltleEnd;

        }

    };
</script>

<style scoped>


</style>