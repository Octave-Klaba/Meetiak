<template>

    <ul class="pagination" v-if="totalItems !== 0">

        <li class="page-item disabled" v-if="currentPage === 1"><span class="page-link">&laquo;</span></li>
        <li class="page-item" v-else><span class="page-link"
                                           rel="prev"
                                           @click="updatePage(currentPage - 1)">&laquo;</span>
        </li>

        <template v-for="i in totalPages">

            <li class="page-item active" v-if="currentPage === i" v-bind:key="i"><span class="page-link">{{i}}</span>
            </li>

            <li class="page-item disabled" v-else-if="i === '...'" v-bind:key="i"><span class="page-link">{{i}}</span>
            </li>

            <li class="page-item" v-else v-bind:key="i"><span class="page-link" @click="updatePage(i)">{{ i }}</span>
            </li>

        </template>

        <li class="page-item disabled" v-if="currentPage === maxPages"><span class="page-link">&raquo;</span></li>
        <li class="page-item" v-else><span class="page-link"
                                           rel="next"
                                           @click="updatePage(currentPage + 1)">&raquo;</span></li>
    </ul>

</template>

<script>
    import _ from "lodash";

    export default {
        name: "pagination",

        props: {
            items: {
                type: [Number, Array],
                default: 0,
                required: true
            },
            perPage: {
                type: Number,
                default: 5,
                required: true
            },
            defaultPage: {
                type: Number,
                default: 1
            },

            value: {
                required: false
            }
        },

        data() {
            return {
                currentPage: this.defaultPage,
                itemsData: this.items
            };
        },

        computed: {
            totalItems() {
                return _.isNumber(this.itemsData) ? this.itemsData : this.itemsData.length;
            },

            totalPages() {
                let current = this.currentPage;
                let last = Math.ceil(this.totalItems / this.perPage);
                let delta = 2;
                let left = current - delta;
                let right = current + delta + 1;
                let range = [];
                let rangeWithDots = [];
                let l;

                for (let i = 1; i <= last; i++) {
                    if (i === 1 || i === last) {
                        range.push(i);
                    } else if (i >= left && i < right) {
                        range.push(i);
                    }
                }

                for (let i of range) {
                    if (l) {
                        if (i - l === 2) {
                            rangeWithDots.push(l + 1);
                        } else if (i - l !== 1) {
                            rangeWithDots.push("...");
                        }
                    }
                    rangeWithDots.push(i);
                    l = i;
                }

                return rangeWithDots;
            },

            maxPages() {
                return Math.ceil(this.totalItems / this.perPage);
            }
        },

        methods: {
            updatePage(page = this.currentPage) {
                this.currentPage = page;

                this.$emit("input", _.isNumber(this.itemsData) ? page : _.slice(this.itemsData, (this.currentPage - 1) * this.perPage, this.currentPage * this.perPage));
                this.$emit("update", _.isNumber(this.itemsData) ? page : _.slice(this.itemsData, (this.currentPage - 1) * this.perPage, this.currentPage * this.perPage));
            },

            goToLastPage() {
                this.updatePage(this.maxPages);
            }
        },

        mounted() {
            this.updatePage(this.defaultPage);

            this.$on("updateItems", function (newItems) {
                this.itemsData = newItems;

                this.updatePage();
            });
        }
    };
</script>

<style scoped>

</style>
