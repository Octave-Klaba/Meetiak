<template>
    <div>

        <h2 v-text="categoryTitle" class="text-center"></h2>

        <div class="card">
            <h5 class="card-header d-flex">
                <router-link to="/" class="no-style no-color mr-auto d-flex"><i class="fas fa-arrow-left"></i>
                </router-link>

                <div class="ml-auto d-flex">
                    <a class="mx-2 no-style no-color" href="#" @click.prevent="getPosts"><i class="fas fa-sync"></i></a>
                    <router-link :to="'/new/post/' + $route.params.id"
                                 v-if="!isLocked"
                                 class="mx-2 no-style no-color ml-auto d-flex"><i class="fas fa-plus"></i></router-link>

                    <i class="fas fa-lock mx-2 no-style no-color ml-auto d-flex" v-else></i>
                </div>

            </h5>

            <div class="card-body">
                <transition name="fade" mode="out-in">

                    <!-- Spinner -->
                    <div v-if="loading" class="d-flex justify-content-center align-items-center m-2">
                        <i class="fas fa-spinner fa-spin fa-5x green"></i>
                    </div>

                    <!-- Error -->
                    <div v-else-if="error" class="d-flex justify-content-center align-items-center m-2 flex-column">
                        <i class="fas fa-times fa-5x text-danger"></i>
                        <div>Erreur</div>
                        <button class="btn btn-success" @click="getPosts">Réessayer</button>
                    </div>

                    <div :key="show" v-else>

                        <div v-for="(post, key) in posts" :key="post.id">

                            <div class="row">

                                <router-link class="col-12 col-md-5" :to="'/post/' + post.category_id + '/'+ post.id">
                                    {{post.title}}
                                </router-link>

                                <div class="col-3 col-md-2" v-html="post.user.link"></div>
                                <div class="col-3 col-md-2 small font-italic">{{post.created_at}}</div>
                                <div class="col-3 col-md-2 small font-italic">{{post.messages_count}} messages</div>
                                <div class="col-3 col-md-1 fas fa-lock green" v-if="post.locked"></div>
                            </div>

                            <hr v-show="++key !== posts.length">
                        </div>
                    </div>
                </transition>
            </div>

        </div>
        <pagination :items="allPosts" :per-page="10" v-model="posts" @update="updatePosts" ref="pagination"/>

    </div>
</template>

<script>
    import Pagination from "./Pagination";

    Vue.component("pagination", Pagination);

    export default {
        name: "posts",

        data() {
            return {
                posts: [],
                show: true,
                categories: categoriesPosts,

                allPosts: [],

                loading: true,
                error: false
            };
        },

        created() {
            this.getPosts();

            document.title = self.categoryTitle + tiltleEnd;
        },

        methods: {
            updatePosts() {
                let self = this;

                self.show = false;

                this.$nextTick(() => {
                    self.show = true;
                });
            },

            getPosts() {

                self = this;

                self.error = false;

                self.$nextTick(() => {
                    self.loading = true;
                });

                axios.get(getCategoryUrl + "?id=" + this.$route.params.id)
                    .then((response) => {
                        self.allPosts = response.data;

                        self.$refs.pagination.$emit("updateItems", self.allPosts);

                        self.error = false;
                        self.loading = false;

                    })
                    .catch((error) => {
                        console.log(error);

                        self.loading = false;

                        self.$nextTick(() => {
                            self.error = true;
                        });


                    });

            },
        },

        computed: {
            isLocked() {
                return _.find(this.categories, {"id": _.toInteger(this.$route.params.id)}).locked;
            },

            categoryTitle() {
                return _.find(this.categories, {"id": _.toInteger(this.$route.params.id)}).title;
            }
        },
    };
</script>

<style scoped lang="scss">
    .card-body {
        min-height: 577px;
    }
</style>