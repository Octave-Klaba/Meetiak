<template>
    <div>

        <h2 v-text="title" class="text-center"></h2>

        <div class="card">
            <h5 class="card-header d-flex">
                <router-link :to="'/category/' + $route.params.category" class="no-style no-color mr-auto d-flex">
                    <i class="fas fa-arrow-left"></i></router-link>

                <div class="ml-auto d-flex">
                    <a class="mx-2 no-style no-color" href="#" @click.prevent="getMessages(false)"><i class="fas fa-sync"></i></a>
                    <i class="fas fa-lock mx-2 no-style no-color" v-if="locked"></i>
                </div>

            </h5>

            <div class="card-body">

                <transition name="fade" mode="out-in">

                    <!-- Spinner -->
                    <div v-if="loading" class="d-flex justify-content-center align-items-center m-2">
                        <i class="fas fa-spinner fa-spin fa-5x green"></i>
                    </div>

                    <!-- Error -->
                    <div v-else-if="error" class="d-flex justify-content-center align-items-center m-2 flex-column">
                        <i class="fas fa-times fa-5x text-danger"></i>
                        <div>Erreur</div>
                        <button class="btn btn-success" @click="getMessages">Réessayer</button>
                    </div>

                    <div :key="animation" v-else>

                        <div v-for="(message, key) in messages" :key="message['id']">
                            <div class="media">
                                <!-- Avatar -->
                                <a :href="'user/' + message['user_id']">
                                    <img class="align-self-center mx-1 mx-md-3 rounded-circle"
                                         :src="message.user['avatar_link']"
                                         style="width: 64px; height: 64px">
                                </a>
                                <div class="media-body">

                                    <h5 class="mt-0">
                                        <span v-html="message.user['link']"></span>
                                        <i>
                                            <small v-text="message['created_at']"
                                                   data-toggle="tooltip"
                                                   data-placement="top"
                                                   :title="message['full_date']"></small>
                                        </i>
                                    </h5>
                                    <p class="word-break">
                                        {{ message["message"] }} </p>
                                </div>

                            </div>
                            <hr v-show="++key !== messages.length">

                        </div>

                    </div>
                </transition>
            </div>

        </div>

        <pagination :items="allMessages" :per-page="5" v-model="messages" ref="pagination" @update="updateAnimation"/>

        <!-- Form -->
        <form v-if="(!locked && !loading && !error) || (!locked && sendLoading)" @submit.prevent="sendMessage">
            <div class="form-group">
                <label for="message">Message :</label>
                <textarea class="form-control" id="message" rows="3" v-model="formMessage" required></textarea>
            </div>

            <button type="submit" class="btn btn-success" :disabled="sendLoading">Envoyer le message</button>
            <small class="form-text text-danger" v-if="sendError">Erreur</small>


        </form>


    </div>
</template>

<script>
    export default {
        name: "post-messages",

        data() {
            return {
                loading: true,
                error: false,

                sendLoading: false,
                sendError: false,
                formMessage: "",

                animation: true,

                allMessages: [],
                messages: [],
                title: "Chargement...",

                locked: false


            };
        },

        created() {
            this.getMessages();
        },

        methods: {
            getMessages(goToLastPage = false) {
                self = this;

                document.title = self.title + tiltleEnd;

                self.error = false;

                self.$nextTick(() => {
                    self.loading = true;
                });

                axios.get(getPostUrl + "?id=" + this.$route.params.id)
                    .then((response) => {
                        self.allMessages = response.data[0];
                        self.title = response.data[1];
                        self.locked = response.data[2];

                        self.$refs.pagination.$emit("updateItems", self.allMessages);

                        self.error = false;
                        self.loading = false;

                        self.sendLoading = false;
                        self.sendError = false;

                        document.title = self.title + tiltleEnd;

                        //Last page
                        if (goToLastPage) {
                            self.$nextTick(() => {
                                self.$refs.pagination.goToLastPage();
                            });

                        }

                    })
                    .catch((error) => {
                        document.title = "Erreur" + tiltleEnd;

                        self.loading = false;

                        self.$nextTick(() => {
                            self.error = true;
                        });


                    });

            },

            updateAnimation() {
                let self = this;

                self.animation = false;

                this.$nextTick(() => {
                    self.animation = true;
                });
            },

            sendMessage() {
                let self = this;

                if (!self.sendLoading) {

                    self.sendLoading = true;
                    self.sendError = false;

                    axios.post(CreateMessageUrl, {
                        _token: _token,
                        id: self.$route.params.id,
                        message: self.formMessage
                    }).then(() => {

                        //Vide message
                        self.formMessage = "";

                        self.getMessages(true);

                    }).catch(() => {

                        self.sendLoading = false;
                        self.sendError = true;

                    });
                }

            }


        },

        watch: {
            messages() {
                this.$nextTick(() => {
                    $("[data-toggle=\"tooltip\"]").tooltip();
                });
            }
        },
    };
</script>

<style scoped>

    .card-body {
        min-height: 612px;
    }

</style>