<template>
    <div class="text-center">
        <h1>Produits</h1>

        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th scope="col">Nom</th>
                    <th scope="col">Prix</th>
                    <th scope="col">Acheté le</th>
                    <th scope="col">Expire le</th>
                    <th scope="col">Expiré ?</th>
                </tr>
                </thead>
                <tbody>

                <tr v-for="produit in produits" :class="{'bg-danger text-dark': produit.expired}">
                    <td v-text="produit.boutique.nom"></td>
                    <td v-text="produit.boutique.prix"></td>
                    <td v-text="produit.created_at"></td>
                    <td v-text="produit.expires_at"></td>
                    <td v-text="produit.expired ? 'oui' : 'non'"></td>
                </tr>

                </tbody>
            </table>
        </div>

    </div>
</template>

<script>
    export default {
        name: "produits",
        data() {
            return {
                produits: produits
            };
        },
    };
</script>

<style scoped>

</style>