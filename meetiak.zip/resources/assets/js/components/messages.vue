<template>
    <div class="overflow" id="overflow">
        <div v-for="message in messages" :key="message['id']" class="message m-2">
            <div class="row">
                <div class="col-md-10" :class="{'offset-md-2 text-right' : message['from_user'] === selfId}">

                    <a :href=" '/user/' + message['from_user']">
                        <img class="photoconversation float-left m-2"
                             :src="message['from']['avatar_link']"
                             v-if="message['from_user'] !== selfId">
                    </a>

                    <strong v-html="message['from']['link'] + message['from']['is_online_dot']" class="my-2">
                    </strong>
                    <i>
                        <small v-text="message['created_at']"
                               data-toggle="tooltip"
                               data-placement="top"
                               :title="message['full_date']"></small>
                    </i>

                    <a :href=" '/user/' + selfId">
                        <img class="photoconversation float-right m-2"
                             :src="message['from']['avatar_link']"
                             v-if="message['from_user'] === selfId">
                    </a>

                    <pre class="no-style" v-text="message['content']"></pre>

                </div>

            </div>
            <hr>
        </div>
    </div>
</template>

<script>
    import {EventBus} from "../event-bus.js";

    export default {
        name: "messages",

        props: ["selfId"],

        data() {
            return {
                messages: [],
                scrolled: false,
            };
        },

        methods: {

            updateScroll() {
                let chatBody = document.getElementById("overflow");
                if (!this.scrolled) {
                    chatBody.scrollTop = chatBody.scrollHeight;
                }

                this.scrolled = !($("#overflow").scrollTop() + $("#overflow").innerHeight() >= $("#overflow")[0].scrollHeight);

            }
        },

        mounted() {
            let self = this;
            let firstTime = true;

            EventBus.$on("get", (messages) => {
                $("[data-toggle=\"tooltip\"]").tooltip();
                self.messages = messages;
            });

            setInterval(this.updateScroll, 250);

            $("#overflow").on("scroll", function () {
                self.scrolled = true;
            });
        }
    };
</script>

<style scoped lang="scss">

    .overflow {
        height: 600px;
        overflow-y: scroll;
        overflow-x: hidden;
    }

    .message, hr {
        max-width: 100%;
    }
</style>