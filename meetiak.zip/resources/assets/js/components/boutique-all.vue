<template>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-12" v-for="item in items">
                <div class="rounded border border-success m-2 p-2 d-flex flex-column align-items-center text-center">

                    <img :src="item.miniature" alt="miniature" class="img-thumbnail" style="">
                    <div>{{item.nom}}</div>
                    <div>{{item.prix}} mcoins</div>
                    <router-link class="btn btn-success" :to="'/'+ item.nom_id + '/'">Plus de détail</router-link>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "boutique-all",

        data() {
            return {items: itemsObject};
        }
    };
</script>

<style scoped>

    .img-thumbnail {
        height: 120px;
        width: 120px;
    }

</style>