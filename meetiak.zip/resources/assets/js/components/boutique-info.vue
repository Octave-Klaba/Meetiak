<template>
    <div class="container">
        <div class="rounded border border-success m-2 p-2 d-flex flex-column align-items-center text-center position-relative">
            <router-link class="btn btn-success boutique-back" to="/">Retour</router-link>

            <h2>{{item.nom}}</h2>

            <div class="row">

                <div class="col-md-6 col-12">
                    <div class="m-1">{{item.description}}</div>
                    <div class="m-1">Durée : <span class="font-weight-bold">{{item.jours}}</span> jours.</div>
                </div>
                <div class="col-md-6 col-12">
                    <img :src="item.image" alt="image" class="img-fluid">
                </div>

            </div>

            <span class="m-2"><span class="font-weight-bold">{{item.prix}}</span> mcoins.</span>

            <button class="btn btn-success m-2" :disabled="mcoins < item.prix" @click="purchase">Acheter</button>
            <div v-if="mcoins < item.prix" class="text-danger small">Vous n'avez pas assez de mcoins.</div>

        </div>
    </div>
</template>

<script>
    import swal from "sweetalert";

    export default {
        name: "boutique-info",

        data() {
            return {item: {}, mcoins: mcoins};
        },

        mounted() {
            this.item = itemsObject[this.$route.params.nom_id];
        },
        methods: {
            purchase() {
                self = this;
                swal({
                    title: "Acheter?",
                    dangerMode: true,
                    buttons: {
                        cancel: {
                            text: "Annuler",
                            value: false,
                            visible: true,

                        },
                        confirm: {
                            text: "Oui",
                            value: true,
                            visible: true,
                        }
                    },
                }).then(function purchaseSwal(response) {
                    if (response) {
                        self.purchaseAjax();
                    }
                });
            },

            purchaseAjax() {
                axios.post(purchaseUrl, {
                    _token: _token,
                    nom_id: this.item.nom_id
                }).then(() => {
                    swal({
                        title: "\"" + this.item.nom + "\" acheté avec succès !",
                        icon: "success",
                        timer: 2000
                    }).then(() => {
                        window.location.href = boutiqueUrl;
                    });
                }).catch(() => {
                    swal({
                        title: "Erreur",
                        text: "Impossible d'acheter le produit, êtes vous connecté et avez vous assez de mcoins?",
                        icon: "error",
                    });
                });


            }
        },


    };
</script>

<style lang="scss" scoped>

    .row {
        width: 100%;
    }

</style>