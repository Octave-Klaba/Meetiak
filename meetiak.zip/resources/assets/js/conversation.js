import Messages from "./components/messages.vue";
import {EventBus} from "./event-bus.js";

// eslint-disable-next-line no-undef
new Vue({
    el: "#app",
    components: {
        messages: Messages
    },

    data: {
        messageInput: ""
    },

    methods: {

        sendMessage() {

            //Ajax
            axios.post(addMessagesUrl, {
                _token: _token,
                message: this.messageInput
            })
                .catch(function (error) {
                    console.log(error);
                });

            //vide input
            this.messageInput = "";

        },
    },

    mounted() {

        function getMessages() {

            axios.post(getMessagesUrl, {
                _token: _token
            })
                .then((response) => {
                    EventBus.$emit("get", response.data.reverse());
                    setTimeout(getMessages, 1000)
                })
                .catch(function (error) {
                    console.log(error);
                    setTimeout(getMessages, 1000)
                });
        }

        getMessages();

    }
});