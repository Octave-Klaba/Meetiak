import VueRouter from "vue-router";
import lodash from "lodash";

import McoinHistory from "./components/mcoin-history";
import Produits from "./components/produits";
import Acheter from "./components/mcoin-achat";
import AchatsHistory from "./components/achat-history";


window._ = lodash;

const routes = [
    {path: "/", component: McoinHistory},
    {path: "/produits", component: Produits},
    {path: "/acheter", component: Acheter},
    {path: "/achats", component: AchatsHistory}
];

const router = new VueRouter({
    routes,
    linkExactActiveClass: "active",
});

new Vue({
    el: "#app",
    router,
    data: {
        transitionName: ""
    },

    watch: {
        '$route' (to, from) {
            const toDepth = _.findIndex(routes, {'path' : to.path});
            const fromDepth =  _.findIndex(routes, {'path' : from.path});
            this.transitionName = toDepth < fromDepth ? "slide-up" : "slide-down"
        }
    }
});