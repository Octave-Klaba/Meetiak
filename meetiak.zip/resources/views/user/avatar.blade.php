@extends("master")

@section("title", "Modification de l'avatar")

@section("content")

    <div class="container" id="app">

        <h1 class="text-center">Recharger la page si l'image n'est pas centrer dans le cadre.</h1>

        <div id="image" ref="image"></div>

        <button class="btn btn-success" @click="sendImage()">Valider</button>

        <form action="{{url("account/avatar")}}" method="post" ref="form">
            {{csrf_field()}}
            <input type="hidden" name="image" ref="input" :value="image">
        </form>


    </div>

@endsection

@push("scripts")
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exif-js/2.3.0/exif.min.js"></script>
    <script src="{{asset("js/library/croppie.min.js")}}"></script>

    <script>
        var base64 = {!! json_encode($base64) !!};
    </script>

    <script src="{{asset("js/avatar.js")}}"></script>

@endpush

@push("css")
    <link rel="stylesheet" href="{{asset("css/croppie.css")}}">
@endpush