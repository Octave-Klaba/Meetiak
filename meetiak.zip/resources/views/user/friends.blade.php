@extends("master")

@section("title", "Amis")

@section("content")

    <div class="container">

        <nav class="nav nav-pills text-center justify-content-center">
            <a class="nav-link fl m-2 {{$page === "friends" ? "active bg-success" : ""}}"
               href="{{url("friends")}}"><span class="{{$page === "friends" ? "" : "active green"}}">

                    <i class="fa fa-users" aria-hidden="true"></i></span>
                Amis</a>
            <a class="nav-link fl m-2 {{$page === "got" ? "active bg-success" : ""}}"
               href="{{url("friends/requests/got")}}">

                <span class="{{$page === "got" ? "" : "active green"}}"><i class="fa fa-user-plus"
                                                                           aria-hidden="true"></i></span>
                Demandes
                d'amis reçu
                @if(getFriendsRequestCount() !== 0)
                    <span class="badge badge-pill {{$page === "got" ? "active badge-light" : "active badge-success"}}">
                        {{ getFriendsRequestCount() }}
                    </span>
                @endif
            </a>
            <a class="nav-link fl m-2 {{$page === "sent" ? "active bg-success" : ""}}"
               href="{{url("friends/requests/sent")}}">

                <span class="{{$page === "sent" ? "" : "active green"}}"><i class="fa fa-paper-plane"
                                                                            aria-hidden="true"></i></span>
                Demandes
                d'amis envoyées</a>
            <a class="nav-link fl m-2 {{$page === "blocked" ? "active bg-success" : ""}}"
               href="{{url("friends/blocked")}}">

                <span class="{{$page === "blocked" ? "" : "active green"}}"><i class="fa fa-user-times"
                                                                               aria-hidden="true"></i></span>
                Utilisateurs
                bloqués</a>
        </nav>

        <div class="row">

            @if($friends->count() === 0)

                <p class="text-center mx-auto my-3">
                    {{$page === "friends" ? "Vous n'avez pas d'amis." : ""}}
                    {{$page === "got" ? "Vous n'avez pas reçu de demande d'amis." : ""}}
                    {{$page === "sent" ? "Vous n'avez pas envoyé de demandes d'amis." : ""}}
                    {{$page === "blocked" ? "Vous n'avez pas bloqué d'utilisateurs." : ""}}
                </p>
            @endif

            @foreach($friends as $friend)

                <div class="col-12">
                    <div class="m-2 p-2 border border-success rounded row align-items-center">

                        <div class="col-12 col-md-3 text-center">
                            <img class="m-2 rounded-circle img-responsive"
                                 src="{{\Illuminate\Support\Facades\Storage::url($friend->avatar)}}"
                                 style="width: 60px; height: 60px">
                        </div>

                        <div class="col-12 col-md-3 text-center">
                        {!! $friend->link !!}
                        {!! $friend->is_online_dot !!}

                        <!-- Sexe -->
                            {!! $friend->sexe_icon!!}
                        </div>

                        <div class="col-12 col-md-3 text-center">
                            {{$friend->age}}
                            ans

                        </div>

                        <div class="col-12 col-md-3 text-center">
                            {{$friend->departement_nom}} ({{$friend->departement}})

                        </div>

                        <!-- Boutons -->
                        <div class="col-12 col-md-12 text-center text-md-right">
                            <div class="btn-group">

                                @if($page === "friends")
                                    <a class="btn btn-success" href="{{ url("conversations/".$friend->id) }}">
                                        Écrire
                                    </a>
                                    <a href="{{url("friends/delete?id=".$friend->id)}}" class="btn btn-danger">
                                        Supprimer
                                    </a>
                                @endif

                                @if($page === "got")
                                    <a href="{{url("friends/requests/accept?id=".$friend->id)}}"
                                       class="btn btn-success">
                                        Accepter
                                    </a>
                                    <a href="{{url("friends/requests/ignore?id=".$friend->id)}}" class="btn btn-danger">
                                        Supprimer
                                    </a>
                                @endif

                                @if($page === "sent")
                                    <a href="{{url("friends/requests/remove/sent?id=".$friend->id)}}"
                                       class="btn btn-danger">
                                        Supprimer
                                    </a>
                                @endif

                                @if($page === "blocked")
                                    <a href="{{url("friends/unblock?id=".$friend->id)}}" class="btn btn-success">
                                        Débloquer
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="profile-ads1 text-center">
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <!-- pubsoustchat -->
                    <ins class="adsbygoogle"
                         style="display:inline-block;width:728px;height:90px"
                         data-ad-client="ca-pub-7690571679670706"
                         data-ad-slot="5236342360"></ins>
                    <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
        </div>
        {{$friends->links()}}

    </div>



@endsection

