@extends("master")

@section("title", "Mon compte")

@section("content")
    <div class="container">
        <h1>Éditer le Profil</h1>

        <!-- Password -->

        <form action="{{url("account/password")}}" method="post">
            {{csrf_field()}}

            @if(Session::get("account_form", "") === "password")
                @include("layouts.errors")
            @endif

            <div class="row">

                <div class="col-sm-6 form-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password" class="form-control" required/>
                </div>

                <div class="col-sm-6 form-group">
                    <label for="password_confirmation">Confirmation du mot de passe</label>
                    <input type="password"
                           id="password_confirmation"
                           name="password_confirmation"
                           class="form-control"
                           required/>
                </div>

                <div class="col-sm-12 form-group">
                    <button type="submit" class="btn btn-outline-success">Changer de mot de passe
                    </button>
                </div>

            </div>
        </form>

        <form action="{{url("account/avatar/crop")}}" method="post" enctype="multipart/form-data">
        {{csrf_field()}}

        @if(Session::get("account_form", "") === "avatar")
            @include("layouts.errors")
        @endif
        <!-- Avatar -->

            <div class="profile-userpic">
                <div class="center"><img src="{{\Illuminate\Support\Facades\Storage::url($user->avatar)}}"></div>
            </div>

            <div class="row">
                <div class="col-sm-6 form-group">
                    Max : 5000 ko.
                    <input type="file" name="avatar" accept="image/*" required/>
                </div>

                <div class="col-sm-12 form-group">
                    <button type="submit" class="btn btn-outline-success">Changer d'avatar
                    </button>
                </div>
            </div>
        </form>

        <form action="{{url("account/info")}}" method="post">
            {{csrf_field()}}

            @if(Session::get("account_form", "") === "info")
                @include("layouts.errors")
            @endif
            <div class="row">

                <!-- Facebook -->
                <div class="col-sm-6 form-group">
                    <label for="facebook">
                        <font size="6px" color="#29487d"><i class="fab fa-facebook-square"
                                                            aria-hidden="true"></i></font>
                    </label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">facebook.com/</span>
                        </div>
                        <input type="text"
                               value="{{!empty($user->facebook) ? $user->facebook : ""}}"
                               id="facebook"
                               name="facebook"
                               class="form-control"/>
                    </div>
                </div>

                <!-- Youtube -->
                <div class="col-sm-6 form-group">
                    <label for="youtube">
                        <font size="6px" color="#ff0000"><i class="fab fa-youtube" aria-hidden="true"></i></font>
                    </label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">youtube.com/channel/</span>
                        </div>
                        <input type="text"
                               value="{{!empty($user->youtube) ? $user->youtube : ""}}"
                               name="youtube"
                               id="youtube"
                               class="form-control"/>
                    </div>
                </div>

            </div>

            <div class="row">

                <!-- Snapchat -->
                <div class="col-sm-6 form-group">
                    <label for="snapchat">
                        <font size="6px" color="#FFFC00"><i class="fab fa-snapchat-square"
                                                            aria-hidden="true"></i></font>
                    </label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">snapchat.com/add/</span>
                        </div>
                        <input type="text"
                               value="{{!empty($user->snapchat) ? $user->snapchat : ""}}"
                               id="snapchat"
                               name="snapchat"
                               class="form-control"/>
                    </div>
                </div>

                <!-- Steam -->
                <div class="col-sm-6 form-group">
                    <label for="steam">
                        <font size="6px" color="#000"><i class="fab fa-steam" aria-hidden="true"></i></font>
                    </label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">steamcommunity.com/id/</span>
                        </div>
                        <input type="text"
                               value="{{!empty($user->steam) ? $user->steam : ""}}"
                               id="steam"
                               name="steam"
                               class="form-control"/>
                    </div>
                </div>

            </div>

            <div class="row">

                <!-- Twitter -->
                <div class="col-sm-6 form-group">
                    <label for="twitter">
                        <font size="6px" color="#1da1f2"><i class="fab fa-twitter-square" aria-hidden="true"></i></font>
                    </label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">twitter.com/</span>
                        </div>
                        <input type="text"
                               value="{{!empty($user->twitter) ? $user->twitter : ""}}"
                               id="twitter"
                               name="twitter"
                               class="form-control"/>
                    </div>
                </div>

                <!-- Twitch -->
                <div class="col-sm-6 form-group">
                    <label for="twitch">
                        <font size="6px" color="#4b367c"><i class="fab fa-twitch" aria-hidden="true"></i></font>
                    </label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">twitch.tv/</span>
                        </div>
                        <input type="text"
                               value="{{!empty($user->twitch) ? $user->twitch : ""}}"
                               id="twitch"
                               name="twitch"
                               class="form-control"/>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Instagram -->
                <div class="col-sm-6 form-group">
                    <label for="instagram">
                        <font size="6px" color="#E70195"><i class="fab fa-instagram" aria-hidden="true"></i></font>
                    </label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">instagram.com/</span>
                        </div>
                        <input type="text"
                               value="{{!empty($user->instagram) ? $user->instagram : ""}}"
                               id="instagram"
                               name="instagram"
                               class="form-control"/>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 form-group">
                    <label for="orientation">Orientation Sexuelle</label>
                    <select class="form-control" name="orientation" id="orientation">

                        @foreach($orientations as $key => $orientation)
                            @if ($user->orientation == $key)
                                <option value="{{ $key }}" selected>{{ $orientation }}</option>
                            @else
                                <option value="{{ $key }}">{{ $orientation }}</option>
                            @endif

                        @endforeach

                    </select>
                </div>
                <div class="col-sm-6 form-group">
                    <label for="statut">Statut</label>
                    <select class="form-control" name="statut" id="statut">

                        @foreach($status as $key => $statut)
                            @if ($user->statut == $key)
                                <option value="{{ $key }}" selected>{{ $statut }}</option>
                            @else
                                <option value="{{ $key }}">{{ $statut }}</option>
                            @endif

                        @endforeach

                    </select>
                </div>
            </div>

            <div class="row">

                <div class="col-sm-12 form-group">
                    <label for="departement">Département</label>
                    <select class="form-control" name="departement" id="departement">

                        @foreach(getDepartements() as $key => $departement)
                            @if ($user->departement == $key)
                                <option value="{{ $key }}" selected>{{ $departement }} ({{$key}})</option>
                            @else
                                <option value="{{ $key }}">{{ $departement }} ({{$key}})</option>
                            @endif

                        @endforeach

                    </select>
                </div>


                <div class="col-sm-12 form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control"
                              rows="10"
                              id="description"
                              name="description">{{$user->description}}</textarea>
                </div>
            </div>
            <br>
            <button type="submit" class="btn btn-outline-success my-2 my-sm-0">Mettre à jour
            </button>
        </form>

        <!-- Delete -->

        <form action="{{url("account/delete")}}" method="post" class="my-5" id="deleteForm">
            {{csrf_field()}}

            @if(Session::get("account_form", "") === "delete")
                @include("layouts.errors")
            @endif

            <h1>Supprimer mon compte</h1>
            <div class="form-group">
                <label for="password">Mot de passe</label>
                <input type="password" class="form-control" name="password" id="password" required>
            </div>


            <div class="form-check">
                <input type="checkbox"
                       class="form-check-input"
                       id="confirm"
                       name="confirm"
                       v-model="checked"
                       required
                       value="1">
                <label class="form-check-label" for="confirm">Je veux supprimer mon compte.</label>
            </div>

            <button type="submit" class="btn btn-danger" :disabled="!checked">Supprimer mon compte</button>
        </form>

    </div>
@endsection

@push("scripts")
    <script type="text/javascript" src="{{url("js/sceditor/minified/sceditor.min.js")}}"></script>
    <script type="text/javascript" src="{{url("js/sceditor/minified/formats/xhtml.js")}}"></script>
    <script type="text/javascript" src="{{url("js/sceditor/languages/fr.js")}}"></script>
    <script>
        $(function () {
            sceditor.create(document.getElementById("description"), {
                format: "xhtml",
                style: '{{url("js/sceditor/minified/themes/content/default.min.css")}}',
                locale: "fr",
                emoticonsEnabled: false,
                toolbar: "bold,italic,underline,strike,subscript,superscript|left,center,right,justify|font,size,color,removeformat|cut,copy,pastetext|bulletlist,orderedlist|image,link,unlink|date,time"
            });
        });

        new Vue({
            el: "#deleteForm",

            data: {
                checked: false
            }

        });

    </script>
@endpush

@push("css")

    <!-- SCeditor -->
    <link rel="stylesheet" type="text/css" href="{{url("js/sceditor/minified/themes/defaultdark.min.css")}}">
@endpush