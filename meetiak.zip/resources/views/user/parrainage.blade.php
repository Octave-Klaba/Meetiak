@extends("master")

@section("title", "Parrainage")

@section("content")

    <div class="container">
        <!-- Info -->
        <article class="text-center">

            <h3>Parrainage</h3>
            <p class="small">Vous gagnerez {{PARRAIN_MCOINS}} MCoins lorsqu'un filleul valide son email, le filleul
                             gagnera {{FILLEUL_MCOINS}} MCoins.</p>

            <div class="form-group">
                <label for="parrain">Lien de parrainage</label>
                <input type="text"
                       class="form-control"
                       id="parrain"
                       aria-describedby="parrain-help"
                       readonly
                       value="{{url("") . "/?p=" . Auth::user()->parrain_id}}">
                <small id="parrain-help" class="form-text text-muted">Donner ce lien aux personnes que vous voulez
                                                                      parrainer.
                </small>
            </div>

            <hr>

            <h3>Filleuls</h3>
            @if(Auth::user()->filleuls()->count() > 0)

                @foreach(Auth::user()->filleuls as $filleul)

                    @php /**@var \App\Parrainage $filleul*/@endphp

                    <div class="row align-items-center border border-success rounded">

                        <div class="col-6">
                            <div class="rounded m-2 p-2">{!! $filleul->user->link !!}</div>
                        </div>

                        <div class="col-6">
                            <div class="rounded m-2 p-2">{{$filleul->user->confirmed ? "Email vérifié." : "Email non vérifié."}}</div>
                        </div>
                    </div>
                @endforeach

            @else

                Vous n'avez pas de filleuls

            @endif

        </article>
    </div>

@endsection