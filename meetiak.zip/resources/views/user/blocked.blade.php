@extends("master")

@section("title", "Profil de " . $user->pseudo)

@section("content")

    @include("user.signaler")

    <div class="container">
        <div class="alert alert-warning" role="alert">
            Vous ne pouvez pas voir ce profil car vous êtes bloqué par {{$user->pseudo}}.
        </div>


        @if($user->rank <= 2 && ! $user->hasBlocked(auth()->user()))
            <a href="{{url("block?id=".$id)}}" class="btn btn-danger btn-sm m-2">Bloquer
                                                                                 l'utlisateur
            </a>
        @endif

        @if($user->isBlockedBy(auth()->user()))
            <p class="w-100">Vous avez bloqué cette utilisateur.</p>
        @endif

        <button type="button" class="btn btn-danger btn-sm m-2" data-toggle="modal" data-target="#modalSignaler">
            Signaler
        </button>


    </div>

@endsection