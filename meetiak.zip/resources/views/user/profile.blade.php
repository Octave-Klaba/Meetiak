@extends("master")

@section("title", "Profil de " .$user->pseudo)

@section("content")

    @include("user.signaler")

    <!-- Début de page -->
    @php  /**@var App\User $user */ @endphp
    <div class="container">

        @include("layouts.errors")

        <div class="row profile">

            <div class="col col-xl-3">
                <div class="profile-sidebar {{$user->shadow_box}}">
                {{--h4 class="niveau"><font color="#000"><br>{{$user->niveau }}</font></h4> --}}
                <!-- SIDEBAR USERPIC -->
                    <div class="profile-userpic">
                        <div class="center">
                            <img src="{{$user->avatar_link}}">
                        </div>
                    </div>
                    <!-- END SIDEBAR USERPIC -->
                    <!-- SIDEBAR USER TITLE -->
                    <div class="profile-usertitle">
                        <div class="profile-usertitle-name">
                            <!-- Pseudo -->
                        {!! $user->pseudo_style !!}

                        {!! $user->is_online_dot !!}

                        <!-- Sexe -->
                            {!! $user->sexe_icon!!}

                        </div>
                        <div class="profile-usertitle-job">
                            <!-- Titre -->
                            {{$user->titre}}
                        </div>
                    </div>
                    <!-- END SIDEBAR USER TITLE -->
                    <!-- SIDEBAR BUTTONS -->
                    <div class="profile-userbuttons d-flex flex-column flex-md-row flex-wrap justify-content-center">

                        {{-- Si pas soi même--}}
                        @if(auth()->check() && App\User::find(auth()->id())->id != $id)

                            {{-- Si amis --}}
                            @if($user->isFriendWith(App\User::find(auth()->id())))
                                <a class="btn btn-success btn-sm m-2" href="{{ url("conversations/".$user->id) }}">
                                    Écrire
                                </a>

                                {{-- Si bloqué--}}
                            @elseif($user->isBlockedBy(App\User::find(auth()->id())))
                                <p class="w-100">Vous avez bloqué cette utilisateur.</p>

                                {{-- Si demande d'ami envoyer --}}
                            @elseif($user->hasFriendRequestFrom(App\User::find(auth()->id())))
                                <p class="w-100 text-center">Vous avez déjà envoyé une demande d'ami.</p>

                                {{-- Si demamde d'ami reçu --}}
                            @elseif($user->hasSentFriendRequestTo(App\User::find(auth()->id())))
                                <p class="w-100 text-center">{{$user->pseudo}} vous a envoyé une demande d'ami</p>
                                <a href="{{url("friends/requests/accept?id=".$user->id)}}" class="btn btn-success">
                                    Accepter
                                </a>

                                {{-- Si robot --}}
                            @else
                                @if($user->rank < 6)
                                    <a href="{{url("friends/requests/send?id=".$id)}}"
                                       class="btn btn-success btn-sm m-2">Envoyer
                                                                          une demande d'ami
                                    </a>
                                @endif
                            @endif

                            @if($user->rank <= 2 && ! $user->isBlockedBy(App\User::find(auth()->id())))
                                <a href="{{url("block?id=".$id)}}" class="btn btn-danger btn-sm m-2">Bloquer
                                                                                                     l'utlisateur
                                </a>
                            @endif

                            @if($user->rank < 3)
                                <button type="button"
                                        class="btn btn-danger btn-sm m-2"
                                        data-toggle="modal"
                                        data-target="#modalSignaler">
                                    Signaler
                                </button>
                            @endif

                        @endif
                        <br>
                        {{-- Si soi même--}}
                        @if(auth()->check() && App\User::find(auth()->id())->id == $id)
                            <a href="{{url("account")}}" class='btn btn-success btn-sm m-2'>Éditer
                                                                                            mon
                                                                                            profil
                            </a>
                        @endif
                    </div>
                    <!-- END SIDEBAR BUTTONS -->
                    <!-- SIDEBAR MENU -->
                    <div class="profile-usermenu">
                        <hr>

                        <div class="center">{{$user->departement_nom}} ({{$user->departement}})</div>
                        <div class="center">
                            {{$user->age}} ans
                        </div>
                        <div class="center">{{$user->orientation_nom}}</div>
                        <div class="center">
                            <!-- Statut -->
                            {{$user->statut_nom}}
                        </div>
                        <hr>
                        <div class="center">
                        {{-- Réseaux sauciaux --}}
                        @if(auth()->check())
                            <!-- Facebook -->
                                @if(!empty($user->facebook))
                                    <a href="https://www.facebook.com/{{$user->facebook}}" target="_blank">
                                        <font size="6px" color="#29487d"><i class="fab fa-facebook-square"
                                                                            aria-hidden="true"></i></font></a>
                                @endif

                            <!-- Youtube -->
                                @if(!empty($user->youtube))
                                    <a href="https://www.youtube.com/channel/{{$user->youtube}}" target="_blank">
                                        <font size="6px" color="#ff0000"><i class="fab fa-youtube"
                                                                            aria-hidden="true"></i></font></a>
                                @endif

                            <!-- Snapchat -->
                                @if(!empty($user->snapchat))
                                    <a href="https://snapchat.com/add/{{$user->snapchat}}" target="_blank">
                                        <font size="6px" color="#FFFC00"><i class="fab fa-snapchat-square"
                                                                            aria-hidden="true"></i></font></a>
                                @endif

                            <!-- Steam -->
                                @if(!empty($user->steam))
                                    <a href="https://steamcommunity.com/id/{{$user->steam}}" target="_blank">
                                        <font size="6px" color="#000"><i class="fab fa-steam"
                                                                         aria-hidden="true"></i></font></a>
                                @endif

                            <!-- Twitter -->
                                @if(!empty($user->twitter))
                                    <a href="https://twitter.com/{{$user->twitter}}" target="_blank">
                                        <font size="6px" color="#1da1f2"><i class="fab fa-twitter-square"
                                                                            aria-hidden="true"></i></font></a>
                                @endif

                            <!-- Twitch -->
                                @if(!empty($user->twitch))
                                    <a href="https://twitch.tv/{{$user->twitch}}" target="_blank">
                                        <font size="6px" color="#4b367c"><i class="fab fa-twitch"
                                                                            aria-hidden="true"></i></font></a>
                                @endif

                            <!-- Instagram -->
                                @if(!empty($user->instagram))
                                    <a href="https://www.instagram.com/{{$user->instagram}}" target="_blank">
                                        <font size="6px" color="#E70195"><i class="fab fa-instagram"
                                                                            aria-hidden="true"></i></font></a>
                                @endif
                            @else
                                <p>Veuillez vous <a href="{{url("auth/login")}}">connecter</a> pour voir les réseaux
                                   sociaux de cet utilisateur.</p>
                            @endif


                        </div>
                    </div>
                    <!-- END MENU -->
                </div>

                <div class="center"><!-- Ban button -->
                @if(auth()->check() && App\User::find(auth()->id())->rank >= 4)
                    <!-- TODO Ajouté lien -->
                        <div class='ban my-2'>
                            <button role='button' class='btn btn-danger btn-sm m-2' id="ban">Bannir</button>
                        </div>
                    @endif
                </div>

            </div>

            <div class="col col-xl-9">
                <div class="profile-content">
                    <h3>Description :</h3>
                    <!-- Description -->
                    {!! clean($user->description) !!}
                    <hr>
                    <div class="m-2">
                        @foreach($user->badges as $badge)
                            <img src="{{asset($badge->image)}}"
                                 alt="{{$badge->nom}}"
                                 class="m-1 img-thumbnail img-badge"
                                 title="{{$badge->nom}}"
                                 data-toggle="popover"
                                 data-trigger="hover"
                                 data-placement="bottom"
                                 data-content="{{$badge->description}}">
                        @endforeach
                    </div>

                    @if(isset($user->confirmed_at) && !empty($user->confirmed_at))
                        <div class="center">
                            <small>Inscrit le :
                                {{\Carbon\Carbon::parse($user->confirmed_at)->format("d/m/Y")}}</small>
                        </div>
                    @endif
                </div>

            </div>
        </div>
    </div>


@endsection

@push("scripts")
    <script>
        $(function () {
            $("[data-toggle=\"popover\"]").popover();

            @if(auth()->check() && App\User::find(auth()->id())->rank >= 4)

            $("#ban").click(function () {
                if (confirm("Bannir {{$user->pseudo}}?")) {
                    var url = '{{url("/admin/ban")}}';
                    var form = $("<form action=\"" + url + "\" method=\"post\">" +
                        '<input type="hidden" name="id" value="{{$user->id}}" />' +
                        '<input type="hidden" name="_token" value="{{csrf_token()}}" />' +
                        "</form>");
                    $("body").append(form);
                    form.submit();
                }
            });

            @endif

        });
    </script>
@endpush