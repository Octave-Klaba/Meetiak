@extends("master")

@section("title", "Règlement")

@section("content")

    <div class="container">
        <h1>Règlement :</h1>
        <p>Voici le règlement de MeetiaK, chaque enfrein du règlement emmènera à des sanctions voir au bannissement
           de votre compte, veillez donc à le respecter et à le regarder régulièrement car des modifications peuvent
           être apportées régulièrement.</p>

        <p>A noter qu’en vous inscrivant sur MeetiaK vous acceptez ce dit règlement.</p>

        <ol>
            <br>
            <li><h3><strong>Règlement Général :</strong></h3>
                <ul>
                    <li>Il est interdit d’avoir plusieurs comptes MeetiaK.</li>
                    <li>Les mineurs doivent s’inscrire sur MeetiaK uniquement après avoir eu l’accord d’un
                        responsable légal.
                    </li>
                    <li> Il est interdit de remplir son profil avec de fausses informations.</li>
                    <li> Aucunes informations personnelles (mail, téléphone, adresse) autre que les réseaux sociaux
                         proposés
                         par MeetiaK ne doivent être communiqués publiquement.
                    </li>
                    <li>Il est strictement interdit de tenir des propos discriminatoires.</li>
                    <li>Il est strictement interdit de parler de religion, drogue, piratage, voyeurisme ou autres sujets
                        malveillants en public.
                    </li>
                    <li>Il est interdit de demander des plans cam ou des rencontres en public.</li>
                    <li>Partager son compte MeetiaK est strictement interdit.</li>
                    <li>Il est interdit en public de s’exprimer autrement qu’en Français.</li>
                </ul>
            </li>
            <br>
            <li><h3><strong>Règlement sur les photos :</strong></h3>
                <ul>
                    <li>Il est interdit de poster des photos dénudées de vous, en sous-vêtements, ou dans des postures
                        osées.
                    </li>
                    <li>Vous devez posséder les droits sur la photo que vous postez.</li>
                    <li>Aucune photo avec armes, même factices ne sera tolérée.</li>
                    <li>S’afficher avec des billets de banque est strictement interdit.</li>
                    <li>Doigts d’honneur et autres gestes déplacés sont interdit.</li>
                    <li>Interdiction de poster une photo en double.</li>
                </ul>
            </li>
            <br>
            <li><h3><strong>Règlement relatif au chat :</strong></h3>
                <ul>
                    <li>Le flood et le spam sont interdit.</li>
                    <li>Est considéré comme spam l’utilisation abusive de majuscules dans un message et le language SMS
                        à trop grande échelle.
                    </li>
                </ul>
            </li>

        </ol>
        <p> Dans le cas où vous pensez être sanctionné à tort par un membre de l’équipe MeetiaK, nous vous
            invitons à
            contacter Omnes en mp via le site où par mail à l’adresse : reclamation@meetiak.fr</p>
    </div>
@endsection
