@extends("master")

@section("title", "503")

@section("content")
    <center><h1 style=" margin-top: 40vh; transform: translateY(-50%);">Le site est en maintenance.</h1>
    </center>
@endsection