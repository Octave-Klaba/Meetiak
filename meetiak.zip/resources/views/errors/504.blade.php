@extends("master")

@section("title", "504")

@section("content")
    <center><h1 style=" margin-top: 40vh; transform: translateY(-50%);">D'oh ! Le serveur a pris des vacances on dirais
                                                                        !</h1></center>
@endsection