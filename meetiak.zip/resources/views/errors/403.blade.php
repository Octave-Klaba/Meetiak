@extends("master")

@section("title", "403")

@section("content")
    <center><h1 style=" margin-top: 40vh; transform: translateY(-50%);">Tu sais que tu n'as pas le droit d'être ici
                                                                        ?</h1></center>
@endsection