@extends("master")

@section("title", "404")

@section("content")
    <center><h1 style=" margin-top: 40vh; transform: translateY(-50%);">OUUUUUPS, tu t'es perdu jeune padawan ?</h1>
    </center>
@endsection