@extends("master")

@section("title", "500")

@section("content")
    <center><h1 style=" margin-top: 40vh; transform: translateY(-50%);">Si tu vois cette page c'est qu'Omnes a tout
                                                                        cassé, appel Bibo pour tout réparer !</h1>
    </center>
@endsection