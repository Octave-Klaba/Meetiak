@extends("master")

@section("title", "419")

@section("content")
    <center><h1 style=" margin-top: 40vh; transform: translateY(-50%);">La session a expiré, merci de recharger la
                                                                        page.</h1></center>
@endsection