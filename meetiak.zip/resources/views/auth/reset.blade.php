@extends("master")

@section("title", "Reinitialisation du mot de passe")

@section("content")
    <div class="container">
        <h1>Changement de mot de passe</h1>
        <form action="{{url("auth/reset")}}" method="post">
            {{csrf_field()}}
            <input type="hidden" name="token" value="{{$token}}">
            <div class="form-group">
                <label for="password">Nouveau mot de passe</label>
                <input type="password" id="password" name="password" class="form-control" required/>
            </div>
            <div class="form-group">
                <label for="password_confirmation">Confirmation</label>
                <input type="password"
                       name="password_confirmation"
                       id="password_confirmation"
                       class="form-control"
                       required/>
            </div>
            <button type="submit" class="btn btn-outline-success my-2 my-sm-0">Changer de mot de passe
            </button>
        </form>
    </div>
@endsection