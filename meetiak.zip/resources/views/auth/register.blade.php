@extends("master")

@section("title", "Inscription")

@section("content")

    <div class="container">
        <h1>S'inscrire</h1>
        <form id="form" action="{{url("auth/register")}}" method="post">
            {{csrf_field()}}
            <div class="row">
                <div class="form-group">
                    @include("layouts.errors")
                </div>
            </div>

            <div class="row">

                <!-- Pseudo -->
                <div class="col-sm-6 form-group">
                    <label for="pseudo">Pseudo</label>
                    <span class="required"> *</span>
                    <input id="pseudo"
                           type="text"
                           name="pseudo"
                           class="form-control"
                           value="{{old("pseudo")}}"
                           required/>
                </div>

                <!-- Email -->
                <div class="col-sm-6 form-group">
                    <label for="email">Email</label>
                    <span class="required"> *</span>
                    <input id="email" type="email" name="email" class="form-control" value="{{old("email")}}" required/>
                </div>

            </div>
            <div class="row">

                <!-- Password -->
                <div class="col-sm-6 form-group">
                    <label for="password">Mot de passe</label>
                    <span class="required"> *</span>
                    <input id="password" type="password" name="password" class="form-control" required/>
                </div>

                <!-- Password Confirmation -->
                <div class="col-sm-6 form-group">
                    <label for="password_confirmation">Confirmation du mot de passe</label>
                    <span class="required"> *</span>
                    <input id="password_confirmation"
                           type="password"
                           name="password_confirmation"
                           class="form-control"
                           required/>
                </div>

            </div>
            <div class="row">

                <!-- Date de Naissance -->
                <div class="col-sm-4 form-group">
                    <label for="ddn"
                           data-toggle="tooltip"
                           data-placement="top"
                           title="Si vous êtes sur safari : format yyyy-mm-dd">Date de naissance</label>
                    <span class="required"> *</span>
                    <input id="ddn" type="date" name="ddn" class="form-control" value="{{old("ddn")}}" required>
                </div>


                <!-- Sexe -->
                <div class="col-sm-4 form-group">
                    <label for="sexe">Sexe</label>
                    <span class="required"> *</span>
                    <select class="form-control" id="sexe" name="sexe" size="1">
                        @foreach($sexes as $key => $sexe)
                            @if (old('sexe') == $key)
                                <option value="{{ $key }}" selected>{{ $sexe }}</option>
                            @else
                                <option value="{{ $key }}">{{ $sexe }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>

                <!-- Departement-->
                <div class="col-sm-4 form-group">
                    <label for="departement">Département</label>
                    <span class="required"> *</span>
                    <select class="form-control" name="departement" id="departement">
                        @foreach($departements as $key => $dep)
                            @if (old('departement') == $key)
                                <option value="{{ $key }}" selected>{{ $dep }} ({{$key}})
                                </option>
                            @else
                                <option value="{{ $key }}">{{ $dep }} ({{$key}})</option>
                            @endif
                        @endforeach
                    </select>
                </div>

                <!-- Orientation-->
                <div class="col-sm-8 form-group">
                    <label for="orientation">Orientation Sexuelle</label>
                    <span class="required"> *</span>
                    <select class="form-control" name="orientation" id="orientation">
                        @foreach($orientations as $key => $or)
                            @if (old('orientation') == $key)
                                <option value="{{ $key }}" selected>{{ $or }}</option>
                            @else
                                <option value="{{ $key }}">{{ $or }}</option>
                            @endif
                        @endforeach
                    </select>
                </div>

            </div>

            @if(config("app.use_recaptcha"))
                {!! Recaptcha::render([ 'lang' => 'fr' ]) !!}
            @endif

            <div id="app">
                <div class="row">

                    <!-- Réglement -->
                    <div class="form-check col-sm-12">
                        <input class="form-check-input"
                               type="checkbox"
                               value="1"
                               id="rules"
                               name="rules"
                               v-model="rulesChecked">
                        <label class="form-check-label" for="rules">
                            En cochant cette case vous assurez avoir lu et accepté le
                            <a href="{{url("/rules")}}">Règlement</a> et les <a href="{{url("/cgu")}}">CGU</a>.
                            <span class="required"> *</span>
                        </label>
                    </div>

                </div>

                <button type="submit"
                        dusk="submit"
                        class="btn btn-outline-success my-2 my-sm-0"
                        :disabled="!rulesChecked">M'inscrire
                </button>

            </div>

            <small>Les champs marqués de
                <span class="required"> *</span>
                   sont obligatoires.
            </small>
        </form>
    </div>
@endsection

@push("scripts")
    <script>

        new Vue({
            el: "#app",
            data: {
                rulesChecked: false
            },

            mounted: function () {
                $("[data-toggle=\"tooltip\"]").tooltip();
            }
        });
    </script>
@endpush