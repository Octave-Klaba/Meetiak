@extends("master")

@section("title", "Mot de passe oublié")

@section("content")
    <div class="container">

        <div class="alert alert-info" role="alert">
            <strong>Un email avec un lien de récupération sera envoyer.</strong>
        </div>

        <form action="{{url("auth/forgot")}}" method="post">
            {{csrf_field()}}

            <div class="form-group">
                @include("layouts.errors")
            </div>

            <div class="form-group">
                <label for="email">Adresse Email</label>
                <input type="email" class="form-control" id="email" name="email" value="{{old("email")}}" required>
            </div>
            <button type="submit" class="btn btn-outline-success">Envoyer
            </button>
        </form>

    </div>
@endsection