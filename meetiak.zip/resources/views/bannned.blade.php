@extends("master")

@section("title", "Banni")

@section("content")
    <div class="container">
        <div class="alert alert-danger" role="alert">
            <strong>Vous êtes banni!</strong>
            <br>
            <a href="{{url("/rules")}}" class="alert-link">Règlement</a>
        </div>
    </div>

@endsection