@extends("master")

@section("title", "Admin")

@section("content")

    <div class="container" id="app">

        <tabs>

            <tab name="Signalement" @selected="getReports" :selected="true">

                <h1>Demande de signalement</h1>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="thead-light">

                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Créer par</th>
                            <th scope="col">Pour</th>
                            <th scope="col">Raison</th>
                            <th scope="col">Date et heure</th>
                            <th scope="col"></th>
                        </tr>

                        </thead>

                        <tbody>

                        <tr v-for="report in reportsArray">

                            <td v-text="report.id"></td>
                            <td><a :href="userLink(report.from_user)" v-text="report.from_pseudo"></a></td>
                            <td><a :href="userLink(report.to_user)" v-text="report.to_pseudo"></a></td>
                            <td v-text="report.raison"></td>
                            <td v-text="report.created_at"></td>
                            <td>
                                <button type="button" class="btn btn-danger" @click="deleteReport(report.id)">
                                    <i class="fa fa-times" aria-hidden="true"></i>
                                </button>
                            </td>

                        </tr>

                        </tbody>
                    </table>
                </div>


            </tab>

            <tab name="ban">
                <h1>Ban</h1>
            </tab>

        </tabs>


    </div>

@endsection

@push("scripts")
    <script !src="">
        var _token = "{{csrf_token()}}";

        var reports_url = "{{url("/admin/report")}}";
        var userUrl = "{{url("/user")}}";
    </script>

    <script src="{{url("js/tabs.js")}}"></script>
    <script src="{{url("js/adminIndex.js")}}"></script>

@endpush