@extends("master")

@section("title", "Confirmation du payment")

@section("content")
    @php  /** @var App\Order $order */ @endphp
    <div class="container">

        @if(session()->has('message'))
            <p class="message">Message de Paypal :
                {{ session('message') }}
            </p>
        @endif

        <div class="border border-success rounded m-2 p-2">
            Prix : {{$order->amount}} €
            <br>
            Mcoins : {{$order->mcoins}}
        </div>

        <a href="{{url("paypal/pay", $order->uuid)}}" class="btn btn-success">Continuer</a>

    </div>
@endsection