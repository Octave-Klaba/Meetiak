@extends("master")

@section("title", "Forum")

@section("content")

    <div class="container" id="app">

        <transition name="fade" mode="out-in">
            <router-view></router-view>
        </transition>
    </div>

@endsection

@push("scripts")
    <script>
        var _token = {!!  json_encode(csrf_token())!!};

        var tiltleEnd = " - Meetiak site de rencontre pour ados gratuit !";

        var categoriesPosts = {!! json_encode($categories) !!};

        var getPostUrl = {!! json_encode(url("forum/get/post")) !!};
        var getCategoryUrl = {!! json_encode(url("forum/get/category")) !!};
        var CreateUrl = {!! json_encode(url("forum/create/post")) !!};
        var CreateMessageUrl = {!! json_encode(url("forum/create/message")) !!};
    </script>

    <script src="{{asset("js/forum.js")}}"></script>
@endpush

@push("css")
    <style>
        .fade-enter-active {
            animation: fadeIn 0.5s;
        }

        .fade-leave-active {
            animation: fadeOut 0.5s;
        }
    </style>
@endpush