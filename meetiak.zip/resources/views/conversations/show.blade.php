@extends("master")

@section("title", "MP de " .$user->pseudo)

@section("content")

    @php  /**@var App\User $user */ @endphp
    <div class="container">
        <div class="row">

            @include('conversations.users', compact("friends"))

            <div class="col-md-9" id="app">
                <div class="card-header">
                    <a href="{{ url("user/".$user->id) }}">

                        <img class="photoconversationlittle" src="{{$user->avatar_link}}"/>
                        {!! $user->pseudo_style !!}

                    </a>
                </div>

                <div class="card-body conversations">
                    <messages :self-id="{{auth()->id()}}" v-cloak></messages>

                    <form @submit.prevent="sendMessage">
                        <div class="form-group">
                            <input type="text"
                                   name="content"
                                   placeholder="Votre message ici..."
                                   class="form-control"
                                   v-model="messageInput"
                                   autocomplete="off">

                        </div>
                        <button class="btn btn-success" type="submit">Envoyer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    @push("scripts")
        <script>
            var _token = "{{csrf_token()}}";
            var getMessagesUrl = "{{url("conversations/". $user->id ."/get")}}";
            var addMessagesUrl = "{{url("conversations/". $user->id ."/add")}}";
        </script>
        <script src="{{asset("js/conversation.js")}}"></script>
    @endpush
@endsection