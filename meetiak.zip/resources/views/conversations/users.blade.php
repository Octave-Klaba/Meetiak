<div class="col-md-3">
    <div class="list-group my-2" id="users-list">

        @if($friends->count() === 0)
            <p class="text-center mx-auto my-2">Ajouter des amis pour pouvoir discuter.</p>
        @endif

        @foreach($friends as /** @var App\User $friend */$friend)

            <a class="list-group-item d-flex justify-content-between align-items-center"
               href="{{ route('conversations.show', $friend->id)}}">

                <img class="photoconversationlittle" src="{{$friend->avatar_link}}"/>
                {!! $friend->pseudo_style !!}

                <span class="badge badge-pill badge-success"
                      v-if="unread[ {{$friend->id}} ] > 0"
                      v-text="unread[ {{$friend->id}} ]">

                    </span>

            </a>

        @endforeach

    </div>
</div>

@push("scripts")

    <script>var unreadUrl = "{{url("conversations/unread/all/user")}}";</script>
    <script src="{{asset("js/conversations-users-unread.js")}}"></script>

@endpush
