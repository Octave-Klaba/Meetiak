@extends("master")

@section("title", "Messages Privés")

@section("content")
    <div class="container">
        @include('conversations.users', compact("friends"))
    </div>

@endsection