@extends("master")

@section("title", "Boutique")

@section("content")
    <div id="app">
        <div class="container">
            <div class="row">
                @foreach($items as /** @var App\Boutique $item */ $item)
                    <div class="col-md-6 col-12">
                        <div class="rounded border border-success m-2 p-2 d-flex flex-column align-items-center text-center boutique-item">

                            <div class="m-2 p-2 rounded border {{empty($item->html) ? "invisible" : ""}}">{!! $item->html !!}</div>

                            <h4 class="m-1">{{$item->nom}}</h4>
                            <div class="m-1">{{$item->description}}</div>

                            <div class="m-1 {{$item->jours === 0 ? "invisible" : ""}} ">Durée :
                                <span class="font-weight-bold">{{$item->jours}}</span> jours.
                            </div>
                            <div class="m-1"><span class="font-weight-bold">{{$item->prix}}</span> mcoins.</div>

                            <button class="btn btn-success m-2"
                                    {{(Auth::user()->mcoins < $item->prix or Auth::user()->hasBoutique($item->nom_id)) ? "disabled" : ""}} @click="purchase('{{$item->nom_id}}')">
                                Acheter
                            </button>

                            {{-- Si l'utilisateur à déjà le produit --}}
                            @if(Auth::user()->hasBoutique($item->nom_id))
                                <div class="text-danger small">Vous avez déjà ce produit.</div>

                                {{-- Si pas assez de mcoins --}}
                            @elseif(Auth::user()->mcoins < $item->prix)
                                <div class="text-danger small">Vous n'avez pas assez de mcoins.</div>
                            @endif


                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

@endsection

@push("scripts")

    <script>
        var _token = {!! json_encode(csrf_token()) !!};
        var purchaseUrl = {!! json_encode(url("boutique/purchase")) !!};
    </script>
    <script src="{{asset("js/boutique.js")}}"></script>

@endpush

@push("css")

    <style>
        .slide-right-enter-active {
            animation: fadeInRight .5s;
        }

        .slide-right-leave-active {
            animation: fadeOutLeft .5s;
        }

        .slide-left-enter-active {
            animation: fadeInLeft .5s;
        }

        .slide-left-leave-active {
            animation: fadeOutRight .5s;
        }


    </style>

@endpush