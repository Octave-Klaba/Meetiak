@extends("master")

@section("title", "Mcoins")

@section("content")
    <div class="container mcoins" id="app" v-cloak>
        <div class="row mcoins">

            <div class="col-md-3 col-12 mb-5">
                <div class="list-group">
                    <router-link to="/" class="list-group-item list-group-item-action">
                        Historique mcoins
                    </router-link>

                    <router-link to="/produits" class="list-group-item list-group-item-action">
                        Produits
                    </router-link>

                    <router-link to="acheter" class="list-group-item list-group-item-action">
                        Acheter des mcoins
                    </router-link>

                    <router-link to="achats" class="list-group-item list-group-item-action">
                        Historique des achats
                    </router-link>
                </div>
            </div>

            <div class="col-md-9 col-12">

                <transition :name="transitionName" mode="out-in">
                    <router-view></router-view>
                </transition>

            </div>

        </div>
    </div>

@endsection

@push("scripts")
    <script>
        var mcoinsHistory = {!! /** @var \Illuminate\Support\Collection $mcoinsHistory */$mcoinsHistory->toJson() !!};
        var produits = {!! /** @var \Illuminate\Support\Collection $produits */$produits->toJson() !!};
        var mcoinsPrix = {!! /** @var \Illuminate\Support\Collection $mcoinsPrix */$mcoinsPrix->toJson() !!};
        var ordersHistory = {!! /** @var \Illuminate\Support\Collection $orders */$orders->toJson() !!};
        var ordersCancelled = {!! /** @var \Illuminate\Support\Collection $ordersCancelled */$ordersCancelled->toJson() !!};

        var orderUrl = {!! json_encode(url("order/create/")) !!};
    </script>
    <script src="{{asset("js/mcoins.js")}}"></script>
@endpush
