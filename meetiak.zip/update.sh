#!/bin/bash
php artisan down

git stash
git pull
git stash clear

composer install --no-dev -o
composer update --no-dev -o

php artisan package:discover


if command -v yarn &>/dev/null; then

    yarn install --production=true
    yarn upgrade --production=true

else

    npm install --production
    npm update --production
    
fi


php artisan config:cache
php artisan route:cache

php artisan update:badges
php artisan update:boutique
php artisan update:categories

php artisan up

touch /var/cache/mod_pagespeed/cache.flush

sudo chgrp -R www-data storage bootstrap/cache
sudo chmod -R ug+rwx storage bootstrap/cache
