<?php

use Illuminate\Database\Seeder;

class ForumSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();

        //Posts
        for ($i = 0; $i < 50; $i++) {

            $post = new \App\ForumPost();

            $post->title = $faker->sentence();

            $post->user()->associate(\App\User::all()->random()->id);
            $post->category_id = App\ForumCategory::all()->random()->id;

            $post->save();

            //Premier message
            $message = new \App\ForumMessage();

            $message->message = $faker->paragraph;

            $message->user()->associate($post->user);
            $message->post()->associate($post);

            $message->save();

        }

        //Messages
        for ($i = 0; $i < 500; $i++) {

            $message = new \App\ForumMessage();

            $message->message = $faker->paragraph;

            $message->user()->associate(\App\User::all()->random()->id);
            $message->post()->associate(\App\ForumPost::all()->random()->id);

            $message->save();

        }
    }
}
