<?php

use Illuminate\Database\Seeder;

class ConversationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 200; $i++) {

            DB::table("messages")->insert(
                [
                    "to_user" => $faker->numberBetween(1, 2),
                    "from_user" => $faker->numberBetween(1, 2),
                    "content" => $faker->paragraph(),
                    "created_at" => DB::raw("NOW()")
                ]
            );
        }
    }
}
