<?php

use Illuminate\Database\Seeder;

class geekfound extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        $faker = Faker\Factory::create();

        $dep = array_keys(getDepartements());
        $or = array_keys(getOrientations());

        for ($i = 0; $i < 200; $i++) {

            shuffle($dep);
            shuffle($or);

            DB::table("users")->insert(
                [
                    "pseudo" => $faker->unique()->userName,
                    "email" => $faker->unique()->email,
                    "password" => password_hash($faker->password(), PASSWORD_DEFAULT),
                    "sexe" => $faker->numberBetween(0, 2),
                    "ddn" => $faker->dateTimeBetween('-50 years', 'now'),
                    "confirmed_at" => $faker->dateTime(),
                    "description" => $faker->paragraph(2),
                    "departement" => $dep[0],
                    "orientation" => $or[0],
                    "last_ip" => $faker->ipv6,
                    "parrain_id" => createUniqueToken("users", "parrain_id", 20)
                ]
            );
        }

        //Admin
        /*DB::table("users")->insert([
            "pseudo" => "admin",
            "email" => "bibo5088@gmail.com",
            "password" => bcrypt("123"),
            "sexe" => $faker->numberBetween(0, 2),
            "ddn" => $faker->date(),
            "confirmed_at" => $faker->dateTime(),
            "confirmed" => true,
            "description" => $faker->paragraph(2),
            "departement" => '01',
            "orientation" => 1,
            "rank" => 5,
            "last_ip" => $faker->ipv6
        ]);*/
    }
}
