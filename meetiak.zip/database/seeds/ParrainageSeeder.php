<?php

use Illuminate\Database\Seeder;

class ParrainageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 20; $i++) {

            DB::table("parrainages")->insert(
                [
                    "user_id" => $faker->unique()->numberBetween(3, 100),
                    "parrain_id" => \App\User::find(1)->parrain_id,
                    "created_at" => DB::raw("NOW()"),
                    "updated_at" => DB::raw("NOW()"),
                ]
            );

        }
    }
}
