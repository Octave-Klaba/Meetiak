 <?php

use App\User;
use Illuminate\Database\Seeder;

class FriendsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 25; $i++) {

            $user1 = User::find($faker->unique()->numberBetween(3, 200));
            $user2 = User::find(1);

            $user1->befriend($user2);

            $rand = rand(0, 2);

            switch ($rand) {

                case(0):
                    $user2->acceptFriendRequest($user1);
                    break;

                case(1):
                    $user2->denyFriendRequest($user1);
                    break;
            }


        }

        //1 et 2
        User::find(2)->befriend(User::find(1));
        User::find(1)->acceptFriendRequest(User::find(2));


        /*            DB::table("friends")->insert(
                        [
                            "from_user" => $faker->unique()->numberBetween(3, 200),
                            "to_user" => 1,
                            "status" => $faker->numberBetween(1, 2),
                        ]
                    );



                    DB::table("friends")->insert(
                        [
                            "from_user" => 1,
                            "to_user" => $faker->unique()->numberBetween(3, 200),
                            "status" => 1,
                        ]
                    );

                    DB::table("block")->insert([
                        "from_user" => $faker->unique()->numberBetween(3, 200),
                        "to_user" => $faker->unique()->numberBetween(3, 200),
                    ]);

                }

                //1 et 2
                DB::table("friends")->insert(
                    [
                        "from_user" => 1,
                        "to_user" => 2,
                        "status" => 2,
                    ]
                );*/
    }
}
