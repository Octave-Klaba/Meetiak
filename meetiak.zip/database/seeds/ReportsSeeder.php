<?php

use Illuminate\Database\Seeder;

class ReportsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 100; $i++) {

            DB::table("reports")->insert(
                [
                    "from_user" => $faker->numberBetween(1, 100),
                    "to_user" => $faker->numberBetween(1, 100),
                    "raison" => $faker->paragraph("1"),
                ]
            );

        }
    }
}
