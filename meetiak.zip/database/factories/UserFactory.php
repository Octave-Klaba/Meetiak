<?php

use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(App\User::class, function (Faker $faker) {

    return [
        "pseudo" => $faker->unique()->userName,
        "email" => $faker->unique()->email,
        "password" => bcrypt($faker->password),
        "sexe" => $faker->numberBetween(0, 2),
        "ddn" => $faker->date(),
        "confirmed_at" => $faker->dateTime(),
        "confirmed" => true,
        "description" => $faker->paragraph(2),
        "departement" => '01',
        "orientation" => 1,
        "rank" => 1,
        "last_ip" => $faker->ipv6,
        "avatar" => "public/avatars/default.png",
        "parrain_id" => createUniqueToken("users", "parrain_id", 20)
    ];
});
