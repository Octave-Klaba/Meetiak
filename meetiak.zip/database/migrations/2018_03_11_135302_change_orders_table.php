<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->string("uuid")->unique();
            $table->integer("mcoins");

            $table->float("amount")->change();

            $table->renameColumn("user", "user_id");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn("uuid");
            $table->dropColumn("mcoins");

            $table->integer("amount")->change();

            $table->renameColumn("user_id", "user");
        });
    }
}
