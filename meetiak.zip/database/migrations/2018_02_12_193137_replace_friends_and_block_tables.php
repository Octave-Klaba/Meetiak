<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

class ReplaceFriendsAndBlockTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //Migration block
        $blocks = DB::table("block")->whereNull("deleted_at")->get();

        foreach ($blocks as $block) {
            DB::table(config('friendships.tables.fr_pivot'))->insert([
                "sender_id" => $block->from_user,
                "sender_type" => \App\User::class,

                "recipient_id" => $block->to_user,
                "recipient_type" => \App\User::class,

                "status" => \Hootlex\Friendships\Status::BLOCKED,

                "created_at" => $block->created_at,
                "updated_at" => $block->updated_at
            ]);
        }

        //Migration friends
        $friends = DB::table("friends")->whereNull("deleted_at")->get();

        foreach ($friends as $friend) {

            $status = $friend->status === 1 ? \Hootlex\Friendships\Status::PENDING : \Hootlex\Friendships\Status::ACCEPTED;

            DB::table(config('friendships.tables.fr_pivot'))->insert([
                "sender_id" => $friend->from_user,
                "sender_type" => \App\User::class,

                "recipient_id" => $friend->to_user,
                "recipient_type" => \App\User::class,

                "status" => $status,

                "created_at" => $friend->created_at,
                "updated_at" => $friend->updated_at
            ]);
        }

        Schema::dropIfExists("block");
        Schema::dropIfExists("friends");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $block = new CreateBlockTable();
        $block->up();

        $friends = new CreateTableFriends();
        $friends->up();
    }
}
