<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateParrainagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table("users", function (Blueprint $table) {
            $table->string("parrain_id");
        });

        //Génère les parrain_id
        \App\User::each(function (\App\User $user) {
            $user->parrain_id = createUniqueToken("users", "parrain_id", 20);
            $user->save();
        });


        Schema::table("users", function (Blueprint $table) {
            $table->unique("parrain_id");
        });


        Schema::create('parrainages', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('user_id')->unsigned();
            $table->foreign('user_id')->references('id')->on('users')->onDelete("CASCADE");

            $table->string("parrain_id");
            $table->foreign('parrain_id')->references('parrain_id')->on('users')->onDelete("CASCADE");

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('parrainages');

        Schema::table("users", function (Blueprint $table) {
            $table->dropColumn("parrain_id");
        });

    }
}
