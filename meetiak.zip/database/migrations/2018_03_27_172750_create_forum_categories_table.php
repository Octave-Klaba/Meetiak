<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateForumCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('forum_categories', function (Blueprint $table) {
            $table->increments('id');

            $table->string("title");
            $table->text("description");

            $table->boolean("locked")->default(false);

            $table->timestamps();
        });

        Schema::table('forum_posts', function (Blueprint $table) {

            $table->integer("category_id")->unsigned();
            $table->foreign("category_id")->references('id')->on('forum_categories')->onDelete("CASCADE");

        });

        \Illuminate\Support\Facades\Artisan::call("update:categories");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('forum_posts', function (Blueprint $table) {

            $table->dropForeign("forum_posts_category_id_foreign");
            $table->dropColumn("category_id");

        });

        Schema::dropIfExists('forum_categories');
    }
}
