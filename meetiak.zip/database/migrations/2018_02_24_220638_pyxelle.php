<?php

use Illuminate\Database\Migrations\Migration;

class Pyxelle extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::table("users")->insert([
            "id" => "0",
            "pseudo" => "🤖 Pyxelle",
            "email" => "0",
            "password" => "0",
            "ddn" => DB::raw("NOW()"),
            "sexe" => 2,
            "avatar" => "public/avatars/pyxelle.png",
            "departement" => "00",
            "orientation" => 11,
            "statut" => 3,
            "rank" => 6,
            "confirmation_token" => NULL,
            "confirmed" => true,
            "confirmed_at" => DB::raw("NOW()"),
            "last_ip" => "0",
            "referer" => "0"
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::table("users")->where("pseudo", "🤖Pyxelle")->delete();
    }
}
