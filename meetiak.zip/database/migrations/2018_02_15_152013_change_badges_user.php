<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class ChangeBadgesUser extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::rename("badges_users", "badge_user");

        Schema::table("badge_user", function (\Illuminate\Database\Schema\Blueprint $table) {
            $table->dropColumn("deleted_at");
        });

        Schema::table("badges", function (\Illuminate\Database\Schema\Blueprint $table) {
            $table->dropColumn("created_at");
            $table->dropColumn("updated_at");

        });

        DB::table("badge_user")->delete();

        exec("php " . __DIR__ . "../../../artisan update:badges");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::rename("badge_user", "badges_users");
    }
}
