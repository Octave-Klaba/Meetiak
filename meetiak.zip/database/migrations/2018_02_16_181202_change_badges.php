<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ChangeBadges extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::table("badge_user")->truncate();

        Schema::table('badges', function (Blueprint $table) {
            $table->string("nom_id");
            $table->unique("nom_id");

        });

        Schema::table('badge_user', function (Blueprint $table) {
            $table->dropForeign("badges_users_badge_id_foreign");
            $table->dropColumn("badge_id");

        });

        Schema::table('badge_user', function (Blueprint $table) {
            $table->string('badge_id');
            $table->foreign('badge_id')->references('nom_id')->on('badges')->onDelete("CASCADE");

        });

        exec("php " . __DIR__ . "../../../artisan update:badges");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        Schema::table('badge_user', function (Blueprint $table) {
            $table->dropForeign("badge_user_badge_id_foreign");
            $table->dropColumn("badge_id");

        });
        DB::table("badge_user")->truncate();
        DB::table("badges")->truncate();

        Schema::table('badge_user', function (Blueprint $table) {
            $table->integer('badge_id')->unsigned();
            $table->foreign('badge_id')->references('id')->on('badges')->onDelete("CASCADE")->default(1);

        });

        Schema::table('badges', function (Blueprint $table) {
            $table->dropColumn("nom_id");
        });

        exec("php " . __DIR__ . "../../../artisan update:badges");
    }
}
