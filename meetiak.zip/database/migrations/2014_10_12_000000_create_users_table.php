<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {

            $table->increments('id');
            $table->string('pseudo')->collation("utf8mb4_bin");
            $table->string('email')->unique()->collation("utf8mb4_bin");
            $table->string('password');
            $table->rememberToken();

            $table->date('ddn');
            $table->integer('sexe');
            $table->integer('orientation')->default('1');
            $table->integer('statut')->default('1');
            $table->string('departement')->default(null)->nullable();
            $table->text('description')->nullable();
            $table->integer('niveau')->default('1');
            $table->integer('rank')->default('1');

            $table->string('confirmation_token', 60)->default(null)->nullable()->collation("utf8mb4_bin");

            $table->dateTime('confirmed_at')->default(null)->nullable();
            $table->boolean('confirmed')->default(false);
            $table->dateTime('reset_at')->default(null)->nullable();
            $table->string('last_ip')->nullable();

            $table->text('referer')->nullable()->default(null);
            $table->string('avatar')->default('public/avatars/default.png');

            $table->text('facebook')->nullable();
            $table->text('youtube')->nullable();
            $table->text('snapchat')->nullable();
            $table->text('steam')->nullable();
            $table->text('twitter')->nullable();
            $table->text('twitch')->nullable();

            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));

            $table->timestamp('last_online')->useCurrent();
        });

        //Admin
        if (App::environment("local")) {
            $faker = Faker\Factory::create();

            DB::table("users")->insert([
                "pseudo" => "admin",
                "email" => "admin@exemple.com",
                "password" => bcrypt("123"),
                "sexe" => $faker->numberBetween(0, 2),
                "ddn" => $faker->date(),
                "confirmed_at" => $faker->dateTime(),
                "confirmed" => true,
                "description" => $faker->paragraph(2),
                "departement" => '01',
                "orientation" => 1,
                "rank" => 5,
                "last_ip" => $faker->ipv6
            ]);
        }


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
