<?php

namespace Tests\Browser;

use App\Repository\UserRepository;
use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use Illuminate\Foundation\Testing\DatabaseMigrations;


class RegisterTest extends DuskTestCase
{
    use DatabaseMigrations;

    /**
     * A Dusk test example.
     *
     * @return void
     */
    public function testRegister()
    {
        Mail::fake();

        $userRepo = new UserRepository();

        $this->browse(function (Browser $browser) use ($userRepo) {

            $browser->maximize()
                ->visit('/auth/register')
                ->assertSee('S\'inscrire');

            //Form
            $browser->type("pseudo", "dusk")
                ->type("email", "email@exemple.com")
                ->type("password", "dusk")
                ->type("password_confirmation", "dusk")
                ->keys("input[name=\"ddn\"]", "01")
                ->keys("input[name=\"ddn\"]", "01")
                ->keys("input[name=\"ddn\"]", "2001")
                ->select("sexe")
                ->select("departement")
                ->select("orientation")
                ->check("rules")
                ->press("@submit")
                ->assertPathIs("/");

            $varlink = url("auth/email/confirmation")
                . '?token=' .
                $userRepo->findWithField("email", "email@exemple.com", ["confirmation_token"])->confirmation_token;

            $browser->visit($varlink)->assertSee("Nos derniers inscrits !");

        });




    }
}
