<?php

namespace Tests\Browser;

use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use App\User;

class LoginTest extends DuskTestCase
{
    use DatabaseMigrations;


    /**
     * A Dusk test example.
     *
     * @return void
     */
    public function testLogin()
    {
        factory(User::class)->create(["email" => "browser@exemple.com", "password" => bcrypt("secret")]);

        $this->browse(function (Browser $browser) {
            $browser->visit('auth/login')
                ->assertSee('Se connecter')
                ->type("email", "browser@exemple.com")
                ->type("password", "secret")
                ->press("button[type=\"submit\"]")
                ->assertSee("Nos derniers inscrits !");
        });
    }
}
