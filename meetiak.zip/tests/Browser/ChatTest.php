<?php

namespace Tests\Browser;

use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use App\User;

class ChatTest extends DuskTestCase
{
    use DatabaseMigrations;

    /**
     * A Dusk test example.
     *
     * @return void
     */
    public function testChat()
    {

        $user1 = factory(User::class)->create(["pseudo" => "browser1_pseudo"]);
        $user2 = factory(User::class)->create(["pseudo" => "browser2_pseudo"]);

        $this->browse(function (Browser $browser1, Browser $browser2) use ($user1, $user2) {

            $browser1->loginAs($user1)
                ->visit("chat");

            $browser2->loginAs($user2)
                ->visit("chat")
                ->type("#message", "browser2_hello")
                ->press("button[type=\"submit\"]");

            $browser1->waitForText('browser2_hello', 10)
                ->assertSee("browser2_pseudo")
                ->type("#message", "browser1_hello")
                ->press("button[type=\"submit\"]");

            $browser2->waitForText('browser1_hello', 10)
                ->assertSee("browser1_pseudo");

        });
    }
}
