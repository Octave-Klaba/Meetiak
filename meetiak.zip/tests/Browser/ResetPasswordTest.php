<?php

namespace Tests\Browser;

use App\User;
use Tests\DuskTestCase;
use Laravel\Dusk\Browser;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Support\Facades\Mail;

class ResetPasswordTest extends DuskTestCase
{

    use DatabaseMigrations;

    /**
     * A Dusk test example.
     *
     * @return void
     */
    public function testResetPassword()
    {
        Mail::fake();

        factory(User::class)->create(["email" => "browser@exemple.com", "password" => bcrypt("forgot")]);

        $this->browse(function (Browser $browser) {
            //Forgot
            $browser->visit('auth/forgot')
                ->assertSee('Un email avec un lien de récupération sera envoyer.')
                ->type("email", "browser@exemple.com")
                ->press("button[type=\"submit\"]");

            $this->assertDatabaseHas("password_resets", ["email" => "browser@exemple.com"]);

            //Reset
            $browser->visit(url("auth/reset") . "?token=" . \DB::table("password_resets")->first(["token"])->token)
                ->assertSee("Changement de mot de passe")
                ->type("password", "secret")
                ->type("password_confirmation", "secret")
                ->press("button[type=\"submit\"]")
                //Login
                ->visit('auth/login')
                ->assertSee('Se connecter')
                ->type("email", "browser@exemple.com")
                ->type("password", "secret")
                ->press("button[type=\"submit\"]")
                ->assertSee("Nos derniers inscrits !");;
        });


    }
}
